import bpy
import json
from bpy.types import Menu, Panel, UIList, Operator
from bpy.props import StringProperty,BoolProperty,IntProperty
from . presets import bagapieModifiers
import bpy.utils.previews
from .utils import Get_addon_pref, Warning, is_in_local_view
from .bagapie_group_op import check_parent_group, check_group_instance
from .bagapie_ui_op import add_remove_ui, Draw_Scatter_Layer_Content
from bl_keymap_utils.io import keyconfig_merge


class BAGAPIE_MT_pie_menu(Menu):
    bl_label = "BagaPie"
    bl_idname = "BAGAPIE_MT_pie_menu"

    @classmethod
    def poll(cls, context):
        mode = context.mode
        return (mode == 'OBJECT')

    def draw(self, context):
        bagapie_pref = Get_addon_pref()
        layout = self.layout
        target = bpy.context.active_object
        pie = layout.menu_pie()


    #################################################################################
    # PIE UI FOR ARRAY
    #################################################################################
        row = pie.column(align = False)
        col = row.column(align = True)
        col.scale_y = 1.1
        col.scale_x = 0.9
        col.label(text = "Array", icon = "MOD_ARRAY")
        col.operator_enum("wm.array","array_type")
        if bagapie_pref.autoarrayoncurve:
            col.operator("wm.curvearray", text = "Curve Deform")
        row_draw = col.row(align = True)
        row_draw.operator("bagapie.drawarray", text="Draw")
        row_draw.operator("bagapie.asset_browser", text="Asset Browser").import_mode= 'DrawArray'
        
        col.operator('bagapie.array_along_shape')
        col.separator(factor = 3)
        row.separator(factor = 1.5)


    #################################################################################
    # PIE UI FOR ARCHITECTURE
    #################################################################################
        col = pie.column(align = True)
        row = col.row(align = True)
        row.separator(factor = 1)
        col = row.column(align = True)
        col.label(text = "Architecture", icon = "HOME")
        col.scale_y = 1.1
        
        row = col.row(align = True)
        row = row.split(factor=0.5, align=True)
        if bagapie_pref.wall:
            row.operator('bagapie.wall')
        if bagapie_pref.wallbrick:
            row.operator('bagapie.wallbrick')

        row = col.row(align = True)
        row = row.split(factor=0.5, align=True)
        if bagapie_pref.window:
            row.operator("bagapie.window")
        else:
            tips = row.operator("bagapie.tooltips", text="Window", depress = False)
            tips.message = 'Window is now in the new pie menu in Edit Mode ! | D key'
            tips.title = "NEW Window System !"
        if bagapie_pref.pipes:
            row.operator('bagapie.pipes')

        row = col.row(align = True)
        row = row.split(factor=0.5, align=True)
        if bagapie_pref.column:
            row.operator('bagapie.column')
        if bagapie_pref.tiles:
            row.operator('bagapie.tiles')

        row = col.row(align = True)
        row = row.split(factor=0.5, align=True)
        if bagapie_pref.beamwire:
            row.operator('bagapie.beamwire')
        if bagapie_pref.beam:
            row.operator('bagapie.beam')

        row = col.row(align = True)
        row = row.split(factor=0.5, align=True)
        if bagapie_pref.linearstair:
            row.operator('bagapie.linearstair')
        if bagapie_pref.stairspiral:
            row.operator('bagapie.spiralstair')

        row = col.row(align = True)
        row = row.split(factor=0.5, align=True)
        if bagapie_pref.floor:
            row.operator('bagapie.floor')
        if bagapie_pref.handrail:
            row.operator('bagapie.handrail')

        row = col.row(align = True)
        row = row.split(factor=0.5, align=True)
        if bagapie_pref.cable:
            row.operator('bagapie.cable')
        if bagapie_pref.fence:
            row.operator('bagapie.fence')
        if bagapie_pref.siding:
            row.operator('bagapie.siding')

        row = col.row(align = True)
        row = row.split(factor=0.5, align=True)
        if bagapie_pref.cable:
            row.operator('bagapie.paving')
        if bagapie_pref.fence:
            row.operator('bagapie.grid')

        row = col.row(align = True)
        row = row.split(factor=0.5, align=True)
        if bagapie_pref.siding:
            row.operator('bagapie.perforated_grid')
        if bagapie_pref.siding:
            row.operator('bagapie.plank')

        col.separator(factor = 8)


    #################################################################################
    # PIE UI FOR BOOLEAN
    #################################################################################
        col = pie.column()
        col.label(text = "Boolean", icon = "MOD_BOOLEAN")
        split = col.split(align = True)
        split.scale_y = 1.2
        split.scale_x = 2.2
        split.operator_enum("wm.boolean", "operation_type")


    #################################################################################
    # PIE UI FOR SCATTER
    #################################################################################
        col = pie.column(align = True)
        col.scale_y = 1.2
        col.scale_x = 0.9
        col.label(text = "Scattering", icon = "OUTLINER_OB_CURVES")
        if bagapie_pref.scatter:
            row = col.row(align=True)
            split = row.split(factor=0.45, align=True)
            split.operator("wm.scatter").paint_mode = False
            split.operator("bagapie.asset_browser", text="Asset Browser").import_mode= 'Scatter'
        if bagapie_pref.scatterpaint:
            row = col.row(align=True)
            split = row.split(factor=0.45, align=True)
            split.operator("wm.scatter",text = "Scatter Paint").paint_mode = True
            split.operator("bagapie.asset_browser", text="Asset Browser").import_mode= 'ScatterPaint'
        if bagapie_pref.pointsnapinstance:
            row = col.row(align=True)
            split = row.split(factor=0.45, align=True)
            split.operator("bagapie.pointsnapinstance",text = "Snap Asset")
            split.operator("bagapie.asset_browser", text="Asset Browser").import_mode= 'PointSnapInstance'
        if bagapie_pref.ivy:
            col.operator("bagapie.ivy")


    #################################################################################
    # PIE UI FOR DEFORM
    #################################################################################
        col = pie.column(align = True)
        col.scale_x = 1.1 # button Width
        row = col.row(align = True)
        col = row.column(align = True)
        col.label(text = "Deformation", icon = "MOD_DISPLACE")
        col.scale_y = 1.2
        if bagapie_pref.displace:
            col.operator("wm.displace")
        if bagapie_pref.instancesdisplace:
            col.operator("bagapie.instancesdisplace")
        if bagapie_pref.deform:
            col.operator('bagapie.deform')
        col.separator(factor = 14)
        row.separator(factor = 4.2)
        col.separator(factor = 10)


    #################################################################################
    # PIE UI FOR EFFECTOR
    #################################################################################
        col = pie.column(align = True)
        row = col.row(align = True)
        row.separator(factor = 5.5)
        col = row.column(align = True)
        col.label(text = "Effector", icon = "PARTICLES")
        col.scale_y = 1.2
        if target is not None:
            if "BagaPie_Scatter" in target.modifiers:
                if bagapie_pref.pointeffector:
                    col.operator("bagapie.pointeffector")
                if bagapie_pref.camculling:
                    col.operator('bagapie.camera')
                col.separator(factor = 27)
            else:
                col.label(text = "No Scatter available")
                col.separator(factor = 30)
        else:
            col.label(text = "No Scatter available")
            col.separator(factor = 30)


    #################################################################################
    # PIE UI FOR MANAGE
    #################################################################################
        col = pie.column(align = True)
        col.scale_x = 1.3 # button Width
        col.separator(factor = 9)
        row = col.row(align = True)
        col = row.column(align = True)

        try:
            prop = target["bagapie"]
        except:
            prop = None

        if prop is not None and bagapie_pref.group:
            col.scale_x = 0.9
            col.separator(factor = 14)
        else:
            col.scale_x = 1.1
            col.separator(factor = 8.5)
        col.label(text = "Manage", icon = "PACKAGE")
        col.scale_y = 1.1

        if bagapie_pref.group:
            col.operator("bagapie.group", text="Create Group")
            col.operator("bagapie.autoinstance", text="To Instance")

        if prop is not None and bagapie_pref.group:
            col.operator("bagapie.ungroup")
            col.operator("bagapie.instance", text = 'Group to Instance')
        if bagapie_pref.proxy:
            col.operator("bagapie.proxy")
        if bagapie_pref.saveasasset:
            col.operator("bagapie.saveasset")
        if bagapie_pref.savematerial:
            col.operator("bagapie.savematerial")
        found_gp_sh = any(
            kmi.idname == "bagapie.group"
            for km, _ in keyconfig_merge(context.window_manager.keyconfigs.user, context.window_manager.keyconfigs.user)
            for kmi in km.keymap_items
        )
        if found_gp_sh==False:
            col.operator('bagapie.replace_shortcut', text="Add Group Key")

        row.separator(factor = 3.5) # X Offset Right


    #################################################################################
    # PIE UI FOR TUTORIALS
    #################################################################################
        col = pie.column(align = True)
        col.separator(factor = 7)
        row = col.row(align = True)
        row.separator(factor = 5)
        col = row.column(align = True)
        col.separator(factor = 12)
        col.label(text = "About", icon = "URL")
        col.scale_y = 1.2
        col.operator("wm.url_open", text="Tutorials", icon = 'PLAY').url = "https://youtube.com/playlist?list=PLSVXpfzibQbh_qjzCP2buB2rK1lQtkQvu&si=Y4MRQn_aTIQUXOpw"
        col.operator("wm.url_open", text="Documentation", icon = 'TEXT').url = "https://www.f12studio.fr/bagapiev6"
        if not bagapie_pref.hide_geopack:
            col.operator("bagapie.geopack_create_modifier")


class BAGAPIE_UL_List(UIList):
    """BagaPie UIList."""

    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):

        val = json.loads(item.val)
        name = val['name']
        if name.startswith('BP_A'):
            label = name.removeprefix('BP_Assets_')
            icon = 'MATERIAL'
        else :
            label = bagapieModifiers[name]['label']
            icon = bagapieModifiers[name]['icon']

        obj = context.object
        modifiers = val['modifiers']

        # Make sure your code supports all 3 layout types
        if self.layout_type in {'DEFAULT', 'COMPACT'}:
            mo_type = val['name']

            if mo_type == 'scatter':
                layout.label(text=modifiers[3], icon = icon)
            else:
                layout.label(text=label, icon = icon)
            row = layout.row(align=True)

            # List of modifier type to avoid or apply/remove
            assets_type_list = ["stump","tree","grass","rock","plant"]
            avoid_list = ["pointeffector","pointsnapinstance","instancesdisplace","camera"]
            for a in assets_type_list:
                avoid_list.append(a)

            # icon set
            if mo_type == "scatter":
                nodes = obj.modifiers[modifiers[0]].node_group.nodes
                scatt_node = nodes[modifiers[1]]
                scatt_nde_visibility_op = scatt_node.inputs[22].default_value
                scatt_nde_visibility_bool = scatt_node.inputs[23].default_value

                if nodes.get('BagaPie_Camera_Culling'):
                    cam_cull_node = nodes.get('BagaPie_Camera_Culling')
                    if len(scatt_node.inputs[24].links)>0 and scatt_node.inputs[24].links[0].from_node == cam_cull_node:
                        props = row.operator('use.cameracullingonlayer', text='', depress = True, icon = 'OUTLINER_OB_CAMERA')
                        props.index = index
                        props.from_list = True
                    else:
                        props = row.operator('use.cameracullingonlayer', text='', depress = False, icon = 'CAMERA_DATA')
                        props.index = index
                        props.from_list = True

                if not scatt_nde_visibility_op and scatt_nde_visibility_bool:
                    viewport_icon = 'RESTRICT_VIEW_ON'
                    render_icon = 'RESTRICT_RENDER_OFF'

                elif scatt_nde_visibility_op and scatt_nde_visibility_bool:
                    viewport_icon = 'RESTRICT_VIEW_OFF'
                    render_icon = 'RESTRICT_RENDER_OFF'

                elif scatt_nde_visibility_op and not scatt_nde_visibility_bool:
                    viewport_icon = 'RESTRICT_VIEW_OFF'
                    render_icon = 'RESTRICT_RENDER_ON'

                elif not scatt_nde_visibility_op and not scatt_nde_visibility_bool:
                    viewport_icon = 'RESTRICT_VIEW_ON'
                    render_icon = 'RESTRICT_RENDER_ON'

            elif mo_type == "pointeffector":
                
                scatt_nde_visibility_op = obj.modifiers[modifiers[0]].node_group.nodes[modifiers[1]].inputs[5].default_value
                scatt_nde_visibility_bool = obj.modifiers[modifiers[0]].node_group.nodes[modifiers[1]].inputs[6].default_value

                if not scatt_nde_visibility_op and scatt_nde_visibility_bool:
                    viewport_icon = 'RESTRICT_VIEW_ON'
                    render_icon = 'RESTRICT_RENDER_OFF'

                elif scatt_nde_visibility_op and scatt_nde_visibility_bool:
                    viewport_icon = 'RESTRICT_VIEW_OFF'
                    render_icon = 'RESTRICT_RENDER_OFF'

                elif scatt_nde_visibility_op and not scatt_nde_visibility_bool:
                    viewport_icon = 'RESTRICT_VIEW_OFF'
                    render_icon = 'RESTRICT_RENDER_ON'

                elif not scatt_nde_visibility_op and not scatt_nde_visibility_bool:
                    viewport_icon = 'RESTRICT_VIEW_ON'
                    render_icon = 'RESTRICT_RENDER_ON'

            elif mo_type == "camera":
                
                scatt_nde_visibility_op = obj.modifiers[modifiers[0]].node_group.nodes[modifiers[1]].inputs[3].default_value
                scatt_nde_visibility_bool = obj.modifiers[modifiers[0]].node_group.nodes[modifiers[1]].inputs[4].default_value

                if not scatt_nde_visibility_op and scatt_nde_visibility_bool:
                    viewport_icon = 'RESTRICT_VIEW_ON'
                    render_icon = 'RESTRICT_RENDER_OFF'

                elif scatt_nde_visibility_op and scatt_nde_visibility_bool:
                    viewport_icon = 'RESTRICT_VIEW_OFF'
                    render_icon = 'RESTRICT_RENDER_OFF'

                elif scatt_nde_visibility_op and not scatt_nde_visibility_bool:
                    viewport_icon = 'RESTRICT_VIEW_OFF'
                    render_icon = 'RESTRICT_RENDER_ON'

                elif not scatt_nde_visibility_op and not scatt_nde_visibility_bool:
                    viewport_icon = 'RESTRICT_VIEW_ON'
                    render_icon = 'RESTRICT_RENDER_ON'

            elif mo_type == "wallbrick":
                if obj.type == 'MESH':
                    viewport_icon = 'RESTRICT_VIEW_OFF'
                    if not obj.modifiers[modifiers[0]].show_viewport:
                        viewport_icon = 'RESTRICT_VIEW_ON'
                    render_icon = 'RESTRICT_RENDER_OFF'
                    if not obj.modifiers[modifiers[0]].show_render:
                        render_icon = 'RESTRICT_RENDER_ON'
                else:
                    viewport_icon = 'RESTRICT_VIEW_OFF'
                    if not obj.modifiers[modifiers[1]].show_viewport:
                        viewport_icon = 'RESTRICT_VIEW_ON'
                    render_icon = 'RESTRICT_RENDER_OFF'
                    if not obj.modifiers[modifiers[1]].show_render:
                        render_icon = 'RESTRICT_RENDER_ON'

            elif mo_type not in assets_type_list and not mo_type.startswith('BP_A'):
                viewport_icon = 'RESTRICT_VIEW_OFF'
                if modifiers[0] in obj.modifiers:
                    if not obj.modifiers[modifiers[0]].show_viewport:
                        viewport_icon = 'RESTRICT_VIEW_ON'
                    render_icon = 'RESTRICT_RENDER_OFF'
                    if not obj.modifiers[modifiers[0]].show_render:
                        render_icon = 'RESTRICT_RENDER_ON'

            # APPLY
            if mo_type not in avoid_list and not mo_type.startswith('BP_A'):
                row.operator("apply.modifier",text="", icon='CHECKMARK')
            # REMOVE
            if mo_type not in assets_type_list and not mo_type.startswith('BP_A'):
                row.operator('bagapie.'+ name +'_remove', text="", icon='REMOVE').index=index
            # VISIBILITY
            if mo_type not in assets_type_list and not mo_type.startswith('BP_A'):
                if modifiers[0] in obj.modifiers:
                    row.operator("hide.viewport",text="", icon=viewport_icon).index=index
                    row.operator("hide.render",text="", icon=render_icon).index=index


class BAGAPIE_PT_modifier_panel(Panel):
    bl_idname = 'BAGAPIE_PT_modifier_panel'
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "BagaPie"
    bl_label = "BagaPie Modifier"

    use_random: bpy.props.BoolProperty(default=False) # type: ignore

    @classmethod
    def poll(cls, context):
        o = context.object
        return (
            o is not None and
            o.type == 'MESH' or 'CURVE'
        )

    def draw(self, context):
        layout = self.layout
        obj = context.object
        obj_allowed_types = ["MESH","CURVE","EMPTY"]
        displaydoc = True
        bagapie_pref = Get_addon_pref()

        if obj and obj.type in obj_allowed_types:
            col = layout.column()
            if obj.bagapieIndex < len(obj.bagapieList):

                displaydoc = False
                
                col.template_list("BAGAPIE_UL_List", "The_List", obj,
                                "bagapieList", obj, "bagapieIndex")

                val = json.loads(obj.bagapieList[obj.bagapieIndex]['val'])
                mo_type = val['name']
                modifiers = val['modifiers']

                if mo_type.startswith('BP_A'): # OLD STUFF, MUST BE REMOVED IN THE FUTURE
                    label = mo_type.removeprefix('BP_Assets_')
                    icon = 'MATERIAL'
                else :
                    label = bagapieModifiers[mo_type]['label']
                    icon = bagapieModifiers[mo_type]['icon']

                if mo_type == "wall":
                    modifier_header_basic(col)
                    box = layout.box()
                    box.label(text=label, icon=icon)

                    box.prop(obj.modifiers[modifiers[1]], 'screw_offset', text="Wall Height")
                    box.prop(obj.modifiers[modifiers[2]], 'thickness', text="Wall Thickness")
                    box.prop(obj.modifiers[modifiers[2]], 'offset', text="Wall Axis Offset")

                elif mo_type == "wallbrick":
                    modifier_header_basic(col)
                    box = layout.box()
                    box.label(text=label, icon=icon)

                    if obj.type == 'MESH':
                        modifier = obj.modifiers[modifiers[0]]
                    else:
                        modifier = obj.modifiers[modifiers[1]]

                    mo_input=modifier.properties.inputs

                    box = box.column(align=True)
                    box.prop(getattr(mo_input, "Input_2"), "value", text="Height")
                    box.prop(getattr(mo_input, "Input_3"), "value", text="Thickness")
                    box.prop(getattr(mo_input, "Input_4"), "value", text="Length")
                    box.label(text="Material :")
                    box.prop_search(getattr(mo_input, "Input_17"), "value", bpy.data, "materials", text="", icon="MATERIAL")

                    box = layout.box()
                    box = box.column(align=False)
                    box.prop(getattr(mo_input, "Input_5"), "value", text="Row Count")
                    box = box.column(align=True)
                    box.prop(getattr(mo_input, "Input_6"), "value", text="Row Offset")
                    box.prop(getattr(mo_input, "Input_7"), "value", text="Horizontal Offset")
                    box.prop(getattr(mo_input, "Input_8"), "value", text="Flip")

                    box = layout.box()
                    box.label(text="Random")
                    box = box.column(align=True)
                    box.label(text="Position Min / Max")
                    row = box.row()
                    row.prop(getattr(mo_input, "Input_9"), "value", text="")
                    row = box.row()
                    row.prop(getattr(mo_input, "Input_10"), "value", text="")
                    box.label(text="Rotation Min / Max")
                    row = box.row()
                    row.prop(getattr(mo_input, "Input_11"), "value", text="")
                    row = box.row()
                    row.prop(getattr(mo_input, "Input_12"), "value", text="")
                    box.label(text="Scale Min / Max")
                    row = box.row()
                    row.prop(getattr(mo_input, "Input_13"), "value", text="")
                    row = box.row()
                    row.prop(getattr(mo_input, "Input_14"), "value", text="")
                    
                    box = layout.box()
                    row = box.row()
                    row.label(text="Deformation")
                    box = box.column(align=True)
                    row = box.row()
                    row.prop(getattr(mo_input, "Input_15"), "value", text="")
                    row = box.row()
                    row.prop(getattr(mo_input, "Input_16"), "value", text="Scale")

                elif mo_type == "pipes":
                    modifier_header_basic(col)
                    box = layout.box()
                    add_remove_ui(col, "Input_13")
                    box.label(text="Pipe", icon=icon)

                    modifier = obj.modifiers[modifiers[0]]
                    mo_input = modifier.properties.inputs

                    box = box.column(align=True)
                    row = box.row(align=True)
                    input_index = "Input_29"
                    value = modifier.properties.inputs[input_index]["value"]
                    props = row.operator("switch.button", text="Poly", depress=value != gn_bool_version(1), icon="OUTLINER_OB_MESH"); props.index = input_index
                    props = row.operator("switch.button", text="Curve", depress=value != gn_bool_version(0), icon="OUTLINER_OB_CURVE"); props.index = input_index

                    props.index = input_index
                    box.prop(getattr(mo_input, "Input_2"), "value", text="Radius")
                    box.prop(getattr(mo_input, "Input_10"), "value", text="Profile Resolution")
                    box.prop(getattr(mo_input, "Input_3"), "value", text="Offset")
                    box.prop(getattr(mo_input, "Input_4"), "value", text="Precision")
                    box.prop(getattr(mo_input, "Input_5"), "value", text="Resolution")
                    box.prop(getattr(mo_input, "Input_24"), "value", text="Bevel")
                    box.prop(getattr(mo_input, "Input_28"), "value", text="End Bevel")
                    box = layout.box()
                    box = box.column(align=True)
                    box.label(text="Junctions")
                    box.prop(getattr(mo_input, "Input_6"), "value", text="Density")
                    box.prop(getattr(mo_input, "Input_7"), "value", text="Depth")
                    box.label(text="Support")
                    box.prop(getattr(mo_input, "Input_8"), "value", text="Probability")
                    box.prop(getattr(mo_input, "Input_9"), "value", text="Radius")
                    
                    box = layout.box()
                    box = box.column(align=True)
                    box.label(text="Random")
                    
                    inputs = [
                        ("Input_14", "Use Valve"),
                        ("Input_15", "Use Jonctions"),
                        ("Input_20", "Use Support"),
                        ("Input_22", "Use Pipe End"),
                    ]
                    for input_index, text in inputs:
                        props = box.operator('switch.button', text=text, depress=(mo_input[input_index]["value"] != gn_bool_version(1)))
                        props.index = input_index
                    
                    box = layout.box()
                    box = box.column(align=True)
                    box.label(text="Custom :",  icon = "MESH_DATA")
                    
                    inputs = [
                        ("Input_26", "Use Custom Valve", "Input_25"),
                        ("Input_16", "Use Custom Jonctions", "Input_17"),
                        ("Input_11", "Support Custom Profile", "Input_12")
                    ]
                    for input_index, text, prop_index in inputs:
                        depress = (mo_input[input_index]["value"] == gn_bool_version(1))
                        props = box.operator('switch.button', text=text, depress=depress)
                        props.index = input_index
                        if depress:
                            box.prop_search(getattr(mo_input, prop_index), "value", bpy.data, "objects", text="", icon="OBJECT_DATA")

                    # TARGET
                    box.separator(factor = 3)
                    box.label(text="Target :", icon = "MOD_SHRINKWRAP")
                    box.prop_search(getattr(mo_input, "Input_13"), "value", bpy.data, "collections", text="", icon="OUTLINER_COLLECTION")

                    # MATERIAL
                    box.separator(factor = 3)
                    box.label(text="Materials", icon = "MATERIAL")
                    box.prop_search(getattr(mo_input, "Input_18"), "value", bpy.data, "materials", text="Jonction", icon="MATERIAL")
                    box.prop_search(getattr(mo_input, "Input_19"), "value", bpy.data, "materials", text="Valve", icon="MATERIAL")
                    box.prop_search(getattr(mo_input, "Input_21"), "value", bpy.data, "materials", text="Support", icon="MATERIAL")
                    box.prop_search(getattr(mo_input, "Input_23"), "value", bpy.data, "materials", text="Pipe", icon="MATERIAL")

                    box.separator(factor = 3)
                    box.label(text="Tips", icon = "INFO")
                    box.label(text="This modifier break UVs.")
                    box.label(text="You can still get UVs as an attribute")
                    box.label(text="Once the modifier is applied :")
                    box.label(text="Prop > Obj Data Prop > Attributes")

                elif mo_type == "beamwire":
                    modifier_header_basic(col)
                    box = layout.box()
                    box.label(text="Beam Wire", icon=icon)

                    modifier = obj.modifiers[modifiers[0]]
                    mo_input = modifier.properties.inputs


                    box = box.column(align=True)
                    box.prop(getattr(mo_input, "Input_2"), "value", text="Sides Count")
                    box.prop(getattr(mo_input, "Input_3"), "value", text="Radius")
                    box.prop(getattr(mo_input, "Input_4"), "value", text="Section Height")
                    box.prop(getattr(mo_input, "Input_5"), "value", text="Levels")

                    box = layout.box()
                    box = box.column(align=True)
                    box.label(text="Diameter")
                    box.prop(getattr(mo_input, "Input_8"), "value", text="Diagonal")
                    box.prop(getattr(mo_input, "Input_7"), "value", text="Beam")
                    
                    box.label(text="Profile")
                    input_index = "Input_6"
                    props = box.operator('switch.button', text='Triangulate', depress=(mo_input[input_index]["value"] == gn_bool_version(1)), icon="MOD_TRIANGULATE")
                    props.index = input_index

                    row = box.row(align=True)
                    row.label(text="Beam")
                    inputs = [
                        ("Input_11", "MESH_CIRCLE", True),
                        ("Input_11", "MESH_PLANE", False)
                    ]
                    for input_index, icon, depress_state in inputs:
                        props = row.operator('switch.button', text='', depress=(mo_input[input_index]["value"] == gn_bool_version(1)) == depress_state, icon=icon)
                        props.index = input_index

                    row = box.row(align=True)
                    row.label(text="Bracing")
                    inputs = [
                        ("Input_9", "MESH_CIRCLE", True),
                        ("Input_9", "MESH_PLANE", False)
                    ]
                    for input_index, icon, depress_state in inputs:
                        depress = (mo_input[input_index]["value"] == gn_bool_version(1)) if depress_state else (mo_input[input_index]["value"] != gn_bool_version(1))
                        props = row.operator('switch.button', text='', depress=depress, icon=icon)
                        props.index = input_index

                    # MATERIAL
                    box = layout.box()
                    box = box.column(align=True)
                    box.label(text="Material", icon = "MATERIAL")
                    box.prop_search(getattr(mo_input, "Input_13"), "value", bpy.data, "materials", text="", icon="MATERIAL")

                elif mo_type == "linearstair":
                    modifier_header_basic(col)
                    box = layout.box()
                    box.label(text="Main", icon=icon)

                    modifier = obj.modifiers[modifiers[0]]
                    mo_input = modifier.properties.inputs

                    box = box.column(align=True)
                    box.prop(getattr(mo_input, "Input_3"), "value", text="Depth")
                    box.prop(getattr(mo_input, "Input_4"), "value", text="Step Height")
                    box.prop(getattr(mo_input, "Input_5"), "value", text="Height")
                    box.prop(getattr(mo_input, "Input_6"), "value", text="Width")
                    box.prop(getattr(mo_input, "Input_8"), "value", text="Thickness")

                    box = layout.box()
                    box = box.column(align=True)
                    box.label(text="Properties")

                    row = box.row(align=True)
                    row.label(text="Type")
                    input_index = "Input_15"
                    value = mo_input[input_index]["value"]
                    props = row.operator("switch.button", text="", depress=value == gn_bool_version(1), icon="MESH_PLANE"); props.index = input_index
                    props = row.operator("switch.button", text="", depress=value != gn_bool_version(1), icon="SNAP_FACE"); props.index = input_index

                    row = box.row(align=True)
                    row.label(text="Use Handrail")
                    input_index = "Input_18"
                    value = mo_input[input_index]["value"]
                    props = row.operator("switch.button", text="", depress=value == gn_bool_version(1), icon="X"); props.index = input_index
                    props = row.operator("switch.button", text="", depress=value != gn_bool_version(1), icon="CHECKMARK"); props.index = input_index

                    row = box.row(align=True)
                    row.label(text="Use Glass")
                    input_index = "Input_23"
                    value = mo_input[input_index]["value"]
                    props = row.operator("switch.button", text="", depress=value == gn_bool_version(1), icon="X"); props.index = input_index
                    props = row.operator("switch.button", text="", depress=value != gn_bool_version(1), icon="CHECKMARK"); props.index = input_index

                    input_index = "Input_15"
                    if mo_input[input_index]["value"] == gn_bool_version(1):
                        box = layout.box()
                        box.label(text="Stringers")
                        box = box.column(align=True)
                        box.prop(getattr(mo_input, "Input_16"), "value", text="Width")
                        box.prop(getattr(mo_input, "Input_17"), "value", text="Height")
                        box.prop(getattr(mo_input, "Input_19"), "value", text="Offset X")
                        box.prop(getattr(mo_input, "Input_20"), "value", text="Offset Y")

                    input_index = "Input_18"
                    if mo_input[input_index]["value"] == gn_bool_version(0):
                        box = layout.box()
                        box.label(text="Handrail")
                        box = box.column(align=True)
                        box.prop(getattr(mo_input, "Input_9"), "value", text="Offset")
                        box.prop(getattr(mo_input, "Input_10"), "value", text="Height")
                        box.prop(getattr(mo_input, "Input_11"), "value", text="Radius")
                        box.prop(getattr(mo_input, "Input_12"), "value", text="Balusters Radius")
                        box.prop(getattr(mo_input, "Input_13"), "value", text="Balusters Distance")
                        box.prop(getattr(mo_input, "Input_14"), "value", text="Handrail Resolution")
                        input_index = "Input_23"
                        if mo_input[input_index]["value"] == gn_bool_version(0):
                            box.prop(getattr(mo_input, "Input_21"), "value", text="Glass Size")
                            box.prop(getattr(mo_input, "Input_22"), "value", text="Glass Offset")

                    # MATERIAL
                    box = layout.box()
                    box = box.column(align=True)
                    box.label(text="Material", icon = "MATERIAL")
                    box.prop_search(getattr(mo_input, "Input_24"), "value", bpy.data, "materials", text="Glass", icon="MATERIAL")
                    box.prop_search(getattr(mo_input, "Input_25"), "value", bpy.data, "materials", text="Baluster", icon="MATERIAL")
                    box.prop_search(getattr(mo_input, "Input_26"), "value", bpy.data, "materials", text="Handrail", icon="MATERIAL")
                    box.prop_search(getattr(mo_input, "Input_27"), "value", bpy.data, "materials", text="Stringer", icon="MATERIAL")
                    box.prop_search(getattr(mo_input, "Input_28"), "value", bpy.data, "materials", text="Step", icon="MATERIAL")

                elif mo_type == "tiles":
                    modifier_header_basic(col)
                    box = layout.box()
                    box.label(text="Tile", icon=icon)

                    modifier = obj.modifiers[modifiers[0]]
                    mo_input = modifier.properties.inputs

                    col = box.column(align=True)
                    row = col.row(align=True)
                    input_index = "Input_11"
                    props = row.operator('switch.button', text='Procedural', depress = mo_input[input_index]["value"] == gn_bool_version(0))
                    props.index = input_index
                    props = row.operator('switch.button', text='Custom', depress = not mo_input[input_index]["value"] == gn_bool_version(0))
                    props.index = input_index

                    if mo_input[input_index]["value"] == gn_bool_version(0):

                        col.prop(getattr(mo_input, "Input_6"), "value", text="Type")
                        col.prop(getattr(mo_input, "Input_2"), "value", text="Resolution")

                        col = box.column(align=True)
                        col.prop(getattr(mo_input, "Input_5"), "value", text="Length")
                        col.prop(getattr(mo_input, "Input_20"), "value", text="Height")
                        col.prop(getattr(mo_input, "Input_3"), "value", text="Width")
                        col.prop(getattr(mo_input, "Input_4"), "value", text="Width Offset")
                        col.prop(getattr(mo_input, "Input_18"), "value", text="Thickness")

                        col = box.column(align=True)
                        col.prop(getattr(mo_input, "Input_7"), "value", text="Angle Tile")
                    else:
                        box.prop_search(getattr(mo_input, "Input_12"), "value", bpy.data, "objects", text="", icon="OBJECT_DATA")
                    
                    # REPARTITION
                    box = layout.box()
                    box.label(text="Repartition", icon=icon)

                    modifier = obj.modifiers[modifiers[0]]

                    col = box.column(align=True)
                    col.prop(getattr(mo_input, "Input_8"), "value", text="Count X")
                    col.prop(getattr(mo_input, "Input_9"), "value", text="Count Y")

                    col = box.column(align=True)
                    col.prop(getattr(mo_input, "Input_23"), "value", text="Biais")
                    col.prop(getattr(mo_input, "Input_19"), "value", text="Superposition X")
                    col.prop(getattr(mo_input, "Input_10"), "value", text="Superposition Y")

                    col = box.column(align=True)
                    col.prop(getattr(mo_input, "Input_13"), "value", text="Triangulate")
                    col.prop(getattr(mo_input, "Input_14"), "value", text="Shift X")

                    col = box.column(align=True)
                    col.prop(getattr(mo_input, "Input_15"), "value", text="Angle")

                    box = layout.box()
                    box.label(text="Random", icon=icon)
                    col = box.column(align=True)
                    col.prop(getattr(mo_input, "Input_16"), "value", text="Scale")
                    col.prop(getattr(mo_input, "Input_17"), "value", text="Rotation")
                    col.prop(getattr(mo_input, "Input_21"), "value", text="Seed")

                    # MATERIAL
                    box = layout.box()
                    box = box.column(align=True)
                    box.label(text="Material", icon = "MATERIAL")
                    box.prop_search(getattr(mo_input, "Input_22"), "value", bpy.data, "materials", text="", icon="MATERIAL")

                elif mo_type == "beam":
                    modifier_header_basic(col)
                    box = layout.box()
                    box.label(text="Main", icon=icon)

                    modifier = obj.modifiers[modifiers[0]]
                    mo_input = modifier.properties.inputs

                    box = box.column(align=True)
                    box.prop(getattr(mo_input, "Input_2"), "value", text="Width")
                    box.prop(getattr(mo_input, "Input_3"), "value", text="Height")
                    box.prop(getattr(mo_input, "Input_8"), "value", text="Length")
                    box = box.column(align=True)
                    box.prop(getattr(mo_input, "Input_4"), "value", text="Thickness")
                    box.prop(getattr(mo_input, "Input_5"), "value", text="Int Offset")
                    box.prop(getattr(mo_input, "Input_6"), "value", text="Bevel")
                    box = box.column(align=True)
                    box.prop(getattr(mo_input, "Input_7"), "value", text="Bevel Count")

                    # MATERIAL
                    box = layout.box()
                    box = box.column(align=True)
                    box.label(text="Material", icon = "MATERIAL")
                    box.prop_search(getattr(mo_input, "Input_9"), "value", bpy.data, "materials", text="", icon="MATERIAL")

                elif mo_type == "column":
                    modifier_header_basic(col)
                    box = layout.box()
                    box.label(text="Main", icon=icon)

                    modifier = obj.modifiers[modifiers[0]]
                    mo_input = modifier.properties.inputs

                    box = box.column(align=True)
                    box.prop(getattr(mo_input, "Input_6"), "value", text="Height")
                    input_index = "Input_7"
                    row = box.row(align=True)
                    row.label(text="Profile")
                    value = mo_input[input_index]["value"]

                    props = row.operator("switch.button", text="", depress=value == gn_bool_version(0), icon="MESH_PLANE"); props.index = input_index
                    props = row.operator("switch.button", text="", depress=value == gn_bool_version(1), icon="MESH_CIRCLE"); props.index = input_index

                    if mo_input[input_index]["value"] == gn_bool_version(0):
                        box.prop(getattr(mo_input, "Input_4"), "value", text="Width")
                        box.prop(getattr(mo_input, "Input_5"), "value", text="Depth")
                        box.separator(factor = 1)
                        box.label(text="Bevel")
                        box = box.column(align=True)
                        box.prop(getattr(mo_input, "Input_2"), "value", text="Size")
                        box.prop(getattr(mo_input, "Input_3"), "value", text="Count")
                    else:
                        box.prop(getattr(mo_input, "Input_9"), "value", text="Radius")
                        box.prop(getattr(mo_input, "Input_8"), "value", text="Resolution")

                    
                    box.label(text="Material")
                    box.prop_search(getattr(mo_input, "Input_11"), "value", bpy.data, "materials", text="", icon="MATERIAL")

                elif mo_type == "deform":
                    modifier_header_basic(col)
                    box = layout.box()
                    box.label(text="Main", icon=icon)

                    modifier = obj.modifiers.get(val["mo_name"])
                    mo_input=modifier.properties.inputs

                    box = box.column(align=True)

                    box.label(text="Blend")
                    row = box.row(align=True)
                    row.prop(getattr(mo_input, "Input_2"), "value", text="X")
                    row.prop(getattr(mo_input, "Input_3"), "value", text="Y")
                    row.prop(getattr(mo_input, "Input_4"), "value", text="Z")
                    row = box.row(align=True)
                    input_index = "Input_8"
                    if mo_input[input_index]["value"] == gn_bool_version(0):
                        props = row.operator('switch.button', text='Flip', depress = True)
                    else:
                        props = row.operator('switch.button', text='Flip', depress = False)
                    props.index = input_index
                    box.separator(factor = 1)
                    box.label(text="Twist")
                    row = box.row(align=True)
                    row.prop(getattr(mo_input, "Input_5"), "value", text="X")
                    row.prop(getattr(mo_input, "Input_6"), "value", text="Y")
                    row.prop(getattr(mo_input, "Input_7"), "value", text="Z")

                elif mo_type == "floor":
                    modifier_header_basic(col)
                    box = layout.box()
                    box.label(text="Main", icon=icon)

                    modifier = obj.modifiers[modifiers[0]]
                    mo_input = modifier.properties.inputs

                    box = box.column(align=True)
                    row = box.row(align=True)
                    row.label(text="X")
                    row.label(text="Y")
                    row.label(text="Z")
                    row = box.row(align=True)
                    row.prop(getattr(mo_input, "Input_3"), "value", text="")
                    row.prop(getattr(mo_input, "Input_4"), "value", text="")
                    row.prop(getattr(mo_input, "Input_5"), "value", text="")
                    box.separator(factor = 1)
                    box.prop(getattr(mo_input, "Input_6"), "value", text="Vertices X")
                    box.prop(getattr(mo_input, "Input_7"), "value", text="Vertices Y")
                    box.separator(factor = 1)
                    box.prop(getattr(mo_input, "Input_8"), "value", text="Offset X")
                    box.prop(getattr(mo_input, "Input_10"), "value", text="Offset Y")
                    box.separator(factor = 1)
                    box.prop(getattr(mo_input, "Input_11"), "value", text="Random")
                    box.prop(getattr(mo_input, "Input_12"), "value", text="Offset")

                    # MATERIAL
                    box = layout.box()
                    box = box.column(align=True)
                    box.label(text="Material", icon = "MATERIAL")
                    box.prop_search(getattr(mo_input, "Input_15"), "value", bpy.data, "materials", text="", icon="MATERIAL")

                    # Custom mesh
                    box = layout.box()
                    box = box.column(align=True)
                    box.label(text="Custom", icon = "MESH_DATA")
                    input_index = "Input_14"
                    if mo_input[input_index]["value"] == gn_bool_version(1):
                        props = box.operator('switch.button', text='Use Custom Mesh', depress = True)
                        box.prop_search(getattr(mo_input, "Input_13"), "value", bpy.data, "objects", text="", icon="OBJECT_DATA")
                    else:
                        props = box.operator('switch.button', text='Use Custom Mesh', depress = False)
                    props.index = input_index

                elif mo_type == "spiralstair":
                    modifier_header_basic(col)
                    box = layout.box()
                    box.label(text="Main", icon=icon)

                    modifier = obj.modifiers[modifiers[0]]
                    mo_input = modifier.properties.inputs

                    box = box.column(align=True)
                    box.prop(getattr(mo_input, "Input_5"), "value", text="Height")
                    box.prop(getattr(mo_input, "Input_3"), "value", text="Radius")
                    box.prop(getattr(mo_input, "Input_2"), "value", text="Width")
                    box.prop(getattr(mo_input, "Input_7"), "value", text="Step Height")
                    box.prop(getattr(mo_input, "Input_6"), "value", text="Rotation")
                    box.prop(getattr(mo_input, "Input_8"), "value", text="Step Thickness")
                    input_index = "Input_9"
                    if mo_input[input_index]["value"] == gn_bool_version(1):
                        props = box.operator('switch.button', text='Invert', depress = True)
                    else:
                        props = box.operator('switch.button', text='Invert', depress = False)
                    props.index = input_index

                    # HANDRAIL
                    box = layout.box()
                    box.label(text="Handrail")
                    box = box.column()
                    row = box.row(align=True)
                    input_index = "Input_18"
                    if mo_input[input_index]["value"] == gn_bool_version(1):
                        props = row.operator('switch.button', text='Left', depress = False)
                    else:
                        props = row.operator('switch.button', text='Left', depress = True)
                    props.index = input_index
                    input_index = "Input_17"
                    if mo_input[input_index]["value"] == gn_bool_version(1):
                        props = row.operator('switch.button', text='Right', depress = False)
                    else:
                        props = row.operator('switch.button', text='Right', depress = True)
                    props.index = input_index
                    box = box.column(align=True)
                    if mo_input["Input_17"]["value"] == gn_bool_version(0) or mo_input["Input_18"]["value"] == gn_bool_version(0):
                        box.prop(getattr(mo_input, "Input_11"), "value", text="Height")
                        box.prop(getattr(mo_input, "Input_10"), "value", text="Offset")
                        box.prop(getattr(mo_input, "Input_14"), "value", text="Baluster Distance")
                        box.prop(getattr(mo_input, "Input_13"), "value", text="Resolution")
                        box = box.column()
                        box = box.column(align=True)
                        box.prop(getattr(mo_input, "Input_12"), "value", text="Radius")
                        box.prop(getattr(mo_input, "Input_38"), "value", text="Profile Resolution")
                    
                    box.separator(factor = 1)
                    # GLASS
                    input_index = "Input_15"
                    if mo_input[input_index]["value"] == gn_bool_version(1):
                        props = box.operator('switch.button', text='Use Glass', depress = True)
                    else:
                        props = box.operator('switch.button', text='Use Glass', depress = False)
                    props.index = input_index
                    if mo_input[input_index]["value"] == gn_bool_version(1):
                        box.prop(getattr(mo_input, "Input_35"), "value", text="Glass Height")
                        box.prop(getattr(mo_input, "Input_40"), "value", text="Glass Width")

                    box = layout.box()
                    box = box.column(align=True)
                    box.label(text="Support")
                    input_index = "Input_25"
                    if mo_input[input_index]["value"] == gn_bool_version(0):
                        props = box.operator('switch.button', text='Column', depress = False)
                    else:
                        props = box.operator('switch.button', text='Column', depress = True)
                    props.index = input_index
                    if mo_input["Input_25"]["value"] == gn_bool_version(1):
                        box.prop(getattr(mo_input, "Input_39"), "value", text="Resolution")

                    box.label(text="Stringer")
                    row = box.row(align=True)
                    input_index = "Input_21"
                    if mo_input[input_index]["value"] == gn_bool_version(1):
                        props = row.operator('switch.button', text='Left', depress = False)
                    else:
                        props = row.operator('switch.button', text='Left', depress = True)
                    props.index = input_index
                    input_index = "Input_22"
                    if mo_input[input_index]["value"] == gn_bool_version(1):
                        props = row.operator('switch.button', text='Right', depress = False)
                    else:
                        props = row.operator('switch.button', text='Right', depress = True)
                    props.index = input_index

                    box = box.column()
                    if mo_input["Input_21"]["value"] == gn_bool_version(0) or mo_input["Input_22"]["value"] == gn_bool_version(0):
                        box.label(text="Width")
                        row = box.row(align=True)
                        if mo_input["Input_21"]["value"] == gn_bool_version(0):
                            row.prop(getattr(mo_input, "Input_19"), "value", text="L")
                        if mo_input["Input_22"]["value"] == gn_bool_version(0):
                            row.prop(getattr(mo_input, "Input_20"), "value", text="R")
                        box.label(text="Offset")
                        row = box.row(align=True)
                        if mo_input["Input_21"]["value"] == gn_bool_version(0):
                            row.prop(getattr(mo_input, "Input_33"), "value", text="L")
                        if mo_input["Input_22"]["value"] == gn_bool_version(0):
                            row.prop(getattr(mo_input, "Input_34"), "value", text="R")
                        box.prop(getattr(mo_input, "Input_23"), "value", text="Thickness")
                        box.prop(getattr(mo_input, "Input_24"), "value", text="Offset Z")

                    # MATERIAL
                    box = layout.box()
                    box = box.column(align=True)
                    box.label(text="Material", icon = "MATERIAL")
                    box.prop_search(getattr(mo_input, "Input_27"), "value", bpy.data, "materials", text="Baluster", icon="MATERIAL")
                    box.prop_search(getattr(mo_input, "Input_28"), "value", bpy.data, "materials", text="Glass", icon="MATERIAL")
                    box.prop_search(getattr(mo_input, "Input_29"), "value", bpy.data, "materials", text="Column", icon="MATERIAL")
                    box.prop_search(getattr(mo_input, "Input_30"), "value", bpy.data, "materials", text="Handrail", icon="MATERIAL")
                    box.prop_search(getattr(mo_input, "Input_31"), "value", bpy.data, "materials", text="Step", icon="MATERIAL")
                    box.prop_search(getattr(mo_input, "Input_32"), "value", bpy.data, "materials", text="Stringer", icon="MATERIAL")

                elif mo_type == "handrail":
                    modifier_header_basic(col)

                    # MAIN
                    box = layout.box()
                    box.label(text="Main", icon=icon)

                    modifier = obj.modifiers[modifiers[0]]
                    mo_input = modifier.properties.inputs

                    box = box.column(align=True)
                    box.prop(getattr(mo_input, "Input_8"), "value", text="Height")
                    box.prop(getattr(mo_input, "Input_2"), "value", text="Module Length")
                    row = box.row(align=True)
                    input_index = "Input_32"
                    if mo_input[input_index]["value"] == gn_bool_version(1):
                        props = row.operator('switch.button', text='Curve', depress = False, icon = 'OUTLINER_OB_CURVE')
                    else:
                        props = row.operator('switch.button', text='Curve', depress = True, icon = 'OUTLINER_OB_CURVE')
                    props.index = input_index
                    if mo_input[input_index]["value"] == gn_bool_version(0):
                        props = row.operator('switch.button', text='Poly', depress = False, icon = 'OUTLINER_OB_MESH')
                    else:
                        props = row.operator('switch.button', text='Poly', depress = True, icon = 'OUTLINER_OB_MESH')
                    props.index = input_index


                    # GLASS

                    box = layout.box()
                    box = box.column() #lol
                    row = box.row()
                    input_index = "Input_15"
                    if mo_input[input_index]["value"] == gn_bool_version(1):
                        props = row.operator('switch.button', text='Glass', depress = True)
                    else:
                        row.scale_y = 2
                        props = row.operator('switch.button', text='Glass', depress = False)
                    props.index = input_index

                    box = box.column(align=True)
                    if mo_input[input_index]["value"] == gn_bool_version(1):
                        box.prop(getattr(mo_input, "Input_4"), "value", text="Size")
                        box.prop(getattr(mo_input, "Input_9"), "value", text="Offset")
                        box.prop(getattr(mo_input, "Input_10"), "value", text="Thickness")
                        box.prop(getattr(mo_input, "Input_3"), "value", text="Proportion")
                        box.separator(factor = 1)
                            
                        input_index = "Input_14"
                        row = box.row()
                        if mo_input[input_index]["value"] == gn_bool_version(1):
                            props = row.operator('switch.button', text='Use Connector', depress = True)
                        else:
                            row.scale_y = 1.5
                            props = row.operator('switch.button', text='Use Connector', depress = False)
                        props.index = input_index

                        box = box.column(align=True)
                        if mo_input[input_index]["value"] == gn_bool_version(1):
                            box.prop(getattr(mo_input, "Input_5"), "value", text="Offset")
                            box.prop(getattr(mo_input, "Input_47"), "value", text="Length")
                            row = box.row(align=True)
                            row.prop(getattr(mo_input, "Input_6"), "value", text="X")
                            row.prop(getattr(mo_input, "Input_7"), "value", text="Y")


                    # BALUSTER

                    box = layout.box()
                    input_index = "Input_17"
                    if mo_input[input_index]["value"] == gn_bool_version(1):
                        props = box.operator('switch.button', text='Baluster', depress = True)
                    else:
                        box.scale_y = 2
                        props = box.operator('switch.button', text='Baluster', depress = False)
                    props.index = input_index
                    if mo_input[input_index]["value"] == gn_bool_version(1):
                        box = box.column(align=True)
                            
                        row = box.row(align=True)
                        row.label(text="Profile")
                        input_index = "Input_16"
                        if mo_input[input_index]["value"] == gn_bool_version(1):
                            props = row.operator('switch.button', text=' ', depress = True, icon = 'MESH_PLANE')
                        else:
                            props = row.operator('switch.button', text=' ', depress = False, icon = 'MESH_PLANE')
                        props.index = input_index
                        input_index = "Input_16"
                        if mo_input[input_index]["value"] == gn_bool_version(1):
                            props = row.operator('switch.button', text=' ', depress = False, icon = 'MESH_CIRCLE')
                        else:
                            props = row.operator('switch.button', text=' ', depress = True, icon = 'MESH_CIRCLE')
                        props.index = input_index

                        box = box.column(align=True)
                        if mo_input[input_index]["value"] == gn_bool_version(1):
                            box.prop(getattr(mo_input, "Input_20"), "value", text="Width")
                            box.prop(getattr(mo_input, "Input_21"), "value", text="Height")
                        else:
                            box.prop(getattr(mo_input, "Input_18"), "value", text="Radius")
                            box.prop(getattr(mo_input, "Input_19"), "value", text="Resolution")


                    # HANDRAIL

                    box = layout.box()
                    input_index = "Input_22"
                    if mo_input[input_index]["value"] == gn_bool_version(1):
                        props = box.operator('switch.button', text='Handrail', depress = True)
                    else:
                        box.scale_y = 2
                        props = box.operator('switch.button', text='Handrail', depress = False)
                    props.index = input_index
                    if mo_input[input_index]["value"] == gn_bool_version(1):
                        box = box.column(align=True)
                            
                        row = box.row(align=True)
                        row.label(text="Profile")
                        input_index = "Input_23"
                        if mo_input[input_index]["value"] == gn_bool_version(1):
                            props = row.operator('switch.button', text=' ', depress = True, icon = 'MESH_PLANE')
                        else:
                            props = row.operator('switch.button', text=' ', depress = False, icon = 'MESH_PLANE')
                        props.index = input_index
                        if mo_input[input_index]["value"] == gn_bool_version(1):
                            props = row.operator('switch.button', text=' ', depress = False, icon = 'MESH_CIRCLE')
                        else:
                            props = row.operator('switch.button', text=' ', depress = True, icon = 'MESH_CIRCLE')
                        props.index = input_index

                        box = box.column(align=True)
                        if mo_input[input_index]["value"] == gn_bool_version(1):
                            box.prop(getattr(mo_input, "Input_26"), "value", text="Width")
                            box.prop(getattr(mo_input, "Input_27"), "value", text="Height")
                        else:
                            box.prop(getattr(mo_input, "Input_24"), "value", text="Radius")
                            box.prop(getattr(mo_input, "Input_25"), "value", text="Resolution")
                        box.prop(getattr(mo_input, "Input_28"), "value", text="Curve Resolution")


                    # HORIZONTAL BALUSTER

                    box = layout.box()
                    input_index = "Input_33"
                    if mo_input[input_index]["value"] == gn_bool_version(1):
                        props = box.operator('switch.button', text='Horizontal Baluster', depress = True)
                    else:
                        box.scale_y = 2
                        props = box.operator('switch.button', text='Horizontal Baluster', depress = False)
                    props.index = input_index
                    if mo_input[input_index]["value"] == gn_bool_version(1):
                        box = box.column(align=True)
                            
                        row = box.row(align=True)
                        row.label(text="Profile")
                        input_index = "Input_36"
                        if mo_input[input_index]["value"] == gn_bool_version(1):
                            props = row.operator('switch.button', text=' ', depress = True, icon = 'MESH_PLANE')
                        else:
                            props = row.operator('switch.button', text=' ', depress = False, icon = 'MESH_PLANE')
                        props.index = input_index
                        if mo_input[input_index]["value"] == gn_bool_version(1):
                            props = row.operator('switch.button', text=' ', depress = False, icon = 'MESH_CIRCLE')
                        else:
                            props = row.operator('switch.button', text=' ', depress = True, icon = 'MESH_CIRCLE')
                        props.index = input_index

                        box = box.column(align=True)
                        if mo_input[input_index]["value"] == gn_bool_version(1):
                            box.prop(getattr(mo_input, "Input_39"), "value", text="Width")
                            box.prop(getattr(mo_input, "Input_40"), "value", text="Height")
                        else:
                            box.prop(getattr(mo_input, "Input_38"), "value", text="Radius")
                            box.prop(getattr(mo_input, "Input_37"), "value", text="Resolution")
                        box.prop(getattr(mo_input, "Input_35"), "value", text="Curve Resolution")
                        box.prop(getattr(mo_input, "Input_41"), "value", text="Offset Z")
                        box.prop(getattr(mo_input, "Input_42"), "value", text="Distance")
                        box.prop(getattr(mo_input, "Input_43"), "value", text="Count")
                        box.prop(getattr(mo_input, "Input_45"), "value", text="Offset")


                    # MATERIAL
                    box = layout.box()
                    box = box.column(align=True)
                    box.label(text="Material", icon = "MATERIAL")
                    box.prop_search(getattr(mo_input, "Input_31"), "value", bpy.data, "materials", text="Glass", icon="MATERIAL")
                    box.prop_search(getattr(mo_input, "Input_46"), "value", bpy.data, "materials", text="Glass Connector", icon="MATERIAL")
                    box.prop_search(getattr(mo_input, "Input_29"), "value", bpy.data, "materials", text="Baluster", icon="MATERIAL")
                    box.prop_search(getattr(mo_input, "Input_30"), "value", bpy.data, "materials", text="Handrail", icon="MATERIAL")
                    box.prop_search(getattr(mo_input, "Input_44"), "value", bpy.data, "materials", text="Baluster", icon="MATERIAL")

                elif mo_type == "door":
                    modifier_header_basic(col)

                    modifier = obj.modifiers[modifiers[0]]
                    mo_input = modifier.properties.inputs

                    # MAIN
                    box = layout.box()
                    box.label(text="Main")
                    box = box.column(align=True)
                    box.prop(getattr(mo_input, "Socket_46"), "value", text="Global Offset")
                    box.prop(getattr(mo_input, "Socket_27"), "value", text="Depth")
                    box.prop(getattr(mo_input, "Socket_63"), "value", text="Door Offset")

                    child_door_bool = None
                    for child in obj.children:
                        if child.name.startswith("BagaPie_Door_Bool") and child.data == obj.data:
                            child_door_bool=child
                            break
                        elif child.data == obj.data:
                            child_door_bool=child
                            break
                        elif child.name.startswith("BagaPie_Door_Bool"):
                            child_door_bool=child
                            break
                    
                    if child_door_bool:
                        solidify_modifier = next((mod for mod in child_door_bool.modifiers if mod.type == 'SOLIDIFY'), None)
                        if solidify_modifier:
                            box.prop(solidify_modifier, "thickness", text="Boolean Thickness")

                    # DOOR
                    box = layout.box()
                    box.label(text="Door")

                    # Regroupement des boutons
                    input_index = "Socket_10"
                    props = box.operator('switch.button', text='Double/Simple', depress=not mo_input[input_index]["value"])
                    props.index = input_index

                    input_index = "Socket_11"
                    props = box.operator('switch.button', text='Flip Side')
                    props.index = input_index

                    input_index = "Socket_76"
                    props = box.operator('switch.button', text='Flip Wall Side', icon="LOOP_BACK")
                    props.index = input_index


                    col = box.column(align=True)
                    col.prop(getattr(mo_input, "Socket_47"), "value", text="Thickness")
                    col.prop(getattr(mo_input, "Socket_37"), "value", text="Random Opening")
                    col.prop(getattr(mo_input, "Socket_7"), "value", text="Opening")

                    col.separator(factor=2)
                    col.label(text="Tweak this if few Shutters fail")
                    col.prop(getattr(mo_input, "Socket_12"), "value", text="Min Height")


                    # DOOR FRAME
                    box = layout.box()
                    input_index = "Socket_23"
                    if mo_input[input_index]["value"]:
                        props = box.operator('switch.button', text='Door Frame', depress=True)
                    else:
                        box.scale_y = 2
                        props = box.operator('switch.button', text='Door Frame', depress=False)
                    props.index = input_index

                    if mo_input[input_index]["value"]:
                        col = box.column(align=True)
                        row = col.row(align=True)
                        row.prop(getattr(mo_input, "Socket_69"), "value", text="A")
                        row.prop(getattr(mo_input, "Socket_70"), "value", text="B")
                        row = col.row(align=True)
                        row.prop(getattr(mo_input, "Socket_71"), "value", text="C")
                        row.prop(getattr(mo_input, "Socket_72"), "value", text="D")

                    # WALL FRAME
                    box = layout.box()
                    input_index = "Socket_19"
                    if mo_input[input_index]["value"]:
                        props = box.operator('switch.button', text='Wall Frame', depress=True)
                    else:
                        box.scale_y = 2
                        props = box.operator('switch.button', text='Wall Frame', depress=False)
                    props.index = input_index

                    if mo_input[input_index]["value"]:
                        col = box.column(align=True)
                        col.prop(getattr(mo_input, "Socket_45"), "value", text="Frame Thickness")

                    # HANDLE
                    box = layout.box()
                    input_index = "Socket_66"
                    if mo_input[input_index]["value"]:
                        props = box.operator('switch.button', text='Handle', depress=True)
                    else:
                        box.scale_y = 2
                        props = box.operator('switch.button', text='Handle', depress=False)
                    props.index = input_index

                    if mo_input[input_index]["value"]:
                        col = box.column(align=True)
                        col.label(text="Handle Type")
                        col.prop(getattr(mo_input, "Socket_75"), "value", text="")
                        if getattr(mo_input, "Socket_75")["value"] == 3:
                            box.prop_search(getattr(mo_input, "Socket_74"), "value", bpy.data, "collections", text="Coll", icon="OUTLINER_COLLECTION")
                        elif getattr(mo_input, "Socket_75")["value"] == 0:
                            col.prop(getattr(mo_input, "Socket_80"), "value", text="Position X")
                            col.prop(getattr(mo_input, "Socket_77"), "value", text="Top Offset")
                            col.prop(getattr(mo_input, "Socket_78"), "value", text="Bottom Offset")
                            col.prop(getattr(mo_input, "Socket_79"), "value", text="Radius")
                        elif getattr(mo_input, "Socket_75")["value"] == 1 or 2:
                            col.prop(getattr(mo_input, "Socket_80"), "value", text="Position X")
                            col.prop(getattr(mo_input, "Socket_81"), "value", text="Position Y")
                    

                    # HINGE
                    box = layout.box()
                    input_index = "Socket_14"
                    if mo_input[input_index]["value"]:
                        props = box.operator('switch.button', text='Hinge', depress=True)
                    else:
                        box.scale_y = 2
                        props = box.operator('switch.button', text='Hinge', depress=False)
                    props.index = input_index

                    if mo_input[input_index]["value"]:
                        col = box.column(align=True)
                        col.prop(getattr(mo_input, "Socket_73"), "value", text="Offset")

                    # MATERIALS
                    box = layout.box()
                    box.label(text="Materials", icon="MATERIAL")
                    col = box.column(align=True)
                    col.prop_search(getattr(mo_input, "Socket_65"), "value", bpy.data, "materials", text="Door", icon="MATERIAL")
                    col.prop_search(getattr(mo_input, "Socket_32"), "value", bpy.data, "materials", text="Frame", icon="MATERIAL")
                    col.prop_search(getattr(mo_input, "Socket_36"), "value", bpy.data, "materials", text="Door Frame", icon="MATERIAL")
                    col.prop_search(getattr(mo_input, "Socket_64"), "value", bpy.data, "materials", text="Handle", icon="MATERIAL")
                    col.prop_search(getattr(mo_input, "Socket_35"), "value", bpy.data, "materials", text="Hinge", icon="MATERIAL")

                elif mo_type == "window_v2":
                    modifier_header_basic(col)
                    box = layout.box()
                    box.label(text="Main", icon=icon)

                    modifier = obj.modifiers[modifiers[0]]
                    mo_input = modifier.properties.inputs

                    box = box.column(align=True)
                    box.prop(getattr(mo_input, "Socket_46"), "value", text="Global Offset")
                    box.prop(getattr(mo_input, "Socket_27"), "value", text="Depth")
                    box.prop(getattr(mo_input, "Socket_63"), "value", text="Windows Offset")

                    child_win_bool = None
                    for child in obj.children:
                        if child.name.startswith("BagaPie_Window_Bool") and child.data == obj.data:
                            child_win_bool=child
                            break
                        elif child.data == obj.data:
                            child_win_bool=child
                            break
                        elif child.name.startswith("BagaPie_Window_Bool"):
                            child_win_bool=child
                            break
                    
                    if child_win_bool:
                        solidify_modifier = next((mod for mod in child_win_bool.modifiers if mod.type == 'SOLIDIFY'), None)
                        if solidify_modifier:
                            box.prop(solidify_modifier, "thickness", text="Boolean Thickness")
                            box.prop(solidify_modifier, "offset", text="Boolean Offset")

                    # REVEAL THICKNESS
                    box = layout.box()
                    input_index = "Socket_19"
                    if mo_input[input_index]["value"]:
                        props = box.operator('switch.button', text='Reveal Thickness', depress=True)
                    else:
                        box.scale_y = 2
                        props = box.operator('switch.button', text='Reveal Thickness', depress=False)
                    props.index = input_index

                    if mo_input[input_index]["value"]:
                        col = box.column(align=True)
                        col.prop(getattr(mo_input, "Socket_45"), "value", text="Reveal Thickness")

                    # GLASS
                    box = layout.box()
                    input_index = "Socket_21"
                    if mo_input[input_index]["value"]:
                        props = box.operator('switch.button', text='Glass', depress=True)
                    else:
                        box.scale_y = 2
                        props = box.operator('switch.button', text='Glass', depress=False)
                    props.index = input_index

                    if mo_input[input_index]["value"]:
                        col = box.column(align=True)
                        col.prop(getattr(mo_input, "Socket_29"), "value", text="Offset Glass")

                    # FRAME
                    box = layout.box()
                    input_index = "Socket_22"
                    if mo_input[input_index]["value"]:
                        props = box.operator('switch.button', text='Frame', depress=True)
                    else:
                        box.scale_y = 2
                        props = box.operator('switch.button', text='Frame', depress=False)
                    props.index = input_index

                    if mo_input[input_index]["value"]:
                        col = box.column(align=True)
                        # Regroupement des propriétés Width et Height
                        row = col.row(align=True)
                        row.prop(getattr(mo_input, "Socket_2"), "value", text="Width")
                        row.prop(getattr(mo_input, "Socket_3"), "value", text="Height")
                        col.prop(getattr(mo_input, "Socket_24"), "value", text="Bevel")
                        # Regroupement des propriétés Count Vertical et Count Horizontal
                        row = col.row(align=True)
                        row.prop(getattr(mo_input, "Socket_4"), "value", text="Count Vertical")
                        row.prop(getattr(mo_input, "Socket_5"), "value", text="Count Horizontal")

                    # CASING
                    box = layout.box()
                    input_index = "Socket_23"
                    if mo_input[input_index]["value"]:
                        props = box.operator('switch.button', text='Casing', depress=True)
                    else:
                        box.scale_y = 2
                        props = box.operator('switch.button', text='Casing', depress=False)
                    props.index = input_index

                    if mo_input[input_index]["value"]:
                        col = box.column(align=True)
                        # Regroupement des propriétés Width 1 et Thickness 1
                        row = col.row(align=True)
                        row.prop(getattr(mo_input, "Socket_17"), "value", text="Width")
                        row.prop(getattr(mo_input, "Socket_18"), "value", text="Thickness")
                        # Regroupement des propriétés Bevel Radius et Bevel Count
                        row = col.row(align=True)
                        row.prop(getattr(mo_input, "Socket_26"), "value", text="Bevel Radius")
                        row.prop(getattr(mo_input, "Socket_38"), "value", text="Bevel Count")
                        col.prop(getattr(mo_input, "Socket_28"), "value", text="Offset")

                        col.separator(factor=0.5)
                        input_index = "Socket_20"
                        if mo_input[input_index]["value"]:
                            props = col.operator('switch.button', text='Casing 2', depress=True)
                        else:
                            props = col.operator('switch.button', text='Casing 2', depress=False)
                        props.index = input_index
                        
                        if mo_input[input_index]["value"]:
                            # Regroupement des propriétés Width 2 et Thickness 2
                            row = col.row(align=True)
                            row.prop(getattr(mo_input, "Socket_15"), "value", text="Width")
                            row.prop(getattr(mo_input, "Socket_16"), "value", text="Thickness")
                            # Regroupement des propriétés Bevel et Bevel Count
                            row = col.row(align=True)
                            row.prop(getattr(mo_input, "Socket_25"), "value", text="Bevel")
                            row.prop(getattr(mo_input, "Socket_62"), "value", text="Bevel Count")
                            col.prop(getattr(mo_input, "Socket_61"), "value", text="Offset")

                    # SHUTTERS
                    box = layout.box()
                    input_index = "Socket_14"
                    if mo_input[input_index]["value"]:
                        props = box.operator('switch.button', text='Shutters', depress=True)
                    else:
                        box.scale_y = 2
                        props = box.operator('switch.button', text='Shutters', depress=False)
                    props.index = input_index

                    if mo_input[input_index]["value"]:
                        col = box.column(align=True)
                        
                        col.label(text="May fail on some shapes !")
                        col.separator(factor=1)

                        row = col.row(align=True)
                        row.scale_y = 1.5
                        row.operator('switch.button', text='Simple', depress=mo_input["Socket_10"]["value"]).index = "Socket_10"
                        row.operator('switch.button', text='Double', depress=not mo_input["Socket_10"]["value"]).index = "Socket_10"
                        
                        if modifier['Socket_10']:
                            props = col.operator('switch.button', text='Flip Side')
                            props.index = "Socket_11"

                        col.separator(factor=0.5)


                        col.prop(getattr(mo_input, "Socket_6"), "value", text="Slide")
                        col.prop(getattr(mo_input, "Socket_9"), "value", text="Length Factor")

                        col.prop(getattr(mo_input, "Socket_7"), "value", text="Opening")
                        col.prop(getattr(mo_input, "Socket_37"), "value", text="Random Opening")



                        col.separator(factor=4)

                        row=col.row(align=True)
                        row.scale_y = 1.5
                        props = row.operator('switch.button', text='Louvered', depress=mo_input["Socket_49"]["value"])
                        props.index = "Socket_49"
                        props = row.operator('switch.button', text='Solid', depress=not mo_input["Socket_49"]["value"])
                        props.index = "Socket_49"

                        col.separator(factor=2)

                        if modifier['Socket_49']:
                            col.label(text="Louvers:")
                            row=col.row(align=True)
                            row.scale_y = 1.2
                            props = row.operator('switch.button', text='Count', depress=not mo_input["Socket_58"]["value"])
                            props.index = "Socket_58"
                            props = row.operator('switch.button', text='Distance', depress=mo_input["Socket_58"]["value"])
                            props.index = "Socket_58"

                            # Séparation des propriétés Verticales
                            col.label(text="Vertical:")
                            row = col.row(align=True)
                            row.prop(getattr(mo_input, "Socket_50"), "value", text="Thickness")
                            row.prop(getattr(mo_input, "Socket_51"), "value", text="Width")
                            if modifier['Socket_58']:
                                col.prop(getattr(mo_input, "Socket_59"), "value", text="Distance")
                            else:
                                col.prop(getattr(mo_input, "Socket_52"), "value", text="Count")
                            # Séparation des propriétés Horizontales
                            col.label(text="Horizontal:")
                            row = col.row(align=True)
                            row.prop(getattr(mo_input, "Socket_54"), "value", text="Thickness")
                            row.prop(getattr(mo_input, "Socket_55"), "value", text="Width")
                            if modifier['Socket_58']:
                                col.prop(getattr(mo_input, "Socket_60"), "value", text="Distance")
                            else:
                                col.prop(getattr(mo_input, "Socket_53"), "value", text="Count")

                            col.prop(getattr(mo_input, "Socket_30"), "value", text="Angle")

                            col.separator(factor=0.5)

                            props = col.operator('switch.button', text='Frame', depress=mo_input["Socket_13"]["value"])
                            props.index = "Socket_13"
                            if modifier['Socket_13']:
                                col.prop(getattr(mo_input, "Socket_56"), "value", text="Thickness")
                                col.prop(getattr(mo_input, "Socket_57"), "value", text="Width")

                        else:    
                            col.prop(getattr(mo_input, "Socket_47"), "value", text="Thickness")
                            col.prop(getattr(mo_input, "Socket_48"), "value", text="Scale")

                        col.separator(factor=2)
                        col.label(text="Tweak this if few Shutters fail")
                        col.prop(getattr(mo_input, "Socket_12"), "value", text="Min Height")

                    # MATERIAL
                    box = layout.box()
                    box = box.column(align=True)
                    box.label(text="Material", icon="MATERIAL")
                    box.prop_search(getattr(mo_input, "Socket_31"), "value", bpy.data, "materials", text="Frame", icon="MATERIAL")
                    box.prop_search(getattr(mo_input, "Socket_32"), "value", bpy.data, "materials", text="Casing", icon="MATERIAL")
                    box.prop_search(getattr(mo_input, "Socket_33"), "value", bpy.data, "materials", text="Glass", icon="MATERIAL")
                    box.prop_search(getattr(mo_input, "Socket_35"), "value", bpy.data, "materials", text="Shutters", icon="MATERIAL")
                    box.prop_search(getattr(mo_input, "Socket_36"), "value", bpy.data, "materials", text="Reveal", icon="MATERIAL")

                elif mo_type == "fence":
                    modifier_header_basic(col)

                    # MAIN

                    box = layout.box()
                    box.label(text="Main", icon=icon)

                    modifier = obj.modifiers[modifiers[0]]
                    mo_input = modifier.properties.inputs

                    box = box.column(align=True)
                    box.prop(getattr(mo_input, "Input_5"), "value", text="Height")
                    box.prop(getattr(mo_input, "Input_4"), "value", text="Fence Offset")
                    row = box.row(align=True)
                    input_index = "Input_54"
                    if mo_input[input_index]["value"] == gn_bool_version(1):
                        props = row.operator('switch.button', text='Curve', depress = False, icon = 'OUTLINER_OB_CURVE')
                    else:
                        props = row.operator('switch.button', text='Curve', depress = True, icon = 'OUTLINER_OB_CURVE')
                    props.index = input_index
                    if mo_input[input_index]["value"] == gn_bool_version(0):
                        props = row.operator('switch.button', text='Poly', depress = False, icon = 'OUTLINER_OB_MESH')
                    else:
                        props = row.operator('switch.button', text='Poly', depress = True, icon = 'OUTLINER_OB_MESH')
                    props.index = input_index
                    
                    # BASE WALL

                    box = layout.box()
                    box = box.column() #lol
                    row = box.row()
                    input_index = "Input_35"
                    if mo_input[input_index]["value"] == gn_bool_version(1):
                        props = row.operator('switch.button', text='Wall', depress = True)
                    else:
                        row.scale_y = 2
                        props = row.operator('switch.button', text='Wall', depress = False)
                    props.index = input_index

                    if mo_input[input_index]["value"] == gn_bool_version(1):
                        col = box.column(align=True)
                        col.prop(getattr(mo_input, "Input_2"), "value", text="Height")
                        col.prop(getattr(mo_input, "Input_3"), "value", text="Width")
                        
                        input_index = "Input_51"
                        if mo_input[input_index]["value"] == gn_bool_version(1):
                            props = col.operator('switch.button', text='Even Thickness', depress = True)
                        else:
                            props = col.operator('switch.button', text='Even Thickness', depress = False)
                        props.index = input_index
                        
                        col.separator(factor=1.5)
                        col = box.column(align=True)
                        input_index = "Input_44"
                        if mo_input[input_index]["value"] == gn_bool_version(1):
                            props = col.operator('switch.button', text='Cap Flashing', depress = True)
                        else:
                            props = col.operator('switch.button', text='Cap Flashing', depress = False)
                        props.index = input_index
                        if mo_input[input_index]["value"] == gn_bool_version(1):
                            col.prop(getattr(mo_input, "Input_37"), "value", text="Height")
                            col.prop(getattr(mo_input, "Input_38"), "value", text="Thickness")
                        
                        col.separator(factor=1.5)
                        col = box.column(align=True)
                        input_index = "Input_53"
                        if mo_input[input_index]["value"] == gn_bool_version(1):
                            props = col.operator('switch.button', text='Auto Smooth', depress = True)
                        else:
                            props = col.operator('switch.button', text='Auto Smooth', depress = False)
                        props.index = input_index
                        if mo_input[input_index]["value"] == gn_bool_version(1):
                            col.prop(getattr(mo_input, "Input_52"), "value", text="Angle")

                    # FENCE VERTICAL

                    box = layout.box()
                    box = box.column() #lol
                    row = box.row()
                    input_index = "Input_42"
                    if mo_input[input_index]["value"] == gn_bool_version(1):
                        props = row.operator('switch.button', text='Fence Vertical', depress = True)
                    else:
                        row.scale_y = 2
                        props = row.operator('switch.button', text='Fence Vertical', depress = False)
                    props.index = input_index

                    if mo_input[input_index]["value"] == gn_bool_version(1):
                        col = box.column(align=True)
                        col.prop(getattr(mo_input, "Input_14"), "value", text="Distance")
                        col.prop(getattr(mo_input, "Input_36"), "value", text="End Wall Offset")
                        col.prop(getattr(mo_input, "Input_55"), "value", text="Offset")
                        col.prop(getattr(mo_input, "Input_15"), "value", text="Scale")
                        col.prop(getattr(mo_input, "Input_16"), "value", text="Scale Random")
                        col.prop(getattr(mo_input, "Input_34"), "value", text="Scale Z Random")
                        
                        col = box.column(align=True)
                        col.prop(getattr(mo_input, "Input_6"), "value", text="Rotation")
                        col.prop(getattr(mo_input, "Input_7"), "value", text="Random Tangent")
                        col.prop(getattr(mo_input, "Input_50"), "value", text="Random Axis")

                        col = box.column(align=True)
                        row = col.row(align=True)
                        row.label(text="Profile")
                        input_index = "Input_8"
                        if mo_input[input_index]["value"] == gn_bool_version(1):
                            props = row.operator('switch.button', text=' ', depress = False, icon = 'MESH_PLANE')
                        else:
                            props = row.operator('switch.button', text=' ', depress = True, icon = 'MESH_PLANE')
                        props.index = input_index
                        if mo_input[input_index]["value"] == gn_bool_version(1):
                            props = row.operator('switch.button', text=' ', depress = True, icon = 'MESH_CIRCLE')
                        else:
                            props = row.operator('switch.button', text=' ', depress = False, icon = 'MESH_CIRCLE')
                        props.index = input_index

                        if mo_input[input_index]["value"] == gn_bool_version(1):
                            col.prop(getattr(mo_input, "Input_13"), "value", text="Radius")
                            col.prop(getattr(mo_input, "Input_12"), "value", text="Resolution")
                        else:
                            col.prop(getattr(mo_input, "Input_10"), "value", text="Width")
                            col.prop(getattr(mo_input, "Input_11"), "value", text="Height")

                    # TIMBER POST

                    box = layout.box()
                    input_index = "Input_39"
                    if mo_input[input_index]["value"] == gn_bool_version(1):
                        props = box.operator('switch.button', text='Timber Post', depress = True)
                    else:
                        box.scale_y = 2
                        props = box.operator('switch.button', text='Timber Post', depress = False)
                    props.index = input_index
                    if mo_input[input_index]["value"] == gn_bool_version(1):
                        col = box.column(align=True)
                        col.prop(getattr(mo_input, "Input_17"), "value", text="Spacing")
                        col.prop(getattr(mo_input, "Input_18"), "value", text="Height")
                        col.prop(getattr(mo_input, "Input_32"), "value", text="Offset")
                            
                        col = box.column(align=True)
                        row = col.row(align=True)
                        row.label(text="Profile")
                        input_index = "Input_19"
                        if mo_input[input_index]["value"] == gn_bool_version(1):
                            props = row.operator('switch.button', text=' ', depress = False, icon = 'MESH_PLANE')
                        else:
                            props = row.operator('switch.button', text=' ', depress = True, icon = 'MESH_PLANE')
                        props.index = input_index
                        if mo_input[input_index]["value"] == gn_bool_version(1):
                            props = row.operator('switch.button', text=' ', depress = True, icon = 'MESH_CIRCLE')
                        else:
                            props = row.operator('switch.button', text=' ', depress = False, icon = 'MESH_CIRCLE')
                        props.index = input_index

                        if mo_input[input_index]["value"] == gn_bool_version(1):
                            col.prop(getattr(mo_input, "Input_23"), "value", text="Radius")
                            col.prop(getattr(mo_input, "Input_22"), "value", text="Resolution")
                        else:
                            col.prop(getattr(mo_input, "Input_20"), "value", text="Width")
                            col.prop(getattr(mo_input, "Input_21"), "value", text="Height")
                        
                        col.separator(factor=1.5)
                        col = box.column(align=True)
                        input_index = "Input_40"
                        if mo_input[input_index]["value"] == gn_bool_version(1):
                            props = col.operator('switch.button', text='Fixation', depress = True)
                        else:
                            props = col.operator('switch.button', text='Fixation', depress = False)
                        props.index = input_index
                        if mo_input[input_index]["value"] == gn_bool_version(1):
                            col.prop(getattr(mo_input, "Input_33"), "value", text="Dimmensions")

                    # HORIZONTAL

                    box = layout.box()
                    input_index = "Input_43"
                    if mo_input[input_index]["value"] == gn_bool_version(1):
                        props = box.operator('switch.button', text='Horizontal', depress = True)
                    else:
                        box.scale_y = 2
                        props = box.operator('switch.button', text='Horizontal', depress = False)
                    props.index = input_index
                    if mo_input[input_index]["value"] == gn_bool_version(1):
                        col = box.column(align=True)
                        col.prop(getattr(mo_input, "Input_29"), "value", text="Base Offset")
                        col.prop(getattr(mo_input, "Input_30"), "value", text="Top Offset")


                        row = col.row(align=True)
                        input_index = "Input_41"
                        if mo_input[input_index]["value"] == gn_bool_version(1):
                            props = row.operator('switch.button', text='Full', depress = True, icon = 'SNAP_FACE')
                        else:
                            props = row.operator('switch.button', text='Full', depress = False, icon = 'SNAP_FACE')
                        props.index = input_index
                        if mo_input[input_index]["value"] == gn_bool_version(1):
                            props = row.operator('switch.button', text='Wire', depress = False, icon = 'ALIGN_JUSTIFY')
                        else:
                            props = row.operator('switch.button', text='Wire', depress = True, icon = 'ALIGN_JUSTIFY')
                        props.index = input_index
                        
                        if mo_input[input_index]["value"] == gn_bool_version(0):
                            col.prop(getattr(mo_input, "Input_31"), "value", text="Count")
                            
                            col = box.column(align=True)
                            row = col.row(align=True)
                            row.label(text="Profile")
                            input_index = "Input_24"
                            if mo_input[input_index]["value"] == gn_bool_version(1):
                                props = row.operator('switch.button', text=' ', depress = False, icon = 'MESH_PLANE')
                            else:
                                props = row.operator('switch.button', text=' ', depress = True, icon = 'MESH_PLANE')
                            props.index = input_index
                            if mo_input[input_index]["value"] == gn_bool_version(1):
                                props = row.operator('switch.button', text=' ', depress = True, icon = 'MESH_CIRCLE')
                            else:
                                props = row.operator('switch.button', text=' ', depress = False, icon = 'MESH_CIRCLE')
                            props.index = input_index

                            if mo_input[input_index]["value"] == gn_bool_version(1):
                                col.prop(getattr(mo_input, "Input_28"), "value", text="Radius")
                                col.prop(getattr(mo_input, "Input_27"), "value", text="Resolution")
                            else:
                                col.prop(getattr(mo_input, "Input_25"), "value", text="Width")
                                col.prop(getattr(mo_input, "Input_26"), "value", text="Height")


                    # MATERIAL
                    box = layout.box()
                    box = box.column(align=True)
                    box.label(text="Material", icon = "MATERIAL")
                    box.prop_search(getattr(mo_input, "Input_45"), "value", bpy.data, "materials", text="Wall", icon="MATERIAL")
                    box.prop_search(getattr(mo_input, "Input_46"), "value", bpy.data, "materials", text="Cap Flashing", icon="MATERIAL")
                    box.prop_search(getattr(mo_input, "Input_47"), "value", bpy.data, "materials", text="Fence", icon="MATERIAL")
                    box.prop_search(getattr(mo_input, "Input_48"), "value", bpy.data, "materials", text="Main Support", icon="MATERIAL")
                    box.prop_search(getattr(mo_input, "Input_49"), "value", bpy.data, "materials", text="Support", icon="MATERIAL")

                    
                    # THANKS
                    box = layout.box()
                    box = box.column(align=True)
                    box.label(text="Thanks !", icon = "FUND")
                    box.label(text="Thanks to Zeroskilz.")
                    box.label(text="He created the Curve to Mesh")
                    box.label(text="Even Thickness node !")

                elif mo_type == "siding":
                    modifier_header_basic(col)

                    box = layout.box()
                    box.label(text="Main", icon='FACESEL')
                    col = box.column(align=True)
                    col.scale_y = 2
                    modifier = obj.modifiers[modifiers[0]]
                    mo_input = modifier.properties.inputs

                    input_index = "Input_19"
                    if mo_input[input_index]["value"] == gn_bool_version(1):
                        props = col.operator('switch.button', text='Keep Original', depress = True)
                    else:
                        props = col.operator('switch.button', text='Keep Original', depress = False)
                    props.index = input_index
                    
                    # X

                    box = layout.box()
                    box.label(text="X", icon=icon)
                    col = box.column(align=True)

                    modifier = obj.modifiers[modifiers[0]]
                    input_index = "Input_6"
                    if mo_input[input_index]["value"] == gn_bool_version(1):
                        props = col.operator('switch.button', text='X Axis', depress = True)
                    else:
                        col.scale_y = 2
                        props = col.operator('switch.button', text='X Axis', depress = False)
                    props.index = input_index

                    if mo_input[input_index]["value"] == gn_bool_version(1):
                        col = box.column(align=True)
                        col.prop(getattr(mo_input, "Input_10"), "value", text="Distance")
                        col.prop(getattr(mo_input, "Input_11"), "value", text="Width")
                        col.prop(getattr(mo_input, "Input_12"), "value", text="Thickness")
                        col.prop(getattr(mo_input, "Input_16"), "value", text="Angle")
                    
                    # Y

                    box = layout.box()
                    box.label(text="Y", icon=icon)
                    col = box.column(align=True)

                    modifier = obj.modifiers[modifiers[0]]
                    input_index = "Input_7"
                    if mo_input[input_index]["value"] == gn_bool_version(1):
                        props = col.operator('switch.button', text='Y Axis', depress = True)
                    else:
                        col.scale_y = 2
                        props = col.operator('switch.button', text='Y Axis', depress = False)
                    props.index = input_index

                    if mo_input[input_index]["value"] == gn_bool_version(1):
                        col = box.column(align=True)
                        col.prop(getattr(mo_input, "Input_9"), "value", text="Distance")
                        col.prop(getattr(mo_input, "Input_13"), "value", text="Width")
                        col.prop(getattr(mo_input, "Input_14"), "value", text="Thickness")
                        col.prop(getattr(mo_input, "Input_17"), "value", text="Angle")

                    # Z

                    box = layout.box()
                    box.label(text="Z", icon=icon)
                    col = box.column(align=True)

                    modifier = obj.modifiers[modifiers[0]]
                    input_index = "Input_8"
                    if mo_input[input_index]["value"] == gn_bool_version(1):
                        props = col.operator('switch.button', text='Z Axis', depress = True)
                    else:
                        col.scale_y = 2
                        props = col.operator('switch.button', text='Z Axis', depress = False)
                    props.index = input_index

                    if mo_input[input_index]["value"] == gn_bool_version(1):
                        col = box.column(align=True)
                        col.prop(getattr(mo_input, "Input_4"), "value", text="Distance")
                        col.prop(getattr(mo_input, "Input_3"), "value", text="Width")
                        col.prop(getattr(mo_input, "Input_2"), "value", text="Thickness")
                        col.prop(getattr(mo_input, "Input_15"), "value", text="Angle")

                    # MATERIAL
                    box = layout.box()
                    box = box.column(align=True)
                    box.label(text="Material", icon = "MATERIAL")
                    box.prop_search(getattr(mo_input, "Input_18"), "value", bpy.data, "materials", text="", icon="MATERIAL")

                elif mo_type == "cable":
                    modifier_header_basic(col)
                    modifier = obj.modifiers[modifiers[0]]
                    mo_input = modifier.properties.inputs

                    add_remove_ui(col, "Input_28")

                    # SHAPE
                    box = layout.box()
                    box.label(text="Shape", icon=icon)

                    col = box.column(align=True)
                    col.prop(getattr(mo_input, "Input_2"), "value", text="Gravity")
                    col.prop(getattr(mo_input, "Input_29"), "value", text="Rigidity")
                    col.prop(getattr(mo_input, "Input_8"), "value", text="Resolution")
                    col.prop(getattr(mo_input, "Input_7"), "value", text="Smooth")

                    col = box.column(align=True)
                    col.prop(getattr(mo_input, "Input_4"), "value", text="Start Offset")
                    col.prop(getattr(mo_input, "Input_5"), "value", text="Start Rigidity")
                    col.prop(getattr(mo_input, "Input_9"), "value", text="Edge Collision")

                    # PROFIL
                    box = layout.box()
                    box.label(text="Profil", icon="PROP_OFF")

                    col = box.column(align=True)
                    col.prop(getattr(mo_input, "Input_11"), "value", text="Radius")
                    col.prop(getattr(mo_input, "Input_12"), "value", text="Cable Count")
                    col.prop(getattr(mo_input, "Input_6"), "value", text="Cable Radius")
                    col.prop(getattr(mo_input, "Input_13"), "value", text="Rotation")
                    col.prop(getattr(mo_input, "Input_10"), "value", text="Resolution")

                    # RANDOM
                    box = layout.box()
                    box.label(text="Randomize")

                    col = box.column(align=True)
                    col.prop(getattr(mo_input, "Input_14"), "value", text="Radius Noise")
                    col.prop(getattr(mo_input, "Input_18"), "value", text="Radius Noise Scale")
                    col = box.column(align=True)
                    col.prop(getattr(mo_input, "Input_15"), "value", text="Radius per Curve")
                    col.prop(getattr(mo_input, "Input_16"), "value", text="Radius offset")
                    col = box.column(align=True)
                    col.prop(getattr(mo_input, "Input_17"), "value", text="Tilt Noise")
                    col.prop(getattr(mo_input, "Input_19"), "value", text="Tilt Noise Scale")

                    # FIXATION
                    box = layout.box()
                    input_index = "Input_34"
                    if mo_input[input_index]["value"] == gn_bool_version(1):
                        props = box.operator('switch.button', text='Fixation', depress = True)
                    else:
                        box.scale_y = 2
                        props = box.operator('switch.button', text='Fixation', depress = False)
                    props.index = input_index
                    if mo_input[input_index]["value"] == gn_bool_version(1):
                        row = box.row(align=True)
                        input_index = "Input_23"
                        if mo_input[input_index]["value"] == gn_bool_version(1):
                            props = row.operator('switch.button', text='Procedural', depress = False)
                        else:
                            props = row.operator('switch.button', text='Procedural', depress = True)
                        props.index = input_index
                        if mo_input[input_index]["value"] == gn_bool_version(1):
                            props = row.operator('switch.button', text='Custom', depress = True)
                        else:
                            props = row.operator('switch.button', text='Custom', depress = False)
                        props.index = input_index
                        col = box.column(align=True)
                            
                        if mo_input[input_index]["value"] == gn_bool_version(0):
                            col.prop(getattr(mo_input, "Input_20"), "value", text="Thickness")
                            col.prop(getattr(mo_input, "Input_21"), "value", text="Radius")
                            col.prop(getattr(mo_input, "Input_22"), "value", text="Angle")
                        else:
                            col.prop_search(getattr(mo_input, "Input_24"), "value", bpy.data, "objects", text="", icon="OBJECT_DATA")
                        

                    # RINGS
                    box = layout.box()
                    input_index = "Input_30"
                    if mo_input[input_index]["value"] == gn_bool_version(1):
                        props = box.operator('switch.button', text='Rings', depress = True)
                    else:
                        box.scale_y = 2
                        props = box.operator('switch.button', text='Rings', depress = False)
                    props.index = input_index
                    if mo_input[input_index]["value"] == gn_bool_version(1):
                            col = box.column(align=True)
                            col.prop(getattr(mo_input, "Input_27"), "value", text="Spacing")
                            col.prop(getattr(mo_input, "Input_25"), "value", text="Length")
                            col.prop(getattr(mo_input, "Input_26"), "value", text="Thickness")


                    # MATERIAL
                    box = layout.box()
                    box = box.column(align=True)
                    box.label(text="Material", icon = "MATERIAL")
                    box.prop_search(getattr(mo_input, "Input_33"), "value", bpy.data, "materials", text="Rings", icon="MATERIAL")
                    box.prop_search(getattr(mo_input, "Input_32"), "value", bpy.data, "materials", text="Fix", icon="MATERIAL")
                    box.prop_search(getattr(mo_input, "Input_31"), "value", bpy.data, "materials", text="Curves", icon="MATERIAL")

                elif mo_type == "array":
                    modifier_header_basic(col)
                    array_modifier = obj.modifiers[modifiers[0]]
                    array_type = modifiers[1]
                    array_mo_input = array_modifier.properties.inputs

                    if array_type == 'LINE':
                        col = layout.column(align=True)
                        col.prop(getattr(array_mo_input, "Input_4"), "value", text = "Count")
                        col.prop(getattr(array_mo_input, "Input_3"), "value", text = "Constant Offset")
                        col.prop(getattr(array_mo_input, "Input_5"), "value", text = "Relative Offset")

                        box = layout.box()
                        box.label(text="Random")
                        box.prop(getattr(array_mo_input, "Input_6"), "value", text = "Position")
                        box.prop(getattr(array_mo_input, "Input_7"), "value", text = "Rotation")
                        col = box.column(align=True)
                        col.prop(getattr(array_mo_input, "Input_8"), "value", text = "Scale")
                        box.prop(getattr(array_mo_input, "Input_9"), "value", text = "Seed")

                    if array_type == 'GRID':
                        col = layout.column(align=True)
                        col.prop(getattr(array_mo_input, "Input_2"), "value", text = "Count X")
                        col.prop(getattr(array_mo_input, "Input_9"), "value", text = "Count Y")
                        box = layout.box()
                        col = box.column(align=True)
                        col.prop(getattr(array_mo_input, "Input_3"), "value", text = "Constant Offset X")
                        col.prop(getattr(array_mo_input, "Input_11"), "value", text = "Constant Offset Y")
                        col = box.column(align=True)
                        col.prop(getattr(array_mo_input, "Input_4"), "value", text = "Relative Offset X")
                        col.prop(getattr(array_mo_input, "Input_10"), "value", text = "Relative Offset Y")
                        col = box.column(align=True)
                        col.prop(getattr(array_mo_input, "Input_12"), "value", text = "Midlevel X")
                        col.prop(getattr(array_mo_input, "Input_13"), "value", text = "Midlevel Y")

                        box = layout.box()
                        box.label(text="Random")
                        box.prop(getattr(array_mo_input, "Input_5"), "value", text = "Position")
                        box.prop(getattr(array_mo_input, "Input_6"), "value", text = "Rotation")
                        col = box.column(align=True)
                        col.prop(getattr(array_mo_input, "Input_8"), "value", text = "Scale")
                        box.prop(getattr(array_mo_input, "Input_7"), "value", text = "Seed")

                    if array_type == 'CIRCLE':
                        col = layout.column(align=True)
                        Double_Row_Switch(col, array_modifier, "Input_19", "Count", "Distance")
                        if array_mo_input["Input_19"]["value"] == True:
                            col.prop(getattr(array_mo_input, "Input_20"), "value", text = "Constant Distance")
                            col.prop(getattr(array_mo_input, "Input_2"), "value", text = "Circle Resolution")
                        else:
                            col.prop(getattr(array_mo_input, "Input_2"), "value", text = "Count")
                        col.prop(getattr(array_mo_input, "Input_4"), "value", text = "Radius")

                        col.separator(factor = 0.4)
                        col.prop(getattr(array_mo_input, "Input_3"), "value", text = "Ring Count")
                        col.prop(getattr(array_mo_input, "Input_8"), "value", text = "Ring Offset")
                        col.prop(getattr(array_mo_input, "Input_9"), "value", text = "Ring Offset Z")

                        col.separator(factor = 2)
                        row=col.row()
                        row.prop(getattr(array_mo_input, "Input_14"), "value", text = "Rotation")
                        col.prop(getattr(array_mo_input, "Input_10"), "value", text = "Align to Center", toggle=True)

                        box = layout.box()
                        box.label(text="Random")
                        row=box.row()
                        row.prop(getattr(array_mo_input, "Input_17"), "value", text = "Position")
                        row=box.row()
                        row.prop(getattr(array_mo_input, "Input_15"), "value", text = "Rotation")
                        col = box.column(align=True)
                        col.prop(getattr(array_mo_input, "Input_16"), "value", text = "Scale")
                        box.prop(getattr(array_mo_input, "Input_18"), "value", text = "Seed")
                        
                    if array_type == 'CURVE':
                        col = layout.column(align=True)
                        row = col.row(align=True)
                        input_index = "Input_4"
                        if array_mo_input[input_index]["value"] == gn_bool_version(1):
                            props = row.operator('switch.button', text='Length', depress = False)
                            props = row.operator('switch.button', text='Count', depress = True)
                            col.prop(getattr(array_mo_input, "Input_6"), "value", text = "Count")
                        else:
                            props = row.operator('switch.button', text='Length', depress = True)
                            props = row.operator('switch.button', text='Count', depress = False)
                            col.prop(getattr(array_mo_input, "Input_5"), "value", text = "Length")
                        props.index = input_index

                        col.label(text="Target :")
                        col.prop_search(getattr(array_mo_input, "Input_2"), "value", bpy.data, "objects", text="", icon="OBJECT_DATA")

                        col = layout.column(align=True)
                        col.prop(getattr(array_mo_input, "Input_3"), "value", text = "Rotation")
                        col.prop(getattr(array_mo_input, "Input_14"), "value", text = "Scale")
                        box = layout.box()
                        box.label(text="Random")
                        box.prop(getattr(array_mo_input, "Input_7"), "value", text = "Random Position")
                        box.prop(getattr(array_mo_input, "Input_8"), "value", text = "Random Rotation")
                        box.prop(getattr(array_mo_input, "Input_9"), "value", text = "Random Scale")
                        box.prop(getattr(array_mo_input, "Input_12"), "value", text = "Seed")

                        box = layout.box()
                        box.prop(getattr(array_mo_input, "Input_10"), "value", text = "Align to Vector")
                        box = box.row(align=True)
                        box.prop(getattr(array_mo_input, "Input_11"), "value", text = "Vector")

                    if array_type == 'CURVE_DRAW':
                        col = layout.column(align=True)
                        col.prop_search(getattr(array_mo_input, "Input_2"), "value", bpy.data, "collections", text="Target", icon="OUTLINER_COLLECTION")
                        
                        
                        # ui_type, modifier, index, name_a, name_b
                        Double_Row_Switch(col, array_modifier, "Input_4", "Length", "Count")
                        if array_mo_input["Input_4"]["value"] == gn_bool_version(1):
                            col.prop(getattr(array_mo_input, "Input_6"), "value", text = "Count")
                        else:
                            col.prop(getattr(array_mo_input, "Input_5"), "value", text = "Length")
                        box = layout.box()
                        box.label(text="Rotation")
                        row = box.row(align=True)
                        row.prop(getattr(array_mo_input, "Input_3"), "value", text = "")
                        box.label(text="Position")
                        row = box.row(align=True)
                        row.prop(getattr(array_mo_input, "Input_15"), "value", text = "")
                        box.prop(getattr(array_mo_input, "Input_10"), "value", text = "Align to Curve")
                        col = box.column(align=True)
                        col.label(text="Scale")
                        col.prop(getattr(array_mo_input, "Input_9"), "value", text = "Min")
                        col.prop(getattr(array_mo_input, "Input_14"), "value", text = "Max")
                        box = layout.box()
                        box.label(text="Random")
                        box.label(text="Position")
                        row = box.row(align=True)
                        row.prop(getattr(array_mo_input, "Input_7"), "value", text = "")
                        box.label(text="Rotation")
                        row = box.row(align=True)
                        row.prop(getattr(array_mo_input, "Input_8"), "value", text = "")
                        row = box.row(align=True)
                        row.prop(getattr(array_mo_input, "Input_12"), "value", text = "Seed")

                elif mo_type == "scatter":
                    
                    ######################################
                    # MAIN SETTINGS
                    ######################################
                    modifier_header_basic(col)
                    col.operator("rename.layer", text= "Rename Layer", icon = 'GREASEPENCIL')
                    scatter_modifier = obj.modifiers[modifiers[0]].node_group.nodes[modifiers[1]]
                    
                    col = layout.column(align=True)
                    col.scale_y = 1.2
                    col.prop(scatter_modifier.inputs[2], 'default_value', text = "Distance Min")
                    row = col.row(align=True)
                    row.prop(scatter_modifier.inputs[3], 'default_value', text = "Density Max")
                    tips = row.operator("bagapie.tooltips", text="", depress = False, icon = 'INFO')
                    tips.message = 'Keep this value as low as possible to preserve performance.'
                    col.prop(scatter_modifier.inputs[4], 'default_value', text = "% Viewport Display")
                    col.prop(scatter_modifier.inputs[5], 'default_value', text = "Align Normal")
                    col.prop(scatter_modifier.inputs[6], 'default_value', text = "Seed")

                    ######################################
                    # TOOLS
                    ######################################
                    col_bt = layout.column()
                    col_bt.scale_y = 2
                    col_bt.enabled = (bpy.context.mode == 'OBJECT')
                    col_bt.prop(bagapie_pref, 'scatter_tools', text="Tools", icon='TOOL_SETTINGS', toggle=True)

                    if bagapie_pref.scatter_tools:
                        box = layout.box()
                        col = box.column(align=True)
                        col.scale_y = 2

                        col.separator(factor = 0.4)
                        row = col.row(align=True)
                        if bagapie_pref.asset_source:
                            row.operator("add.asset", text= "Add Assets", icon = 'ADD')
                            tips = row.operator("bagapie.tooltips", text="", depress = False, icon = 'INFO')
                            tips.message = 'Selected objects will be added to the current scatter layer'
                        else: 
                            imp = row.operator("bagapie.asset_browser", text= "Add Assets", icon = 'ADD')
                            imp.import_mode= 'AddAssets'
                            tips = row.operator("bagapie.tooltips", text="", depress = False, icon = 'INFO')
                            tips.message = 'Selected assets in the asset browser will be added to the current scatter layer'

                        row = col.row(align=True)
                        row.scale_y = 0.6
                        split = row.split(factor=0.25, align=True)
                        split.label(text="Source :")
                        split.prop(bagapie_pref, 'asset_source', text = "View 3D",  toggle = True)
                        split.prop(bagapie_pref, 'asset_source', text = "Asset Browser",  toggle = True, invert_checkbox=True)
                        tips = row.operator("bagapie.tooltips", text="", depress = False, icon = 'INFO')
                        tips.message = 'Select the source of the object you want to add to the current scatter layer'

                        col.separator(factor = 0.3)
                        row = col.row(align=True)
                        row.operator("remove.asset", text= "Remove Assets", icon = 'REMOVE')
                        tips = row.operator("bagapie.tooltips", text="", depress = False, icon = 'INFO')
                        tips.message = 'Select the asset(s) you want to remove from the active layer (surface select last)'

                        col.separator(factor = 0.4)
                        
                        if obj.modifiers[modifiers[0]].node_group.nodes.get('BagaPie_Camera_Culling'):
                            row = col.row(align=True)
                            if len(scatter_modifier.inputs[24].links) > 0:
                                props = row.operator('use.cameracullingonlayer', text='Camera Culling', depress = True, icon = 'OUTLINER_OB_CAMERA')
                            else:
                                props = row.operator('use.cameracullingonlayer', text='Use Camera Culling', depress = False, icon = 'CAMERA_DATA')
                            props.index = 24
                            
                        col_contect = col.column(align=True)
                        col_contect.scale_y = 0.6
                        col_contect.label(text="Layer Collection :")
                        col_contect.prop(scatter_modifier.inputs[1], 'default_value', text = "")

                        Draw_Scatter_Layer_Content(box, scatter_modifier)

                        row = box.row(align=True)
                        row.operator("use.proxyonassets", text= "Proxy All", icon = 'RESTRICT_VIEW_OFF').use_proxy = True
                        row.operator("use.proxyonassets", text= "Proxy All", icon = 'RESTRICT_VIEW_ON').use_proxy = False

                        box.operator("select.content", text= "Select All Assets", icon = 'RESTRICT_SELECT_OFF')

                    ######################################
                    # PAINT MODE
                    ######################################
                    if bpy.context.object.mode == 'OBJECT':
                        col = layout.column(align=True)
                        col.scale_y = 2
                        row = col.row(align=True)
                        row.operator("switch.mode", text= "Paint !", icon = 'BRUSH_DATA')
                        if scatter_modifier.inputs[26].default_value:
                            props = row.operator('switch.boolnode', text='', depress = True, icon = 'ARROW_LEFTRIGHT')
                        else:
                            props = row.operator('switch.boolnode', text='', depress = False, icon = 'ARROW_LEFTRIGHT')
                        props.index = 26

                    if bpy.context.object.mode == 'WEIGHT_PAINT':
                        col = layout.column()
                        col.scale_y = 2
                        col.operator("switch.mode", text="Exit Paint Mode", icon = 'FILE_PARENT')
                        col = layout.column()
                        # col.scale_y = 1.5
                        box=col.box()
                        box.label(text="Painting :", icon = "BRUSH_DATA")
                        box.operator("clean.paint", text= "Clear Paint", icon = 'FILE_REFRESH')
                        box.operator("invert.weight", text= "Invert Paint", icon = 'ARROW_LEFTRIGHT')
                        if bpy.context.workspace.tools.from_space_view3d_mode(bpy.context.mode).idname == "builtin_brush.Draw":
                            draw_brush = bpy.data.brushes.get("Draw")
                            if draw_brush:
                                box.label(text="Brush Profile :")
                                box.prop(draw_brush, "curve_preset", text="")


                        mo_main = obj.modifiers[modifiers[0]]
                        node_group = mo_main.node_group
                        socket_id = scatter_modifier.inputs[25].links[0].from_socket.identifier

                        for i in node_group.interface.items_tree:
                            if i.in_out == 'INPUT':
                                if i.socket_type == 'NodeSocketFloat':
                                    identifier=i.identifier
                                    if socket_id == identifier:
                                        box.label(text="Vertex Group :")
                                        box.prop_search(
                                            mo_main, 
                                            f'["{identifier}_attribute_name"]',
                                            obj, 
                                            "vertex_groups",
                                            text=""
                                        )

                        paint_invert_mode = scatter_modifier.inputs[26].default_value
                        if bpy.app.version >= (5, 0, 0):
                            weight = bpy.context.scene.tool_settings.weight_paint.brush.weight
                        else:
                            weight = bpy.context.scene.tool_settings.unified_paint_settings.weight
                        add_depress = (paint_invert_mode and weight >= 0.5) or (not paint_invert_mode and weight < 0.5)
                        remove_depress = not add_depress

                        row = box.row(align=True)
                        row.operator("invert.paint", text="Add", depress=add_depress, icon='ADD')
                        row.operator("invert.paint", text="Remove", depress=remove_depress, icon='REMOVE')

                        box = box.box()
                        box.scale_y = 0.3
                        box.separator(factor = 0.5)
                        box.label(text="Tips", icon = "INFO")
                        box.separator(factor = 1)
                        box.label(text="Paint resolution depend")
                        box.label(text="on your mesh topology !")
                        box.separator(factor = 1)
                        box.label(text="If necessary,")
                        box.label(text="subdivide your surface.")

                    ######################################
                    # POSITION / ROTATION / SCALE SETTINGS
                    ######################################
                    col_bt = layout.column()
                    col_bt.scale_y = 2
                    col_bt.prop(bagapie_pref, 'scatter_posrot', text = "Transform", toggle = True)

                    if bagapie_pref.scatter_posrot:
                        box = layout.box()
                        box = box.column(align=True)
                        row = box.row()
                        row.label(text="Position")
                        row = box.row()
                        row.prop(scatter_modifier.inputs[7], 'default_value', text = "")
                        row = box.row()
                        row.label(text="Rotation")
                        box = box.column(align=False)
                        row = box.row()
                        row.prop(scatter_modifier.inputs[8], 'default_value', text = "")
                        row = box.row()
                        row = box.column(align=True)
                        row.prop(scatter_modifier.inputs[9], 'default_value', text = "Scale Min")
                        row.prop(scatter_modifier.inputs[10], 'default_value', text = "Scale Max")

                    ######################################
                    # RANDOM SETTINGS
                    ######################################
                    col_bt = layout.column()
                    col_bt.scale_y = 2
                    col_bt.prop(bagapie_pref, 'scatter_random', text = "Randomize Transform", toggle = True)

                    if bagapie_pref.scatter_random:
                        box = layout.box()
                        box = box.column(align=True)
                        row = box.row()
                        row.label(text="Position :")
                        row.label(text="X")
                        row.label(text="Y")
                        row.label(text="Z")
                        row = box.row()
                        split=row.split(factor=0.15)
                        split.label(text="Min")
                        row = split.row()
                        row.prop(scatter_modifier.inputs[11], 'default_value', text = "")

                        row = box.row()
                        split=row.split(factor=0.15)
                        split.label(text="Max")
                        row = split.row()
                        row.prop(scatter_modifier.inputs[12], 'default_value', text = "")

                        box.separator(factor = 1)
                        row = box.row()
                        row.label(text="Rotation :")

                        row = box.row()
                        split=row.split(factor=0.15)
                        split.label(text="Min")
                        row = split.row()
                        row.prop(scatter_modifier.inputs[13], 'default_value', text = "")

                        row = box.row()
                        split=row.split(factor=0.15)
                        split.label(text="Max")
                        row = split.row()
                        row.prop(scatter_modifier.inputs[14], 'default_value', text = "")

                        box.separator(factor = 1)
                        row = box.row()
                        row.label(text="Scale :")

                        row = box.row()
                        split=row.split(factor=0.15)
                        split.label(text="Min")
                        row = split.row()
                        row.prop(scatter_modifier.inputs[15], 'default_value', text = "")

                        row = box.row()
                        split=row.split(factor=0.15)
                        split.label(text="Max")
                        row = split.row()
                        row.prop(scatter_modifier.inputs[16], 'default_value', text = "")

                    ######################################
                    # TEXTURE SETTINGS
                    ######################################
                    col_bt = layout.column()
                    col_bt.scale_y = 2
                    col_bt.prop(bagapie_pref, 'scatter_mask', text = "Mask", toggle = True)

                    if bagapie_pref.scatter_mask:
                        box = layout.box()
                        row = box.row(align=True)
                        row.label(text="Texture Mask")
                        row.operator("bagapie.texturemask_copy", text="", icon="COPYDOWN")
                        row.operator("bagapie.texturemask_paste", text="", icon="PASTEDOWN")
                        col = box.column(align=True)
                        col.prop(scatter_modifier.inputs[17], 'default_value', text = "Fac")
                        col.prop(scatter_modifier.inputs[18], 'default_value', text = "Scale")
                        col.prop(scatter_modifier.inputs[19], 'default_value', text = "Offset")
                        col.prop(scatter_modifier.inputs[20], 'default_value', text = "Smooth")
                        col.label(text="Position :")
                        row = col.row()
                        row.prop(scatter_modifier.inputs[27], 'default_value', text = "")
                        col.prop(scatter_modifier.inputs[28], 'default_value', text = "Invert Mask")

                    ######################################
                    # TUTORIAL & DOC
                    ######################################
                    col_bt = layout.column()
                    col_bt.scale_y = 2
                    col_bt.prop(bagapie_pref, 'scatter_tuto', text = "Tutorial", toggle = True)

                    if bagapie_pref.scatter_tuto:
                        box = layout.box()
                        col = box.column(align=True)
                        col.operator("wm.url_open", text="Scatter Tutorial", icon = 'PLAY').url = "https://youtu.be/oMKetYzkAI0?list=PLSVXpfzibQbh_qjzCP2buB2rK1lQtkQvu"
                        col.operator("wm.url_open", text="Documentation", icon = 'TEXT').url = "https://www.f12studio.fr/bagapiev6"

                    ######################################
                    # GEOPACK EXPORT
                    ######################################
                    col_bt = layout.column()
                    col_bt.scale_y = 2
                    col_bt.prop(bagapie_pref, 'scatter_geopack_export', text = "Save in GeoPack", toggle = True)

                    if bagapie_pref.scatter_geopack_export:
                        box = layout.box()
                        col = box.column(align=True)
                        col_gp = col.column()
                        col_gp.scale_y = 2
                        col_gp.operator("bagapie.geopack_create_modifier", text="Save Scatter in GeoPack")
                        col.operator("wm.url_open", text="Create Preset Tutorial", icon = 'PLAY').url = "https://youtu.be/SbOvA8Yzdrw?list=PLSVXpfzibQbh_qjzCP2buB2rK1lQtkQvu"
                        col.prop(bagapie_pref, 'geopack_render_generate', text = "Generate Preview Icon", toggle = True, icon = 'IMAGE_DATA')
                        if bagapie_pref.geopack_render_generate == True:
                            col.prop(bagapie_pref, 'geopack_render_use_current_world', text = "Lighting : Use Current World")

                        col.label(text="What it does :")
                        col.label(text=" - All scatter layers will be saved")
                        col.label(text=" - Re-use scatter like a preset")
                        col.label(text=" - Can be Exported as .geopack file")
                        col.label(text=" - Assets stored in the pack")
                        col.label(text=" - CamCull & Effectors ignored")
                        if bagapie_pref.geopack_render_generate == True:
                            col.label(text=" - Preview stored in pack")
                            col.label(text=" - Preview from current view")
                            col.label(text=" - Preview from active object")
                            col.label(text=" - Preview can be change in Pref")
                            res = bagapie_pref.geopack_render_resolution
                            samples = bagapie_pref.geopack_render_samples
                            col.label(text=f' - Preview {res}px/{samples} samples, see pref')

                elif mo_type == "displace":
                    modifier_header_basic(col)
                    displace_subdiv = obj.modifiers[modifiers[0]]
                    displace_disp = obj.modifiers[modifiers[1]]
                    texture = bpy.data.textures[modifiers[2]]

                    box = layout.box()# SUBDIVISION
                    box.label(text="Subdivision")
                    box.prop(displace_subdiv, 'subdivision_type', text="Type")
                    box = box.column(align=True)
                    box.prop(displace_subdiv, 'levels', text="Subdivision")
                    box.prop(displace_subdiv, 'render_levels', text="Subdivision Render")

                    box = layout.box()# DISPLACEMENT
                    box.label(text="Displace")
                    box.prop(displace_disp, 'direction', text="Direction")
                    box = box.column(align=True)
                    box.prop(displace_disp, 'strength', text="Strength")
                    box.prop(displace_disp, 'mid_level', text="Midlevel")
                    box = layout.box()

                    box.label(text="Texture")# TEXTURE
                    box.prop(texture, 'type', text="Type")
                    if texture.type == 'IMAGE':
                        box.label(text="Go in Texture tab.")
                    box.prop(displace_disp, 'texture_coords', text="Mapping")
                    if displace_disp.texture_coords == 'OBJECT':
                        box.prop(displace_disp, 'texture_coords_object', text="Object")
                    box = box.column(align=True)
                    box.prop(texture, 'noise_scale', text="Scale")
                    box.prop(texture, 'intensity', text="Brightness")
                    box.prop(texture.color_ramp.elements[0], 'position', text="Ramp Min")
                    box.prop(texture.color_ramp.elements[1], 'position', text="Ramp Max")

                elif mo_type == "scatterpaint":
                    modifier_header_basic(col)

                    col = layout.column(align=True)
                    col.scale_y = 2.0

                    if bpy.context.object.mode == 'OBJECT':
                        col.operator("switch.mode", text= "Paint !")

                    if bpy.context.object.mode == 'WEIGHT_PAINT':
                        
                        if bpy.app.version >= (5, 0, 0):
                            weight = bpy.context.scene.tool_settings.weight_paint.brush.weight
                        else:
                            weight = bpy.context.scene.tool_settings.unified_paint_settings.weight
                        if weight < 1:
                            col.operator("invert.paint", text="ADD")
                        else:
                            col.operator("invert.paint", text="REMOVE")

                        col.scale_y = 1
                        col.operator("clean.paint", text= "CLEAN PAINT")
                        col.operator("invert.weight", text= "INVERT PAINT")

                        col = layout.column()
                        col.scale_y = 2
                        col.operator("switch.mode", text="EXIT !")

                    scatter_modifier = obj.modifiers.get("BagaScatter")
                    scatt_nde_group = scatter_modifier.node_group
                    scatt_nde_main = scatt_nde_group.nodes.get(modifiers[1])

                    col = layout.column(align=True)
                    col.scale_y = 1.2
                    col.prop(scatt_nde_main.inputs[1], 'default_value', text = "Source Collection")
                    col.prop(scatt_nde_main.inputs[2], 'default_value', text = "Distance Min")
                    col.prop(scatt_nde_main.inputs[3], 'default_value', text = "Density")
                    col.prop(scatt_nde_main.inputs[4], 'default_value', text = "% Viewport Display")


                    box = layout.box()
                    box = box.column(align=True)
                    box.prop(scatt_nde_main.inputs[7], 'default_value', text = "Random Position")
                    box.prop(scatt_nde_main.inputs[8], 'default_value', text = "Random Rotation")
                    box.prop(scatt_nde_main.inputs[11], 'default_value', text = "Align Z")
                    box.prop(scatt_nde_main.inputs[9], 'default_value', text = "Scale Min")
                    box.prop(scatt_nde_main.inputs[10], 'default_value', text = "Scale Max")
                    box.prop(scatt_nde_main.inputs[5], 'default_value', text = "Seed")

                    box.label(text="Current Layer :")
                    box.prop(obj.vertex_groups, 'active_index', text = obj.vertex_groups.active.name)

                elif mo_type == "curvearray":
                    modifier_header_basic(col)
                    arraycurve_array = obj.modifiers[modifiers[0]]
                    arraycurve_curve = obj.modifiers[modifiers[1]]

                    col = layout.column()
                    col.prop(arraycurve_curve, 'deform_axis', text="Axis")
                    box = layout.box()
                    box.prop(arraycurve_array, 'use_relative_offset', text="Use Relative Offset")
                    box.prop(arraycurve_array, 'relative_offset_displace', text="Ralative Offset")
                    box = layout.box()
                    box.prop(arraycurve_array, 'use_constant_offset', text="Use Constant Offset")
                    box.prop(arraycurve_array, 'constant_offset_displace', text="Constant Offset")

                elif mo_type == "window":
                    modifier_header_basic(col)

                    if modifiers[6] == "win":
                        window_weld = obj.modifiers[modifiers[0]]
                        window_disp = obj.modifiers[modifiers[1]]
                        window_wire = obj.modifiers[modifiers[2]]
                        window_bevel = obj.modifiers[modifiers[3]]

                        box = layout.box()
                        box.prop(window_disp, 'strength', text="Offset")
                        box.prop(window_wire, 'thickness', text="Window Size")
                        box.prop(window_wire, 'offset', text="Window Offset")
                        box.prop(window_bevel, 'width', text="Window Bevel")
                        box.prop(window_weld, 'merge_threshold', text="Merge by Distance")


                        col = layout.column()
                        col.scale_y = 1.5
                        active_ob = bpy.context.active_object
                        if bpy.context.object.mode == 'OBJECT' and active_ob == obj:
                            col.operator("bool.mode", text= "More Window !")
                        elif bpy.context.object.mode == 'EDIT' and active_ob == obj:
                            col.operator("bool.mode", text= "EXIT")
                        else:
                            col.label(text="Selects the bounding box of the window")


                    elif modifiers[6] == "wall":

                        window = bpy.data.objects[modifiers[7]]

                        window_weld = window.modifiers[modifiers[1]]
                        window_disp = window.modifiers[modifiers[2]]
                        window_wire = window.modifiers[modifiers[3]]
                        window_bevel = window.modifiers[modifiers[4]]

                        box = layout.box()
                        box.prop(window_disp, 'strength', text="Offset")
                        box.prop(window_wire, 'thickness', text="Window Size")
                        box.prop(window_wire, 'offset', text="Window Offset")
                        box.prop(window_bevel, 'width', text="Window Bevel")
                        box.prop(window_weld, 'merge_threshold', text="Merge by Distance")

                elif mo_type == "pointeffector":
                    modifier_header_basic(col)
                    effector_modifier = obj.modifiers[modifiers[0]]
                    effector_nde = effector_modifier.node_group.nodes.get(modifiers[1])

                    col = layout.column(align=True)
                    col.scale_y = 1.2
                    col.label(text="Effector Collection :", icon = "OUTLINER_COLLECTION")
                    col.prop_search(effector_nde.inputs[0], 'default_value', bpy.data, "collections", text="", icon="OUTLINER_COLLECTION")
                    col.separator(factor = 1)
                    col.prop(effector_nde.inputs[1], 'default_value', text = "Distance Min")
                    col.prop(effector_nde.inputs[2], 'default_value', text = "Distance Max")
                    col.prop(effector_nde.inputs[3], 'default_value', text = "Density")

                elif mo_type == "camera":
                    modifier_header_basic(col)
                    effector_modifier = obj.modifiers[modifiers[0]]
                    effector_nde = effector_modifier.node_group.nodes.get(modifiers[1])

                    col = layout.column(align=True)
                    col.scale_y = 1.2
                    col.label(text="Camera :")
                    col.prop_search(effector_nde.inputs[0], 'default_value', bpy.data, "objects", text="", icon="VIEW_CAMERA")
                    col.separator(factor = 1)
                    col.prop(effector_nde.inputs[1], 'default_value', text = "X Ratio")
                    col.prop(effector_nde.inputs[2], 'default_value', text = "Y Ratio")
                    col.prop(effector_nde.inputs[5], 'default_value', text = "Offset")
                    
                    box = layout.box()
                    box = box.column(align=True)
                    box.label(text="Tips", icon = "INFO")
                    box.label(text="Culling resolution depend")
                    box.label(text="on your surface resolution !")
                    box.separator(factor = 2)
                    box.label(text="If necessary,")
                    box.label(text="subdivide your surface.")

                elif mo_type == "boolean":
                    modifier_header_basic(col)
                    box = layout.box()
                    
                    if obj.modifiers.get(modifiers[0]):
                        box.label(text="Boolean Type")
                        box.prop(obj.modifiers[modifiers[0]], 'operation', text="")
                        box.prop(obj.modifiers[modifiers[0]], 'solver', text="")
                        if obj.modifiers[modifiers[0]].solver == 'EXACT':
                            box = box.row(align = True)
                            box.prop(obj.modifiers[modifiers[0]], 'use_self', text="Use self")
                            box.prop(obj.modifiers[modifiers[0]], 'use_hole_tolerant', text="Hole Tolerant")

                        box = layout.box()
                        box.label(text="Boolean Target")
                        box = box.column(align = True)
                        box.prop(obj.modifiers[modifiers[1]], 'segments', text="Bevel Segments")
                        box.prop(obj.modifiers[modifiers[1]], 'width', text="Bevel Size")

                        bool_obj = bpy.data.objects[modifiers[5]]

                        box = layout.box()
                        box.label(text="Boolean Object")
                        box = box.column(align = True)
                        box.prop(bool_obj.modifiers[modifiers[3]], 'segments', text="Bevel Segments")
                        box.prop(bool_obj.modifiers[modifiers[3]], 'width', text="Bevel Size")
                        box.prop(bool_obj.modifiers[modifiers[6]], 'strength', text="Displace")

                        box = box.column(align = False)
                        col = box.column()
                        if bool_obj.modifiers[modifiers[4]].show_render:
                            box.operator("solidify.visibility", text= "Disable Solidify")
                        else:
                            box.operator("solidify.visibility", text= "Use Solidify")
                        box = box.column(align = True)  
                        box.prop(bool_obj.modifiers[modifiers[4]], 'thickness', text="Solidify")
                        box.prop(bool_obj.modifiers[modifiers[4]], 'offset', text="Solidify Offset")
                        box = box.row(align = True)
                        box.label(text="Mirror XYZ")
                        box.prop(bool_obj.modifiers[modifiers[2]], 'use_axis', text="")
                        
                        col = layout.column()
                        col.scale_y = 2.0
                        active_ob = bpy.context.active_object
                        if bpy.context.object.mode == 'OBJECT' and active_ob == obj:
                            col.operator("bool.mode", text= "More Boolean !")
                        elif bpy.context.object.mode == 'EDIT' and active_ob == obj:
                            col.operator("bool.mode", text= "EXIT")
                    else:
                        box.label(text="Modifier not found")

                elif mo_type == "ivy":
                    modifier_header_basic(col)
                    ivy_modifier = obj.modifiers[modifiers[0]]
                    ivy_mo_input = ivy_modifier.properties.inputs

                    box = layout.box()
                    box = box.column(align=True)
                    box.scale_y = 1.5
                    box.operator("bagapie.addvertcursor", text="Add Ivy to 3D Cursor")
                    row=box.row(align=True)
                    row.operator("bagapie.addobjecttarget", text="Target", icon = 'ADD')
                    row.operator("bagapie.removeobjecttarget", text="Target", icon = 'REMOVE')
                    box = layout.box()

                    box.label(text="Ivy")
                    row = box.row(align=True)

                    input_index = "Input_23"
                    value_button = getattr(ivy_mo_input, input_index)["value"]
                    row.operator(
                        "switch.button",
                        text="Spiral",
                        depress=not value_button,
                        icon="MOD_DASH",
                    ).index = input_index
                    row.operator(
                        "switch.button",
                        text="Grid Project",
                        depress=value_button,
                        icon="VIEW_ORTHO",
                    ).index = input_index

                    input_index = "Input_18"
                    value_button = getattr(ivy_mo_input, input_index)["value"]
                    box.operator(
                        "switch.button",
                        text="View Guide",
                        depress=value_button,
                        icon="HIDE_OFF" if value_button else "HIDE_ON",
                    ).index = input_index
                    box = box.column(align=True)
                    
                    box.prop(getattr(ivy_mo_input, "Input_3"), "value", text = "Radius")
                    if not ivy_mo_input['Input_23']["value"]:
                        box.prop(getattr(ivy_mo_input, "Input_5"), "value", text = "Height")
                        box.prop(getattr(ivy_mo_input, "Input_6"), "value", text = "Loop")
                    box.prop(getattr(ivy_mo_input, "Input_21"), "value", text = "Gravity")
                    box.prop(getattr(ivy_mo_input, "Input_19"), "value", text = "Scale")
                    box.prop(getattr(ivy_mo_input, "Input_2"), "value", text = "Resolution")

                    box = layout.box()
                    box = box.column(align=True)
                    box.prop(getattr(ivy_mo_input, "Input_10"), "value", text = "Density")
                    box.prop(getattr(ivy_mo_input, "Input_20"), "value", text = "Decimate")

                    box = layout.box()
                    box.label(text="Random")
                    box = box.column(align=True)
                    box.prop(getattr(ivy_mo_input, "Input_7"), "value", text = "Random Position")
                    box.prop(getattr(ivy_mo_input, "Input_14"), "value", text = "Emission Area")
                    box.prop(getattr(ivy_mo_input, "Input_11"), "value", text = "Surface Offset")
                    box.prop(getattr(ivy_mo_input, "Input_8"), "value", text = "Scale")
                    box.label(text="Ivy Random Position")
                    box = box.row(align=True)
                    box.prop(getattr(ivy_mo_input, "Input_12"), "value", text = "")
                    
                    box = layout.box()
                    box.label(text="Collections", icon = "INFO")
                    box.prop_search(getattr(ivy_mo_input, "Input_9"), "value", bpy.data, "collections", text="Target", icon="OUTLINER_COLLECTION")
                    box.prop_search(getattr(ivy_mo_input, "Input_16"), "value", bpy.data, "collections", text="Asset", icon="OUTLINER_COLLECTION")
                    box.prop_search(getattr(ivy_mo_input, "Input_17"), "value", bpy.data, "collections", text="Emitter", icon="OUTLINER_COLLECTION")

                elif mo_type == "pointsnapinstance":
                    modifier_header_basic(col)
                    psi_modifier = obj.modifiers[modifiers[0]]
                    psi_mo_input = psi_modifier.properties.inputs
                    col = layout.column(align=True)
                    col.scale_y=2
                    col.operator("bagapie.pointsnapinstance", text= "Add Instances")
                    col = layout.column(align=True)
                    col.label(text="ESCAPE to Stop")

                    col = layout.column(align=True)
                    box = layout.box()
                    box.label(text="Main")
                    box = box.column(align=True)
                    box.prop(getattr(psi_mo_input,"Input_9"), "value", text = "Offset Z")
                    box.prop(getattr(psi_mo_input,"Input_8"), "value", text = "Align Normal")
                    box = layout.box()
                    box.label(text="Random")
                    box = box.column(align=True)
                    box.prop(getattr(psi_mo_input, "Input_5"), "value", text = "Random Rotation")
                    box.prop(getattr(psi_mo_input, "Input_6"), "value", text = "Scale Min")
                    box.prop(getattr(psi_mo_input, "Input_7"), "value", text = "Scale Max")
                    
                    box = layout.box()
                    box.label(text="Source info", icon = "INFO")
                    box.prop_search(getattr(psi_mo_input, "Input_3"), "value", bpy.data, "objects", text="Target", icon="OBJECT_DATA")
                    box.prop_search(getattr(psi_mo_input, "Input_4"), "value", bpy.data, "collections", text="Instances", icon="OUTLINER_COLLECTION")                    

                elif mo_type == "grass":
                    material_slots = obj.material_slots
                    index = 0
                    col.label(text="Grass Shader :")
                    for m in material_slots:
                        index += 1
                        material = m.material
                        nodes = material.node_tree.nodes
                        for node in nodes:
                            if node.name == modifiers[0]:
                                shader_node = node
                            elif node.name == modifiers[1]:
                                shader_node = node
                            elif node.name == modifiers[2]:
                                shader_node = node

                        if shader_node.name.startswith('BagaPie_Moss'):
                            box = layout.box()
                            box.label(text="Material " + str(index))
                            box = box.column(align=True)
                            box.prop(shader_node.inputs[1], 'default_value', text = "Brightness")
                            box.prop(shader_node.inputs[0], 'default_value', text = "Saturation")

                        elif shader_node.name.startswith('BagaPie_LP_Plant'):
                            box = layout.box()
                            box.label(text="Material " + str(index))
                            box = box.column(align=True)
                            box.prop(shader_node.inputs[0], 'default_value', text = "")
                            box.prop(shader_node.inputs[1], 'default_value', text = "AO White")
                            box.prop(shader_node.inputs[2], 'default_value', text = "AO Distance")
                            box.separator(factor = 0.5)
                            box.prop(shader_node.inputs[3], 'default_value', text = "Translucent")
                            box.prop(shader_node.inputs[4], 'default_value', text = "")
                            box.separator(factor = 0.5)
                            box.prop(shader_node.inputs[5], 'default_value', text = "Tint Intensity")
                            box.prop(shader_node.inputs[6], 'default_value', text = "Random Tint")
                            box.prop(shader_node.inputs[7], 'default_value', text = "")
                            box.separator(factor = 0.5)
                            box.prop(shader_node.inputs[8], 'default_value', text = "Brightness")
                            box.prop(shader_node.inputs[9], 'default_value', text = "Random Brightness")
                            box.prop(shader_node.inputs[10], 'default_value', text = "Saturation")
                            box.prop(shader_node.inputs[11], 'default_value', text = "Random Saturation")

                        else:
                            box = layout.box()
                            box.label(text="Material " + str(index))
                            box = box.column(align=True)
                            box.prop(shader_node.inputs[1], 'default_value', text = "Brightness")
                            box.prop(shader_node.inputs[2], 'default_value', text = "Random Brightness")
                            box.prop(shader_node.inputs[3], 'default_value', text = "Saturation")
                            box.prop(shader_node.inputs[4], 'default_value', text = "Random Saturation")
                            box.separator(factor = 0.5)
                            box = box.column(align=True)
                            box.prop(shader_node.inputs[5], 'default_value', text = "Season")
                            box.prop(shader_node.inputs[6], 'default_value', text = "Random Saison")
                            if shader_node.inputs[5].default_value + (shader_node.inputs[6].default_value) >= 0.9:
                                box.label(text="Season value up to 0.9", icon = 'ERROR')
                                box.label(text="This value add transparency.")
                                box.label(text="May increase render time !")
                                box.label(text="Decrease Season or Random Season")
                            box.separator(factor = 0.5)
                            box = box.column(align=True)
                            box.prop(shader_node.inputs[7], 'default_value', text = "Translucent")
                            box.prop(shader_node.inputs[10], 'default_value', text = "Specular")
                            box.prop(shader_node.inputs[11], 'default_value', text = "Roughness")

                elif mo_type == "plant":
                    material_slots = obj.material_slots
                    index = 0
                    col.label(text="Plant Shader :")
                    for m in material_slots:
                        index += 1
                        material = m.material
                        nodes = material.node_tree.nodes
                        disp = False
                        for node in nodes:
                            if node.name == modifiers[0]:
                                shader_node = node
                                disp = True
                            elif node.name == modifiers[1]:
                                shader_node = node
                            elif node.name == modifiers[2]:
                                shader_node = node

                        if shader_node.name == "BagaPie_LP_Plant":
                            box = layout.box()
                            box.label(text="Material " + str(index))
                            box = box.column(align=True)
                            box.prop(shader_node.inputs[0], 'default_value', text = "Color")
                            box.prop(shader_node.inputs[1], 'default_value', text = "AO White")
                            box.prop(shader_node.inputs[2], 'default_value', text = "AO Distance")
                            if bpy.context.scene.render.engine == 'BLENDER_EEVEE':
                                if bpy.context.scene.eevee.use_gtao:
                                    box.prop(bpy.context.scene.eevee, 'use_gtao', text = "Use AO")
                            box.separator(factor = 1)
                            box.prop(shader_node.inputs[3], 'default_value', text = "Translucent")
                            box.prop(shader_node.inputs[4], 'default_value', text = "")
                            box.separator(factor = 1)
                            box.prop(shader_node.inputs[6], 'default_value', text = "Tint Intensity")
                            box.prop(shader_node.inputs[5], 'default_value', text = "Random Tint")
                            box.prop(shader_node.inputs[7], 'default_value', text = "")
                            box.separator(factor = 1)                            
                            box.prop(shader_node.inputs[8], 'default_value', text = "Brightness")
                            box.prop(shader_node.inputs[9], 'default_value', text = "Random Brightness")
                            box.prop(shader_node.inputs[10], 'default_value', text = "Saturation")
                            box.prop(shader_node.inputs[11], 'default_value', text = "Random Saturation")

                        elif shader_node.name.startswith("BagaPie_LP_Tree_Leaf"):
                            box = layout.box()
                            box.label(text= (m.name[:-4]).removeprefix('BagaPie_'))
                            box = box.column(align=True)
                            box.prop(shader_node.inputs[0], 'default_value', text = "AO White")
                            box.prop(shader_node.inputs[1], 'default_value', text = "AO Distance")
                            box.separator(factor = 0.5)
                            box.prop(shader_node.inputs[2], 'default_value', text = "Subsurface")
                            box.prop(shader_node.inputs[3], 'default_value', text = "")
                            box.separator(factor = 0.5)
                            box.prop(shader_node.inputs[4], 'default_value', text = "Tint Intensity")
                            box.prop(shader_node.inputs[5], 'default_value', text = "Random Tint")
                            box.prop(shader_node.inputs[6], 'default_value', text = "")
                            box.separator(factor = 0.5)
                            box.prop(shader_node.inputs[7], 'default_value', text = "Brightness")
                            box.prop(shader_node.inputs[8], 'default_value', text = "Random Brightness")
                            box.prop(shader_node.inputs[9], 'default_value', text = "Saturation")
                            box.prop(shader_node.inputs[10], 'default_value', text = "Random Saturation")

                        
                        elif shader_node.name.startswith("BagaPie_V2"):
                            if "Desert" in shader_node.name:
                                    box = layout.box()
                                    box.label(text= (m.name[:-4]).removeprefix('BagaPie_V2_'))
                                    box = box.column(align=True)
                                    idx_input = 4
                                    box.prop(shader_node.inputs[idx_input], 'default_value', text = shader_node.inputs[idx_input].name)
                                    idx_input = 5
                                    box.prop(shader_node.inputs[idx_input], 'default_value', text = shader_node.inputs[idx_input].name)
                                    idx_input = 7
                                    box.prop(shader_node.inputs[idx_input], 'default_value', text = shader_node.inputs[idx_input].name)
                                    idx_input = 8
                                    box.prop(shader_node.inputs[idx_input], 'default_value', text = shader_node.inputs[idx_input].name)
                                    idx_input = 9
                                    box.prop(shader_node.inputs[idx_input], 'default_value', text = shader_node.inputs[idx_input].name)
                                    idx_input = 10
                                    box.prop(shader_node.inputs[idx_input], 'default_value', text = shader_node.inputs[idx_input].name)
                                    idx_input = 11
                                    box.prop(shader_node.inputs[idx_input], 'default_value', text = shader_node.inputs[idx_input].name)
                                    idx_input = 12
                                    box.prop(shader_node.inputs[idx_input], 'default_value', text = shader_node.inputs[idx_input].name)
                            elif "Bark" in shader_node.name:
                                box = layout.box()
                                box.label(text= (m.name[:-4]).removeprefix('BagaPie_V2_'))
                                box = box.column(align=True)
                                idx_input = 4
                                box.prop(shader_node.inputs[idx_input], 'default_value', text = shader_node.inputs[idx_input].name)
                                idx_input = 5
                                box.prop(shader_node.inputs[idx_input], 'default_value', text = shader_node.inputs[idx_input].name)
                                idx_input = 11
                                box.prop(shader_node.inputs[idx_input], 'default_value', text = shader_node.inputs[idx_input].name)
                                idx_input = 12
                                box.prop(shader_node.inputs[idx_input], 'default_value', text = shader_node.inputs[idx_input].name)
                                idx_input = 9
                                box.prop(shader_node.inputs[idx_input], 'default_value', text = shader_node.inputs[idx_input].name)
                                idx_input = 10
                                box.prop(shader_node.inputs[idx_input], 'default_value', text = shader_node.inputs[idx_input].name)
                            else: 
                                box = layout.box()
                                box.label(text="Material " + str(index))
                                box = box.column(align=True)
                                box.prop(shader_node.inputs[1], 'default_value', text = "Brightness")
                                box.prop(shader_node.inputs[2], 'default_value', text = "Random Brightness")
                                box.prop(shader_node.inputs[3], 'default_value', text = "Saturation")
                                box.prop(shader_node.inputs[4], 'default_value', text = "Random Saturation")
                                box.separator(factor = 0.5)
                                box = box.column(align=True)
                                box.prop(shader_node.inputs[5], 'default_value', text = "Season")
                                box.prop(shader_node.inputs[6], 'default_value', text = "Random Season")
                                if shader_node.inputs[5].default_value + (shader_node.inputs[6].default_value) >= 0.9:
                                    box.label(text="Season value up to 0.9", icon = 'ERROR')
                                    box.label(text="This value add transparency.")
                                    box.label(text="May increase render time !")
                                    box.label(text="Decrease Season or Random Season")
                                box.separator(factor = 0.5)
                                box = box.column(align=True)
                                box.prop(shader_node.inputs[7], 'default_value', text = "Translucent")
                                box.prop(shader_node.inputs[10], 'default_value', text = "Specular")
                                box.prop(shader_node.inputs[11], 'default_value', text = "Roughness")
                                box.prop(shader_node.inputs[12], 'default_value', text = "Alpha")

                        elif disp is True:
                            box = layout.box()
                            box.label(text="Material " + str(index))
                            box = box.column(align=True)
                            box.prop(shader_node.inputs[1], 'default_value', text = "Brightness")
                            box.prop(shader_node.inputs[2], 'default_value', text = "Random Brightness")
                            box.prop(shader_node.inputs[3], 'default_value', text = "Saturation")
                            box.prop(shader_node.inputs[4], 'default_value', text = "Random Saturation")
                            box.separator(factor = 0.5)
                            box = box.column(align=True)
                            box.prop(shader_node.inputs[5], 'default_value', text = "Season")
                            box.prop(shader_node.inputs[6], 'default_value', text = "Random Season")
                            if shader_node.inputs[5].default_value + (shader_node.inputs[6].default_value) >= 0.9:
                                box.label(text="Season value up to 0.9", icon = 'ERROR')
                                box.label(text="This value add transparency.")
                                box.label(text="May increase render time !")
                                box.label(text="Decrease Season or Random Season")
                            box.separator(factor = 0.5)
                            box = box.column(align=True)
                            box.prop(shader_node.inputs[7], 'default_value', text = "Translucent")
                            box.prop(shader_node.inputs[10], 'default_value', text = "Specular")
                            box.prop(shader_node.inputs[11], 'default_value', text = "Roughness")

                elif mo_type == "rock":
                    material_slots = obj.material_slots
                    col.label(text="Rock Shader :")
                    
                    for m in material_slots:
                        material = m.material
                        nodes = material.node_tree.nodes
                        for node in nodes:
                            if node.name == modifiers[0]:
                                shader_node = node
                        
                        if shader_node.name.startswith("BagaPie_V2"):
                            if "Rock" in shader_node.name:
                                box = layout.box()
                                box.label(text= (m.name[:-4]).removeprefix('BagaPie_'))
                                box = box.column(align=True)
                                inp = shader_node.inputs

                                idx_input = [13,14,15,16]
                                for i in idx_input:
                                    box.prop(inp[i], 'default_value', text = inp[i].name)
                                box.separator(factor = 0.5)
                                box.prop(shader_node.inputs[17], 'default_value', text = "Tint")
                                box.prop(shader_node.inputs[18], 'default_value', text = "")
                                box.separator(factor = 0.5)
                                idx_input = [4,5]
                                for i in idx_input:
                                    box.prop(inp[i], 'default_value', text = inp[i].name)
                                box.label(text="Bump")
                                box.prop(shader_node.inputs[12], 'default_value', text = "Threshold")
                                box.prop(shader_node.inputs[7], 'default_value', text = "Intensity")
                                box.label(text="Ambient Occlusion")
                                box.prop(shader_node.inputs[6], 'default_value', text = "AO (Map)")
                                if bpy.context.scene.render.engine == 'BLENDER_EEVEE':
                                    if bpy.context.scene.eevee.use_gtao:
                                        box.label(text="AO disabled")
                                        box.prop(bpy.context.scene.eevee, 'use_gtao', text = "Use AO")
                                box.prop(shader_node.inputs[10], 'default_value', text = "AO Distance")
                                box.prop(shader_node.inputs[11], 'default_value', text = "AO Intensity")
                        elif shader_node.name.startswith("BagaPie_PL_Tree_Trunk"):
                            box = layout.box()
                            box.label(text= (m.name[:-4]).removeprefix('BagaPie_'))
                            box = box.column(align=True)
                            box.prop(shader_node.inputs[0], 'default_value', text = "AO")
                            box.prop(shader_node.inputs[1], 'default_value', text = "AO Distance")
                            box.prop(shader_node.inputs[8], 'default_value', text = "AO Tint")
                            box.separator(factor = 0.5)
                            box.prop(shader_node.inputs[2], 'default_value', text = "Tint Intensity")
                            box.prop(shader_node.inputs[3], 'default_value', text = "")
                            box.separator(factor = 0.5)
                            box.prop(shader_node.inputs[5], 'default_value', text = "Brightness")
                            box.prop(shader_node.inputs[4], 'default_value', text = "Saturation")
                        else:
                            box = layout.box()
                            box.label(text= (m.name[:-4]).removeprefix('BagaPie_'))
                            box = box.column(align=True)
                            box.prop(shader_node.inputs[1], 'default_value', text = "Saturation")
                            box.prop(shader_node.inputs[2], 'default_value', text = "Random Saturation")
                            box.prop(shader_node.inputs[3], 'default_value', text = "Brightness")
                            box.prop(shader_node.inputs[4], 'default_value', text = "Random Brightness")
                            box.separator(factor = 0.5)
                            box.prop(shader_node.inputs[6], 'default_value', text = "Tint")
                            box.prop(shader_node.inputs[5], 'default_value', text = "")
                            box.separator(factor = 0.5)
                            box.prop(shader_node.inputs[7], 'default_value', text = "Specular")
                            box.prop(shader_node.inputs[8], 'default_value', text = "Roughness")

                            box.label(text="Bump")
                            box.prop(shader_node.inputs[12], 'default_value', text = "Threshold")
                            box.prop(shader_node.inputs[13], 'default_value', text = "Intensity")
                            box.label(text="Ambient Occlusion")
                            if bpy.context.scene.render.engine == 'BLENDER_EEVEE':
                                if not bpy.context.scene.eevee.use_gtao:
                                    box.label(text="AO disabled")
                                    box.prop(bpy.context.scene.eevee, 'use_gtao', text = "Use AO")
                            box.prop(shader_node.inputs[14], 'default_value', text = "Intensity")
                            box.prop(shader_node.inputs[15], 'default_value', text = "Distance")

                elif mo_type == "tree":
                    material_slots = obj.material_slots
                    index = 0
                    col.label(text="Tree Shader :")
                    for m in material_slots:
                        index += 1
                        material = m.material
                        nodes = material.node_tree.nodes
                        disp = False
                        for node in nodes:
                            if node.name == modifiers[0]:
                                shader_node = node
                                disp = True
                            elif node.name == modifiers[1] and modifiers[1] != "":
                                shader_node = node
                                disp = True
                            elif node.name == modifiers[2] and modifiers[2] != "":
                                shader_node = node
                                disp = True
                        
                        # disp = DISPLAY !
                        if disp is True:
                            if shader_node.name.startswith("BagaPie_LP_Tree_Leaf"):
                                box = layout.box()
                                box.label(text= (m.name[:-4]).removeprefix('BagaPie_'))
                                box = box.column(align=True)
                                box.prop(shader_node.inputs[0], 'default_value', text = "AO White")
                                box.prop(shader_node.inputs[1], 'default_value', text = "AO Distance")
                                box.separator(factor = 0.5)
                                box.prop(shader_node.inputs[2], 'default_value', text = "Subsurface")
                                box.prop(shader_node.inputs[3], 'default_value', text = "")
                                box.separator(factor = 0.5)
                                box.prop(shader_node.inputs[4], 'default_value', text = "Tint Intensity")
                                box.prop(shader_node.inputs[5], 'default_value', text = "Random Tint")
                                box.prop(shader_node.inputs[6], 'default_value', text = "")
                                box.separator(factor = 0.5)
                                box.prop(shader_node.inputs[7], 'default_value', text = "Brightness")
                                box.prop(shader_node.inputs[8], 'default_value', text = "Random Brightness")
                                box.prop(shader_node.inputs[9], 'default_value', text = "Saturation")
                                box.prop(shader_node.inputs[10], 'default_value', text = "Random Saturation")

                            elif shader_node.name.startswith("BagaPie_PL_Tree_Trunk"):
                                box = layout.box()
                                box.label(text= (m.name[:-4]).removeprefix('BagaPie_'))
                                box = box.column(align=True)
                                box.prop(shader_node.inputs[0], 'default_value', text = "AO White")
                                box.prop(shader_node.inputs[1], 'default_value', text = "AO Distance")
                                box.separator(factor = 0.5)
                                box.prop(shader_node.inputs[2], 'default_value', text = "Tint Intensity")
                                box.prop(shader_node.inputs[3], 'default_value', text = "")
                                box.separator(factor = 0.5)
                                box.prop(shader_node.inputs[5], 'default_value', text = "Brightness")
                                box.prop(shader_node.inputs[4], 'default_value', text = "Saturation")

                            elif shader_node.name.startswith("BagaPie_V2"):
                                if "Bark" in shader_node.label:
                                    box = layout.box()
                                    box.label(text= (m.name[:-4]).removeprefix('BagaPie_V2_'))
                                    box = box.column(align=True)
                                    idx_input = 4
                                    box.prop(shader_node.inputs[idx_input], 'default_value', text = shader_node.inputs[idx_input].name)
                                    idx_input = 5
                                    box.prop(shader_node.inputs[idx_input], 'default_value', text = shader_node.inputs[idx_input].name)
                                    idx_input = 11
                                    box.prop(shader_node.inputs[idx_input], 'default_value', text = shader_node.inputs[idx_input].name)
                                    idx_input = 12
                                    box.prop(shader_node.inputs[idx_input], 'default_value', text = shader_node.inputs[idx_input].name)
                                else:
                                    box = layout.box()
                                    box.label(text= (m.name[:-4]).removeprefix('BagaPie_V2_'))
                                    box = box.column(align=True)
                                    box.prop(shader_node.inputs[1], 'default_value', text = "Brightness")
                                    box.prop(shader_node.inputs[2], 'default_value', text = "Random Brightness")
                                    box.prop(shader_node.inputs[3], 'default_value', text = "Saturation")
                                    box.prop(shader_node.inputs[4], 'default_value', text = "Random Saturation")
                                    box.separator(factor = 0.5)
                                    box = box.column(align=True)
                                    box.prop(shader_node.inputs[5], 'default_value', text = "Season")
                                    box.prop(shader_node.inputs[6], 'default_value', text = "Random Season")
                                    if shader_node.inputs[5].default_value + (shader_node.inputs[6].default_value) >= 0.9:
                                        box.label(text="Season value up to 0.9", icon = 'ERROR')
                                        box.label(text="This value add transparency.")
                                        box.label(text="May increase render time !")
                                        box.label(text="Decrease Season or Random Season")
                                    box.separator(factor = 0.5)
                                    box = box.column(align=True)
                                    box.prop(shader_node.inputs[7], 'default_value', text = "Translucent")
                                    box.prop(shader_node.inputs[10], 'default_value', text = "Specular")
                                    box.prop(shader_node.inputs[11], 'default_value', text = "Roughness")
                                    box.prop(shader_node.inputs[12], 'default_value', text = "Disable Alpha")

                            else:
                                box = layout.box()
                                box.label(text= (m.name[:-4]).removeprefix('BagaPie_'))
                                box = box.column(align=True)
                                box.prop(shader_node.inputs[1], 'default_value', text = "Brightness")
                                box.prop(shader_node.inputs[2], 'default_value', text = "Random Brightness")
                                box.prop(shader_node.inputs[3], 'default_value', text = "Saturation")
                                box.prop(shader_node.inputs[4], 'default_value', text = "Random Saturation")
                                box.separator(factor = 0.5)
                                box = box.column(align=True)
                                box.prop(shader_node.inputs[5], 'default_value', text = "Season")
                                box.prop(shader_node.inputs[6], 'default_value', text = "Random Season")
                                if shader_node.inputs[5].default_value + (shader_node.inputs[6].default_value) >= 0.9:
                                    box.label(text="Season value up to 0.9", icon = 'ERROR')
                                    box.label(text="This value add transparency.")
                                    box.label(text="May increase render time !")
                                    box.label(text="Decrease Season or Random Season")
                                box.separator(factor = 0.5)
                                box = box.column(align=True)
                                box.prop(shader_node.inputs[7], 'default_value', text = "Translucent")
                                box.prop(shader_node.inputs[10], 'default_value', text = "Specular")
                                box.prop(shader_node.inputs[11], 'default_value', text = "Roughness")

                elif mo_type == "stump":
                    material_slots = obj.material_slots
                    for m in material_slots:
                        material = m.material
                        nodes = material.node_tree.nodes
                        for node in nodes:
                            if node.name == modifiers[0]:
                                shader_node = node
                        
                        if shader_node.name.startswith("BagaPie_V2"):
                            if "Wood" in shader_node.name:
                                box = layout.box()
                                box.label(text= (m.name[:-4]).removeprefix('BagaPie_'))
                                box = box.column(align=True)
                                inp = shader_node.inputs

                                idx_input = [10,11,12,13]
                                for i in idx_input:
                                    box.prop(inp[i], 'default_value', text = inp[i].name)
                                box.separator(factor = 0.5)
                                box.prop(shader_node.inputs[14], 'default_value', text = "Tint")
                                box.prop(shader_node.inputs[15], 'default_value', text = "")
                                box.separator(factor = 0.5)
                                idx_input = [4,5]
                                for i in idx_input:
                                    box.prop(inp[i], 'default_value', text = inp[i].name)
                                box.label(text="Bump")
                                box.prop(shader_node.inputs[7], 'default_value', text = "Threshold")
                                box.prop(shader_node.inputs[8], 'default_value', text = "Intensity")
                                box.label(text="Ambient Occlusion")
                                box.prop(shader_node.inputs[6], 'default_value', text = "AO (Map)")
                                if bpy.context.scene.render.engine == 'BLENDER_EEVEE':
                                    if not bpy.context.scene.eevee.use_gtao:
                                        box.label(text="AO disabled")
                                        box.prop(bpy.context.scene.eevee, 'use_gtao', text = "Use AO")
                                box.prop(shader_node.inputs[16], 'default_value', text = "AO Intensity")
                                box.prop(shader_node.inputs[17], 'default_value', text = "AO Distance")
                                
                    if shader_node.name.startswith("BagaPie_V2"): 
                        pass
                    elif shader_node.name.startswith("BagaPie_PL_Tree_Trunk"):
                        box = layout.box()
                        box.label(text= (m.name[:-4]).removeprefix('BagaPie_'))
                        box = box.column(align=True)
                        box.prop(shader_node.inputs[0], 'default_value', text = "AO")
                        box.prop(shader_node.inputs[1], 'default_value', text = "AO Distance")
                        box.prop(shader_node.inputs[8], 'default_value', text = "AO Tint")
                        box.separator(factor = 0.5)
                        box.prop(shader_node.inputs[2], 'default_value', text = "Tint Intensity")
                        box.prop(shader_node.inputs[3], 'default_value', text = "")
                        box.separator(factor = 0.5)
                        box.prop(shader_node.inputs[5], 'default_value', text = "Brightness")
                        box.prop(shader_node.inputs[4], 'default_value', text = "Saturation")
                    else:
                        col.label(text="Stump Shader :")
                        box = layout.box()
                        box.label(text= (m.name[:-4]).removeprefix('BagaPie_'))
                        box = box.column(align=True)
                        box.prop(shader_node.inputs[1], 'default_value', text = "Saturation")
                        box.prop(shader_node.inputs[2], 'default_value', text = "Random Saturation")
                        box.prop(shader_node.inputs[3], 'default_value', text = "Brightness")
                        box.prop(shader_node.inputs[4], 'default_value', text = "Random Brightness")
                        box.separator(factor = 0.5)
                        box.prop(shader_node.inputs[6], 'default_value', text = "Tint")
                        box.prop(shader_node.inputs[5], 'default_value', text = "")
                        box.separator(factor = 0.5)
                        box.prop(shader_node.inputs[7], 'default_value', text = "Specular")
                        box.prop(shader_node.inputs[8], 'default_value', text = "Roughness")

                        box.label(text="Bump")
                        box.prop(shader_node.inputs[12], 'default_value', text = "Threshold")
                        box.prop(shader_node.inputs[13], 'default_value', text = "Intensity")
                        box.label(text="Ambient Occlusion")
                        box.prop(shader_node.inputs[14], 'default_value', text = "Intensity")
                        box.prop(shader_node.inputs[15], 'default_value', text = "Distance")

                elif mo_type == "instancesdisplace":
                    modifier_header_basic(col)
                    disp_modifier = obj.modifiers[modifiers[0]]
                    disp_mo_input = disp_modifier.properties.inputs

                    col = layout.column(align=True)
                    box = layout.box()
                    box.label(text="Noise Texture")
                    box = box.column(align=True)
                    box.prop(getattr(disp_mo_input, "Input_3"), "value", text = "Scale")
                    box.prop(getattr(disp_mo_input, "Input_4"), "value", text = "Noise")
                    box = layout.box()
                    box.label(text="Intensity XYZ")
                    row = box.row(align=True)
                    row.prop(getattr(disp_mo_input, "Input_2"), "value", text = "")
                    box.label(text="Noise Position XYZ")
                    row = box.row(align=True)
                    row.prop(getattr(disp_mo_input, "Input_5"), "value", text = "")

                elif mo_type == "paving":
                    modifier_header_basic(layout)
                    modifier = obj.modifiers[modifiers[0]]
                    mo_input = modifier.properties.inputs

                    # MAIN PARAMETERS
                    box = layout.box()
                    box.label(text="Main Parameters", icon="MODIFIER")

                    col = box.column(align=True)
                    col.prop(getattr(mo_input, "Socket_2"), "value", text="Sharp Threshold")
                    col.prop(getattr(mo_input, "Socket_3"), "value", text="Rotation")
                    col.prop(getattr(mo_input, "Socket_4"), "value", text="Length")
                    col.prop(getattr(mo_input, "Socket_5"), "value", text="Width")
                    col.prop(getattr(mo_input, "Socket_6"), "value", text="Width Offset")
                    col.prop(getattr(mo_input, "Socket_7"), "value", text="Length Offset")
                    col.prop(getattr(mo_input, "Socket_8"), "value", text="Width Scale")
                    col.prop(getattr(mo_input, "Socket_9"), "value", text="Length Scale")

                    # BORDER PROPERTIES
                    box = layout.box()
                    box.label(text="Border Properties", icon="CURVE_DATA")

                    col = box.column(align=True)
                    col.prop(getattr(mo_input, "Socket_10"), "value", text="Resample Border")
                    col.prop(getattr(mo_input, "Socket_11"), "value", text="Length Herringbone Warp")
                    col.prop(getattr(mo_input, "Socket_12"), "value", text="Width Herringbone Warp")

                    # RANDOMIZATION
                    box = layout.box()
                    box.label(text="Randomization", icon="RNDCURVE")

                    col = box.column(align=True)
                    col.prop(getattr(mo_input, "Socket_13"), "value", text="Random Deform")
                    col.prop(getattr(mo_input, "Socket_17"), "value", text="Random Thickness")
                    col.prop(getattr(mo_input, "Socket_27"), "value", text="Seed")

                    # TILES
                    box = layout.box()
                    box.label(text="Tile Properties", icon="TEXTURE")

                    col = box.column(align=True)
                    col.prop(getattr(mo_input, "Socket_14"), "value", text="Insert Tiles")
                    col.prop(getattr(mo_input, "Socket_15"), "value", text="Taper")
                    col.prop(getattr(mo_input, "Socket_16"), "value", text="Thickness")

                    # EDGING
                    input_index = "Socket_24"
                    box = layout.box()
                    box.scale_y = 2 if not mo_input[input_index]["value"] else 1
                    props = box.operator('switch.button', text='Edging', depress=mo_input[input_index]["value"])
                    props.index = input_index

                    if mo_input[input_index]["value"]:
                        col = box.column(align=True)
                        col.prop(getattr(mo_input, "Socket_19"), "value", text="Edging Scale")
                        col.prop(getattr(mo_input, "Socket_20"), "value", text="Edging Taper")
                        col.prop(getattr(mo_input, "Socket_21"), "value", text="Edging Width")
                        col.prop(getattr(mo_input, "Socket_22"), "value", text="Edging Thickness")
                        col.prop(getattr(mo_input, "Socket_23"), "value", text="Edging Random Thickness")

                    # POSITION OFFSET
                    box = layout.box()
                    box.label(text="Position Offset", icon="PIVOT_BOUNDBOX")

                    col = box.column(align=True)
                    col.prop(getattr(mo_input, "Socket_25"), "value", text="Offset X")
                    col.prop(getattr(mo_input, "Socket_26"), "value", text="Offset Y")

                    # SURFACE
                    box = layout.box()
                    box.label(text="Surface Deformation", icon="MOD_DISPLACE")

                    col = box.column(align=True)
                    col.prop(getattr(mo_input, "Socket_18"), "value", text="Surface Deform")

                    layout.prop_search(getattr(mo_input, "Socket_28"), "value", bpy.data, "materials", text="Material", icon="MATERIAL"),

                elif mo_type == "grid":
                    modifier_header_basic(layout)
                    modifier = obj.modifiers[modifiers[0]]
                    mo_input = modifier.properties.inputs

                    # MAIN PARAMETERS
                    box = layout.box()
                    box.label(text="Main Parameters", icon="MODIFIER")

                    col = box.column(align=True)
                    col.prop(getattr(mo_input, "Socket_2"), "value", text="Sharp Threshold")
                    col.prop(getattr(mo_input, "Socket_3"), "value", text="Rotation")
                    col.prop(getattr(mo_input, "Socket_5"), "value", text="Distance X")
                    col.prop(getattr(mo_input, "Socket_4"), "value", text="Distance Y")

                    # GRID PROPERTIES
                    box = layout.box()
                    box.label(text="Grid Properties", icon="GRID")

                    col = box.column(align=True)
                    col.prop(getattr(mo_input, "Socket_30"), "value", text="Offset Grid")
                    col.prop(getattr(mo_input, "Socket_31"), "value", text="Offset X")
                    col.prop(getattr(mo_input, "Socket_32"), "value", text="Offset Y")

                    # PROFIL SETTINGS
                    box = layout.box()
                    box.label(text="Profil")
                    row = box.row(align=True)
                    row.scale_y = 1.5
                    row.operator('switch.button', text='Circle', depress=mo_input["Socket_26"]["value"]).index = "Socket_26"
                    row.operator('switch.button', text='Quad', depress=not mo_input["Socket_26"]["value"]).index = "Socket_26"
                        
                    if mo_input["Socket_26"]["value"]:
                        box.prop(getattr(mo_input, "Socket_25"), "value", text="Radius")
                        box.prop(getattr(mo_input, "Socket_27"), "value", text="Resolution")
                    else:
                        box.prop(getattr(mo_input, "Socket_28"), "value", text="Width")
                        box.prop(getattr(mo_input, "Socket_29"), "value", text="Height")

                    box.prop(getattr(mo_input, "Socket_34"), "value", text="Fix Tilt (Parallelogram)")

                    layout.prop_search(getattr(mo_input, "Socket_33"), "value", bpy.data, "materials", text="Material", icon="MATERIAL"),

                elif mo_type == "perforated_grid":
                    modifier_header_basic(layout)
                    modifier = obj.modifiers[modifiers[0]]
                    mo_input = modifier.properties.inputs

                    # MAIN PARAMETERS
                    box = layout.box()
                    box.label(text="Main Parameters", icon="MODIFIER")

                    col = box.column(align=True)
                    col.prop(getattr(mo_input, "Socket_2"), "value", text="Sharp Threshold")
                    col.prop(getattr(mo_input, "Socket_3"), "value", text="Rotation")
                    col.prop(getattr(mo_input, "Socket_4"), "value", text="Length")
                    col.prop(getattr(mo_input, "Socket_5"), "value", text="Width")

                    # OFFSET SETTINGS
                    box = layout.box()
                    box.label(text="Offset Settings", icon="GRID")

                    col = box.column(align=True)
                    col.prop(getattr(mo_input, "Socket_6"), "value", text="Width Offset")
                    col.prop(getattr(mo_input, "Socket_7"), "value", text="Length Offset")
                    col.prop(getattr(mo_input, "Socket_29"), "value", text="Hole Offset")
                    col.prop(getattr(mo_input, "Socket_26"), "value", text="Offset X")
                    col.prop(getattr(mo_input, "Socket_27"), "value", text="Offset Y")

                    # HERRINGBONE WARP ###### BROKEN : Need to fix the Node Tree !!! T_T
                    # box = layout.box()
                    # box.label(text="Herringbone Warp", icon="CURVE_DATA")

                    # col = box.column(align=True)
                    # col.prop(getattr(mo_input, "Socket_11"), "value", text="Length Herringbone Warp")
                    # col.prop(getattr(mo_input, "Socket_12"), "value", text="Width Herringbone Warp")

                    # SCALE SETTINGS
                    box = layout.box()
                    box.label(text="Scale Settings", icon="ARROW_LEFTRIGHT")

                    col = box.column(align=True)
                    col.prop(getattr(mo_input, "Socket_24"), "value", text="Length Scale")
                    col.prop(getattr(mo_input, "Socket_25"), "value", text="Width Scale")

                    # THICKNESS SETTINGS
                    box = layout.box()
                    box.label(text="Thickness Settings", icon="MOD_SOLIDIFY")

                    col = box.column(align=True)
                    col.prop(getattr(mo_input, "Socket_16"), "value", text="Thickness")
                    col.prop(getattr(mo_input, "Socket_17"), "value", text="Random Thickness")

                    # RANDOMIZATION
                    box = layout.box()
                    box.label(text="Randomization", icon="RNDCURVE")

                    col = box.column(align=True)
                    col.prop(getattr(mo_input, "Socket_28"), "value", text="Seed")

                    layout.prop_search(getattr(mo_input, "Socket_30"), "value", bpy.data, "materials", text="Material", icon="MATERIAL"),

                elif mo_type == "plank":
                    if modifiers[0] not in obj.modifiers:
                        layout.label(text="Modifier is missing", icon='ERROR')
                        layout.label(text="If present, rename it :")
                        layout.label(text=modifiers[0])
                    else:
                        modifier_header_basic(layout)
                        modifier = obj.modifiers[modifiers[0]]
                        mo_input = modifier.properties.inputs

                        # MAIN PARAMETERS
                        box = layout.box()
                        box.label(text="Main Parameters", icon="MODIFIER")

                        col = box.column(align=True)
                        col.prop(getattr(mo_input, "Socket_4"), "value", text="Length")
                        col.prop(getattr(mo_input, "Socket_5"), "value", text="Width")
                        col.prop(getattr(mo_input, "Socket_3"), "value", text="Rotation")
                        col.prop(getattr(mo_input, "Socket_2"), "value", text="Sharp Threshold (Cut)")

                        # OFFSET SETTINGS
                        box = layout.box()
                        box.label(text="Offset Settings", icon="GRID")

                        col = box.column(align=True)
                        col.prop(getattr(mo_input, "Socket_7"), "value", text="Length Offset")
                        col.prop(getattr(mo_input, "Socket_26"), "value", text="Offset X")
                        col.prop(getattr(mo_input, "Socket_27"), "value", text="Offset Y")

                        # SCALE SETTINGS
                        box = layout.box()
                        box.label(text="Scale Settings", icon="ARROW_LEFTRIGHT")

                        col = box.column(align=True)
                        col.prop(getattr(mo_input, "Socket_8"), "value", text="Width Scale")
                        col.prop(getattr(mo_input, "Socket_9"), "value", text="Length Scale")

                        # THICKNESS SETTINGS
                        box = layout.box()
                        box.label(text="Thickness Settings", icon="MOD_SOLIDIFY")

                        col = box.column(align=True)
                        col.prop(getattr(mo_input, "Socket_16"), "value", text="Thickness")
                        col.prop(getattr(mo_input, "Socket_17"), "value", text="Random Thickness")
                        col.prop(getattr(mo_input, "Socket_25"), "value", text="Tile Skew")

                        # RANDOMIZATION
                        box = layout.box()
                        box.label(text="Randomization", icon="RNDCURVE")

                        col = box.column(align=True)
                        col.prop(getattr(mo_input, "Socket_13"), "value", text="Random Deform")
                        col.prop(getattr(mo_input, "Socket_31"), "value", text="Random Rotate Y")
                        col.prop(getattr(mo_input, "Socket_32"), "value", text="Random Rotate X")
                        col.prop(getattr(mo_input, "Socket_18"), "value", text="Surface Deform")
                        col.prop(getattr(mo_input, "Socket_30"), "value", text="Random Offset")
                        col.prop(getattr(mo_input, "Socket_29"), "value", text="Seed")

                        # DELETION SETTINGS
                        box = layout.box()
                        box.label(text="Debug", icon="X")

                        col = box.column(align=True)
                        col.prop(getattr(mo_input, "Socket_28"), "value", text="Delete Small Area")

                        layout.prop_search(getattr(mo_input, "Socket_33"), "value", bpy.data, "materials", text="Material", icon="MATERIAL"),

                elif mo_type == "array_along_shape":
                    if modifiers[0] not in obj.modifiers:
                        layout.label(text="Modifier is missing", icon='ERROR')
                        layout.label(text="If present, rename it :")
                        layout.label(text=modifiers[0])
                    else:
                        modifier_header_basic(layout)
                        modifier = obj.modifiers[modifiers[0]]
                        mo_input=modifier.properties.inputs

                        # MAIN PARAMETERS
                        box = layout.box()
                        box.label(text="Main Parameters", icon="MODIFIER")

                        col = box.column(align=True)
                        col.prop(getattr(mo_input, "Socket_12"), "value", text="Count")
                        col.prop(getattr(mo_input, "Socket_2"), "value", text="Precision")
                        col.prop(getattr(mo_input, "Socket_10"), "value", text="Distance")
                        box.label(text="Array might fail on sharp edges (>70°)")

                        # RANDOMIZATION
                        box = layout.box()
                        box.label(text="Randomization", icon="RNDCURVE")

                        col = box.column(align=True)
                        col.prop(getattr(mo_input, "Socket_3"), "value", text="Position")
                        col.prop(getattr(mo_input, "Socket_4"), "value", text="Rotation X")
                        col.prop(getattr(mo_input, "Socket_5"), "value", text="Rotation Y")
                        col.prop(getattr(mo_input, "Socket_6"), "value", text="Rotation Normal")
                        col.prop(getattr(mo_input, "Socket_7"), "value", text="Scale Min")
                        col.prop(getattr(mo_input, "Socket_8"), "value", text="Scale Max")
                        col.prop(getattr(mo_input, "Socket_14"), "value", text="Seed")

                        # ORIENTATION SETTINGS
                        box = layout.box()
                        box.label(text="Orientation Settings", icon="ORIENTATION_GIMBAL")

                        col = box.column(align=True)
                        col.prop(getattr(mo_input, "Socket_9"), "value", text="Orientation Angle")
                        col.prop(getattr(mo_input, "Socket_13"), "value", text="Smooth Rotation")
                        
                        box.label(text="Lock Axis :")
                        row = box.row(align=True)
                        row.prop(getattr(mo_input, "Socket_17"), "value", text="X", toggle=True, icon='LOCKED' if getattr(mo_input, "Socket_17")["value"] else 'UNLOCKED')
                        row.prop(getattr(mo_input, "Socket_18"), "value", text="Y", toggle=True, icon='LOCKED' if getattr(mo_input, "Socket_18")["value"] else 'UNLOCKED')
                        row.prop(getattr(mo_input, "Socket_19"), "value", text="Z", toggle=True, icon='LOCKED' if getattr(mo_input, "Socket_19")["value"] else 'UNLOCKED')

                        box.label(text="TIPS : Don't use Rot Ang and Lock Axis together")

                        # COLLECTION SETTINGS
                        box = layout.box()
                        box.label(text="Target", icon="OUTLINER_COLLECTION")

                        col = box.column(align=True)
                        col.prop_search(getattr(mo_input, "Socket_16"), "value", bpy.data, "collections", text="", icon="OUTLINER_COLLECTION")

                else:
                    displaydoc == True

            #################################################################################
            # GROUP
            #################################################################################
            elif obj and obj.get("bagapie") == "bound_box":

                layout.label(text="Group :")
                box = layout.box()

                found_gp_sh = any(
                    kmi.idname == "bagapie.group"
                    for km, _ in keyconfig_merge(context.window_manager.keyconfigs.user, context.window_manager.keyconfigs.user)
                    for kmi in km.keymap_items
                )
                if found_gp_sh:
                    row = box.row(align=True)
                    row.split(factor=0.5)
                    row.label(text="Group Objects :")
                    row.label(text="Ctrl + G")
                else:
                    box.operator('bagapie.replace_shortcut', text="Add Group Shortcut")

                row = box.row(align=True)
                row.split(factor=0.5)
                row.label(text="Duplicate :")
                row.label(text="Alt + J")
                row = box.row(align=True)
                row.split(factor=0.5)
                row.label(text="Duplicate Linked :")
                row.label(text="Alt + N")

                col = layout.column()
                col.scale_y = 1.2

                row = col.row(align=True)
                split = row.split(factor=0.85, align=True)
                if obj["bagapie_locker"] == True:
                    split.operator("bagapie.editgroup", text="Make Content Selectable", icon ="RESTRICT_SELECT_OFF")
                    split.operator("bagapie.editgroup", text="All").all = True
                else:
                    split.operator("bagapie.lockgroup", text="Make Content Unlectable",icon="RESTRICT_SELECT_ON")
                    split.operator("bagapie.lockgroup", text="All").all = True
                col.operator("bagapie.instance", text= "Group to Instance", icon="LINKED")

                if is_in_local_view():
                    col.operator("bagapie.isolategroup", text= "Unisolate", icon="ZOOM_PREVIOUS")
                else:
                    col.operator("bagapie.isolategroup", text= "Isolate", icon="ZOOM_PREVIOUS")

                col.operator("bagapie.ungroup", text= "Ungroup", icon="MOD_EXPLODE")
                col.operator("bagapie.deletegroup", text= "Delete Group (ALL)", icon="TRASH")

                col.label(text="Group Content:")
                row = col.row(align=True)
                row.operator("bagapie.addgroup", text= "Add", icon="ADD")
                row.operator("bagapie.removegroup", text= "Remove", icon="REMOVE")

                row = col.row(align=True)
                row.operator("bagapie.moveonlygroup", text= "Link Obj to Group Coll Only", icon="OUTLINER_COLLECTION")
                tips = row.operator("bagapie.tooltips", text="", depress = False, icon = 'INFO')
                tips.message = "Objects in the selected group may be linked to multiple collections in your scene. This tool will remove them from all collections except the group's collection. If these objects are needed in other collections, avoid using this tool."

                if check_parent_group(obj):
                    col.operator("bagapie.move_group_modal", text= "Move Instance Group", icon="EMPTY_ARROWS").is_parent = True

                if bagapie_pref.feature_enabled == False:
                    row = col.row(align=True)
                    row.operator("bagapie.double_click_edit", text="Double Clic Edit - OFF", icon ="MOUSE_LMB")
                    tips = row.operator("bagapie.tooltips", text="", depress = False, icon = 'INFO')
                    tips.message = "Beta Feature : When double clicking on an instance or a group, it will isolate it. Double click to go back."
                else:
                    col.label(text="Double Clic Edit - ON", icon='CHECKBOX_HLT')

                displaydoc=False

            elif obj.parent and obj.parent.get("bagapie") and obj.parent["bagapie"] == "bound_box" or any(col.name.startswith("BagaPie_Group") for col in obj.users_collection):
                if check_group_instance(obj) == True:
                    col = layout.column()
                    col.scale_y = 2
                    col.operator("bagapie.move_group_modal", text= "Move Instance Group", icon="EMPTY_ARROWS").is_parent = False
                    displaydoc=False
                    
            elif obj is not None and obj.type == 'EMPTY' and any(coll.name == "BagaPie_Instances" for coll in obj.users_collection):
                if is_in_local_view()==False:
                    col = layout.column()
                    col.scale_y = 2
                    col.operator("bagapie.editinstancegroup", text= "Edit Instance Group", icon="GREASEPENCIL")

            row_tuto = layout.row(align=True)
            row_tuto.scale_y = 1.3
            row_tuto.operator("wm.url_open", text="Tutorials Playlist !", icon = 'PLAY').url = "https://youtube.com/playlist?list=PLSVXpfzibQbh_qjzCP2buB2rK1lQtkQvu&si=Y4MRQn_aTIQUXOpw"
            row_tuto.operator("wm.url_open", text="", icon = 'TEXT').url = "https://www.f12studio.fr/bagapiev6"


        # In case nothing is selected ...
        elif obj and obj.type not in obj_allowed_types:
            box = layout.box()
            box = box.column(align=True)
            box.label(text="This object is not supported")
            box.label(text="Mesh or Curve Only")

        else:
            displaydoc=True

        if is_in_local_view()==True:
            col = layout.column()
            col.scale_y = 2
            col.operator("view3d.localview", text= "Exit Editing", icon="LOOP_BACK")


        #################################################################################
        # NODES TO PANEL
        #################################################################################

        # DISPLAY MODIFIER AND MATERIAL
            # "Node to Panel" allow to create cusrom N panels for modifier and shaders in the BagaPie tab :
            #  - For geometry nodes tree : Set the "BP_" prefix in the name, description of you node tree. This prefix informs Bagapie to display your node tree.
            #  - For materials : Only for NodeGroups; Set the "BP_" prefix in the node group name or in the node name/label.
            #  - Then, to display node group inputs, set a prefix (eg V_) in the input name/description.

        if obj is not None:
            buttons_display = []
            check_BP_ = "BP_"

            if obj.type == 'MESH' or 'CURVE':

                check_URL_ = "URL_"
                check_L_ = "L_"
                check_C_ = "C_"
                check_S_ = "S_"
                check_V_ = "V_"
                check_P = "P"
                check_P_ = "P_"
                check_B = "B"
                check_R = "R"
                check_ = "_"
                layout_recur = layout
                lay_list = {}

                # DISPLAY MODIFIER
                for mo in obj.modifiers:
                    if mo.type == "NODES" and mo is not None and mo.node_group is not None:

                        # DISPLAY MODIFIER PANEL
                        if  mo.name.startswith("BP_") or mo.node_group.name.startswith("BP_") or mo.node_group.description.startswith("BP_"):
                            displaydoc = False
                            row_head = layout.row(align=True)
                            row_headception = row_head.row(align=True)
                            row_headception.alignment  = 'LEFT'
                            row_headception.prop(mo, 'show_expanded', text="", emboss=False)
                            row_headception.prop(mo, 'show_expanded', text=mo.node_group.name, icon = 'GEOMETRY_NODES', emboss=False)
                            row_headception2 = row_head.row(align=True)
                            row_headception2.alignment  = 'RIGHT'
                            row_headception2.prop(mo, 'show_on_cage', text="")
                            row_headception2.prop(mo, 'show_in_editmode', text="")
                            row_headception2.prop(mo, 'show_viewport', text="")
                            row_headception2.prop(mo, 'show_render', text="")
                            if mo.show_expanded == False:
                                continue

                            for input in mo.node_group.interface.items_tree:
                                Nodes_to_Panel_Geometry_Nodes(input,mo,layout,buttons_display,lay_list,layout_recur)
                        
                    
                        # DISPLAY NODES GROUPS SUBPANELS
                        for node in mo.node_group.nodes:
                            if node.type == 'GROUP':
                                if node.node_tree.description.startswith(check_BP_) or node.node_tree.name.startswith(check_BP_) or node.name.startswith(check_BP_) or node.label.startswith(check_BP_):
                                    box=layout.box()
                                    row_head = box.row(align=True)
                                    row_head.alignment  = 'LEFT'
                                    row_head.prop(node, 'hide', text="", icon = 'RIGHTARROW' if node.hide else 'DOWNARROW_HLT', emboss=False)
                                    if node.label != "":
                                        name = node.label
                                    else:
                                        name = node.node_tree.name
                                    row_head.prop(node, 'hide', text=name, emboss=False)
                                    if node.hide:
                                        continue
                                    for input in node.inputs:
                                        if input != node.inputs[0]:
                                            Nodes_to_Panel_Geometry_Nodes(input,node,box,buttons_display,lay_list,layout_recur,input_id="default_value")


                        if mo.is_active:
                            layout.operator("bagapie.geopack_create_modifier", text = "Save as GeoPack Modifier")

                # DISPLAY MATERIAL
                for mat in obj.material_slots:
                    if mat.material: #if a material is assign to the slot
                        material = bpy.data.materials[mat.name]
                        for node in material.node_tree.nodes:
                            if node.type == 'GROUP':
                                if node.node_tree.description.startswith(check_BP_) or node.node_tree.name.startswith(check_BP_) or node.name.startswith(check_BP_) or node.label.startswith(check_BP_):
                                    displaydoc = False
                                    mat_name = node.node_tree.name.removeprefix('BP_')
                                    if node.label != "":
                                        mat_name=node.label.removeprefix('BP_')
                                    row_head = layout.row(align=True)
                                    row_head.alignment  = 'LEFT'
                                    row_head.prop(node, 'hide', text="", icon = 'RIGHTARROW' if node.hide else 'DOWNARROW_HLT', emboss=False)
                                    row_head.prop(node, 'hide', text=mat_name, icon='MATERIAL', emboss=False)
                                    if node.hide:
                                        continue

                                    for input in node.inputs:
                                        id = input.name
                                        idd = node.node_tree.interface.items_tree[input.name].description

                                        checks = ["URL_", "L_", "C_", "S_", "V_", "P", "P_", "B", "B_", "R", "R_", "1", "2", "3", "4", "5", "6", "7", "8", "9"]
                                        for c in checks:
                                            if idd.startswith(c):
                                                if id.startswith(("B", "R")):
                                                    id = " "+input.name
                                                id = idd + id
                                                break
                                        
                                        Material_Input_Type(id, idd, input, check_L_, check_S_, check_V_, layout)
                                            
                                        check_B = "B"
                                        check_R = "R"
                                        if id.startswith(check_B) or idd.startswith(check_B) or id.startswith(check_R) or idd.startswith(check_R):
                                            id_final, idd_final, layout_final = Recustive_ui(id, idd, layout_recur, layout, lay_list, "")
                                            Material_Input_Type(id_final, idd_final, input, check_L_, check_S_, check_V_, layout_final)
                                            layout_recur = layout_final

            if obj.name.startswith("Ivy_Parent"):
                box = layout.box()
                box.scale_y = 2
                box.operator("bagapie.removesingleivy", text= "Delete this part of ivy")

        # DISPLAY DOC AND YOUTUBE TUTORIAL
        if displaydoc == True and is_in_local_view() == False:
            box = layout.box()
            box.scale_y = 0.5
            
            row = box.row(align=True)
            split = row.split(factor=0.7)
            split.label(text="Menu :")
            split.label(text="Key :")

            box.separator(factor = 0.5)

            wm = bpy.context.window_manager
            kc_user = wm.keyconfigs.user
            display_keymaps = kc_user.keymaps

            found_gp_sh = False
            for km in display_keymaps:
                for kmi in km.keymap_items:
                    if kmi.idname == "bagapie.group":
                        found_gp_sh = True
                        break
                if found_gp_sh:
                    break
            
            for km in display_keymaps:
                for kmi in km.keymap_items:
                    # PIE MENU MAIN
                    if kmi.name == 'BagaPie':
                        shortcut = format_shortcut(kmi)
                        row = box.row(align=True)
                        split = row.split(factor=0.7)
                        split.label(text="Main Pie (Object Mode)")
                        split.label(text=shortcut)

                    # PIE MENU TOOLS
                    if kmi.name == 'BagaPie Tools':
                        shortcut = format_shortcut(kmi)
                        row = box.row(align=True)
                        split = row.split(factor=0.7)
                        split.label(text="Tools Pie (Edit Mode)")
                        split.label(text=shortcut)

                    # GEOPACK
                    if kmi.name == 'BagaPie GeoPack':
                        shortcut = format_shortcut(kmi)
                        row = box.row(align=True)
                        split = row.split(factor=0.7)
                        split.label(text="GeoPack")
                        split.label(text=shortcut)

                    # GROUP SHORTCUT
                    if kmi.idname == "bagapie.group" and found_gp_sh == True:
                        row = box.row(align=True)
                        split = row.split(factor=0.7)
                        split.label(text="Group") 
                        shortcut = format_shortcut(kmi)
                        split.label(text=shortcut)
                    elif found_gp_sh == False:
                        row = box.row(align=True)
                        split = row.split(factor=0.7)
                        split.label(text="Group") 
                        split.operator('bagapie.replace_shortcut', text="+")
                        found_gp_sh = True


###################################################################################
# NODE TO PANEL UTILS
###################################################################################
def Dispay_Value(input, col, mo, input_id, id):
    mo_inputs=mo.properties.inputs
    input_id_r = input_id.removeprefix('["').removesuffix('"]') # Blender 5.2 update
    if input == mo:
        col.prop(getattr(mo_inputs, input_id_r), "value", text=id)
    elif input.bl_socket_idname == 'NodeSocketMaterial':
        col.prop_search(getattr(mo_inputs, input_id_r), "value", bpy.data, "materials", text=id, icon="MATERIAL"), 
    elif input.bl_socket_idname == 'NodeSocketObject':
        col.prop_search(getattr(mo_inputs, input_id_r), "value", bpy.data, "objects", text=id, icon="OBJECT_DATA"), 
    elif input.bl_socket_idname == 'NodeSocketCollection':
        col.prop_search(getattr(mo_inputs, input_id_r), "value", bpy.data, "collections", text=id, icon="OUTLINER_COLLECTION"), 
    elif input.bl_socket_idname == 'NodeSocketImage':
        col.prop_search(getattr(mo_inputs, input_id_r), "value", bpy.data, "images", text=id, icon="IMAGE"), 
    else:
        col.prop(getattr(mo_inputs, input_id_r), "value", text=id)

def Format_Id(id, check, layout):
    id = id.removeprefix(check)
    col = layout.column()
    if id[0].isdigit() and id[1] == "_":
        col.scale_y = int(id[0])
        id = id.removeprefix(str(id[0])+"_")
    return id, col

def Display_Curve(mo, id, col):
    found=False
    for node in mo.node_group.nodes:
        if node.name.endswith(id) or node.label.endswith(id):
            if node.type == 'VALTORGB':
                col.template_color_ramp(node, "color_ramp")
                found=True
                break
            elif node.type == 'CURVE_FLOAT':
                col.template_curve_mapping(node, "mapping")
                found=True
                break
    if not found:
        box=col.box()
        box.scale_y=0.6
        box.label(text="'"+id +"' Node not found")
        box.label(text="Node and Input must have the same name")

def Display_Button(input, mo, col, id):
    input_index = input.identifier
    if mo.properties.inputs[input_index]["value"] == gn_bool_version(1):
        props = col.operator('switch.boolcustom', text=id, depress = True)
    else:
        props = col.operator('switch.boolcustom', text=id, depress = False)
    props.index = input_index
    props.modifier = mo.name

def Display_URL(mo, input, col, id):
    url_link = mo.properties.inputs[input.identifier]["value"]
    if url_link == "":
        url_link = input.default_value
    if input.socket_type == "NodeSocketString" and url_link != "":
        col.operator("wm.url_open", text=id, icon = 'URL').url = url_link
    elif input.socket_type != "NodeSocketString":
        col.label(text="'"+id+"' input must be String type", icon = 'URL')
    else:
        col.label(text="'"+id+"': Set URL as input default value", icon = 'URL')

def Material_Input_Type(id, idd, input, check_L_, check_S_, check_V_, layout):
    if id.startswith(check_L_) or idd.startswith(check_L_):
        id, col = Format_Id(id, check_L_, layout)
        col.label(text=id)

    elif id.startswith(check_S_) or idd.startswith(check_S_):
        id = id.removeprefix(check_S_)
        layout.separator(factor = int(id[0]))

    elif id.startswith(check_V_) or idd.startswith(check_V_):
        id, col = Format_Id(id, check_V_, layout)
        col.prop(input, "default_value", text=id)

def GeoNode_Input_Type(id, idd, input, mo, input_id, check_L_, check_S_, check_V_, check_C_, check_P_, check_URL_, layout):
    if id.startswith(check_L_) or idd.startswith(check_L_):
        id, col = Format_Id(id, check_L_, layout)
        col.label(text=id)

    elif id.startswith(check_S_) or idd.startswith(check_S_):
        id = id.removeprefix(check_S_)
        layout.separator(factor = int(id[0]))

    elif id.startswith(check_V_) or idd.startswith(check_V_):
        id, col = Format_Id(id, check_V_, layout)
        Dispay_Value(input, col, mo, input_id, id)

    elif id.startswith(check_C_) or idd.startswith(check_C_):
        id, col = Format_Id(id, check_C_, layout)
        Display_Curve(mo, id, col)

    elif id.startswith(check_P_) or idd.startswith(check_P_) and input.bl_socket_idname == 'NodeSocketBool':
        id, col = Format_Id(id, check_P_, layout)
        Display_Button(input, mo, col, id)

    elif id.startswith(check_URL_) or idd.startswith(check_URL_):
        id, col = Format_Id(id, check_URL_, layout)
        Display_URL(mo, input, col, id)

def Display_All(id, idd, mo, input, input_id, layout):
    check_URL_ = "URL_"
    check_L_ = "L_"
    check_C_ = "C_"
    check_S_ = "S_"
    check_V_ = "V_"

    if id.startswith(check_URL_) or idd.startswith(check_URL_):
        id, col = Format_Id(id, check_URL_, layout)
        Display_URL(mo, input, col, id)
        return True
        
    elif id.startswith(check_L_) or idd.startswith(check_L_):
        id, col = Format_Id(id, check_L_, layout)
        col.label(text=id)
        return True

    elif id.startswith(check_C_) or idd.startswith(check_C_):
        id, col = Format_Id(id, check_C_, layout)
        Display_Curve(mo, id, col)
        return True

    elif id.startswith(check_S_) or idd.startswith(check_S_):
        id = id.removeprefix(check_S_)
        layout.separator(factor = int(id[0]))
        return True

    elif id.startswith(check_V_) or idd.startswith(check_V_):
        id, col = Format_Id(id, check_V_, layout)
        Dispay_Value(input, col, mo, input_id, id)
        return True
    return False

def remove_prefix(id, idd, check_X):
    id = id.removeprefix(check_X)
    idd = idd.removeprefix(check_X)
    return id, idd

def Recustive_ui(id, idd, layout_recur, layout, lay_list, id_name):
    layout_temp = layout_recur

    for prefix, suffix in [("B", "B"), ("R", "R")]:
        if (id.startswith(prefix) or idd.startswith(prefix)) and "_" in id:
            layout = lay_list.get(id_name, layout)
            id_name += suffix
            id, idd = remove_prefix(id, idd, prefix)

            if id.startswith("_") or idd.startswith("_"):
                id, idd = remove_prefix(id, idd, "_")

                if prefix == "B":
                    layout_recur = layout.box().column(align=True)
                elif prefix == "R":
                    layout_recur = layout.row(align=True)

                layout = layout_recur
                lay_list[id_name] = layout_recur
            else:
                layout = layout_temp

            return Recustive_ui(id, idd, layout_recur, layout, lay_list, id_name)

    if lay_list.get(id_name) is not None:
        layout_recur = lay_list[id_name]

    return id, idd, layout_recur

def Recursive_call(check_B,id,idd,check_R,mo,input_id,input,layout,lay_list,layout_recur):
    if id.startswith(check_B) or idd.startswith(check_B) or id.startswith(check_R) or idd.startswith(check_R):
        id_final, idd_final, layout_final = Recustive_ui(id, idd, layout_recur, layout, lay_list, "")
        Display_All(id_final, idd_final, mo, input, input_id, layout_final)
        layout_recur = layout_final

def Nodes_to_Panel_Geometry_Nodes(input,mo,layout,buttons_display,lay_list,layout_recur,input_id="NONE"):
    check_URL_ = "URL_"
    check_L_ = "L_"
    check_C_ = "C_"
    check_S_ = "S_"
    check_V_ = "V_"
    check_P = "P"
    check_P_ = "P_"
    check_B = "B"
    check_R = "R"
    check_ = "_"
    
    if input_id == "NONE":
        id = input.name
        idd = input.description
    else:
        identifier = input.identifier
        inputs = list(mo.node_tree.interface.items_tree.values())
        index = next((i for i, item in enumerate(inputs) if item.identifier == identifier), -1)
        id = mo.node_tree.interface.items_tree[index].name
        idd = mo.node_tree.interface.items_tree[index].description
        mo=input


    checks = ["URL_", "L_", "C_", "S_", "V_", "P", "P_", "B", "B_", "R", "R_", "1", "2", "3", "4", "5", "6", "7", "8", "9"]
    for c in checks: # This loop properly combine the input name and description
        if idd.startswith(c):
            if id.startswith(("B", "R")):
                id = " "+input.name
            desc=idd
            checks_desc = checks[:]
            checks_desc.append("_") 
            while any(desc.startswith(prefix) for prefix in checks_desc):
                for prefix in checks_desc:
                    if desc.startswith(prefix):
                        desc = desc.removeprefix(prefix)
            idd = idd[:len(idd) - len(desc)]
            id = idd + id
            break
    if input_id == "NONE":
        input_id = '["{}"]'.format(bpy.utils.escape_identifier(input.identifier))
    

    # Display_All => Draw values, labels, URL, curves, separators
    if Display_All(id, idd, mo, input, input_id, layout) == False:

        # BUTTONS
        if id.startswith(check_P) or idd.startswith(check_P) and input.bl_socket_idname == 'NodeSocketBool':
            id = id.removeprefix(check_P)
            
            if id.startswith(check_) or idd.startswith(check_):
                id, col = Format_Id(id, check_, layout)
                Display_Button(input, mo, col, id)

            elif id[0].isdigit() and id[1] == '_':
                buttons_display.append([id[0], mo.properties.inputs[input.identifier]])

                id = id[2:]
                col = layout.column()
                if id[0].isdigit() and id[1] == "_":
                    col.scale_y = int(id[0])
                    id = id.removeprefix(str(id[0])+"_")
                    
                Display_Button(input, mo, col, id)
        
        # BUTTONS CHILDREN
        elif id[0].isdigit():
            button_id = id[0]
            id = id.removeprefix(id[0])
            display_line = False

            for button in buttons_display:
                if button_id in button[0] and button[1]:
                    display_line = True

            if display_line:
                GeoNode_Input_Type(id, idd, input, mo, input_id, check_L_, check_S_, check_V_, check_C_, check_P_, check_URL_, layout)

                Recursive_call(check_B,id,idd,check_R,mo,input_id,input,layout,lay_list,layout_recur)
        
        # BOX AND ROW INCEPTION
        else:
            Recursive_call(check_B,id,idd,check_R,mo,input_id,input,layout,lay_list,layout_recur)
                            

###################################################################################
# UI OP
###################################################################################
class BAGAPIE_OP_modifierDisplay(Operator):
    """Hide modifier in viewport"""
    bl_idname = "hide.viewport"
    bl_label = "Hide Viewport"

    index: bpy.props.IntProperty(default=0) # type: ignore

    def execute(self, context):
        obj = context.object
        val = json.loads(obj.bagapieList[self.index]['val'])
        modifiers = val['modifiers']
        mo_type = val['name']
        avoid_string = "BagaPie_Texture"

        if mo_type == "scatter":
            scatter_modifier = obj.modifiers.get("BagaPie_Scatter")
            scatt_nde_group = scatter_modifier.node_group
            scatter_node = scatt_nde_group.nodes[modifiers[1]]
            scatter_node_input_value = scatter_node.inputs[22].default_value

            if scatter_node_input_value:
                scatt_nde_group.nodes[modifiers[1]].inputs[22].default_value = False
            else:
                scatt_nde_group.nodes[modifiers[1]].inputs[22].default_value = True

        elif mo_type == "pointeffector":
            scatter_modifier = obj.modifiers.get("BagaPie_Scatter")
            scatt_nde_group = scatter_modifier.node_group
            
            scatt_nde_visibility_op = scatt_nde_group.nodes[modifiers[1]].inputs[5].default_value

            if scatt_nde_visibility_op:
                scatt_nde_group.nodes[modifiers[1]].inputs[5].default_value = False
            else:
                scatt_nde_group.nodes[modifiers[1]].inputs[5].default_value = True

        elif mo_type == "camera":
            scatter_modifier = obj.modifiers.get("BagaPie_Scatter")
            scatt_nde_group = scatter_modifier.node_group
            
            scatt_nde_visibility_op = scatt_nde_group.nodes[modifiers[1]].inputs[3].default_value

            if scatt_nde_visibility_op:
                scatt_nde_group.nodes[modifiers[1]].inputs[3].default_value = False
            else:
                scatt_nde_group.nodes[modifiers[1]].inputs[3].default_value = True

        elif mo_type == "boolean":
            if obj.modifiers[modifiers[0]].show_viewport:
                for mo in modifiers:
                    if mo.startswith(("BagaBool","BagaBevel")) and not mo.startswith("BagaBevelObj"):
                        obj.modifiers[mo].show_viewport = False
                    else:
                        bool_obj = bpy.data.objects[modifiers[5]]
                        if mo != modifiers[5]:
                            if bool_obj.modifiers[mo].show_in_editmode and mo.startswith("BagaSolidify"):
                                bool_obj.modifiers[mo].show_viewport = False
                            elif not mo.startswith("BagaSolidify"):
                                bool_obj.modifiers[mo].show_viewport = False

            else:
                for mo in modifiers:
                    if mo.startswith(("BagaBool","BagaBevel")) and not mo.startswith("BagaBevelObj"):
                        obj.modifiers[mo].show_viewport = True
                    else:
                        bool_obj = bpy.data.objects[modifiers[5]]
                        if mo != modifiers[5]:
                            if bool_obj.modifiers[mo].show_in_editmode and mo.startswith("BagaSolidify"):
                                bool_obj.modifiers[mo].show_viewport = True
                            elif not mo.startswith("BagaSolidify"):
                                bool_obj.modifiers[mo].show_viewport = True

        elif mo_type == "window":

            if modifiers[6] == "win":
                wall = bpy.data.objects[modifiers[7]]
                if obj.modifiers[modifiers[0]].show_viewport:
                    for mo in modifiers:
                        if mo.startswith("Baga") and mo != modifiers[4] and mo != modifiers[5]:
                            obj.modifiers[mo].show_viewport = False
                        elif mo == modifiers[5]:
                            wall.modifiers[mo].show_viewport = False
                else:
                    for mo in modifiers:
                        if mo.startswith("Baga") and mo != modifiers[4] and mo != modifiers[5]:
                            obj.modifiers[mo].show_viewport = True
                        elif mo == modifiers[5]:
                            wall.modifiers[mo].show_viewport = True

            elif modifiers[6] == "wall":
                window = bpy.data.objects[modifiers[7]]
                if obj.modifiers[modifiers[0]].show_viewport:
                    for mo in modifiers:
                        if mo.startswith("Baga") and mo != modifiers[0] and mo != modifiers[5] and mo != modifiers[7]:
                            window.modifiers[mo].show_viewport = False
                        elif mo == modifiers[0] and mo != modifiers[7]:
                            obj.modifiers[mo].show_viewport = False
                else:
                    for mo in modifiers:
                        if mo.startswith("Baga") and mo != modifiers[0] and mo != modifiers[5] and mo != modifiers[7]:
                            window.modifiers[mo].show_viewport = True
                        elif mo == modifiers[0] and mo != modifiers[7]:
                            obj.modifiers[mo].show_viewport = True

        elif mo_type == "wallbrick":
            if obj.type=='MESH':
                mo = modifiers[0]
                if obj.modifiers[modifiers[0]].show_viewport:
                    if mo.startswith("Baga") and not mo.startswith(avoid_string):
                        obj.modifiers[mo].show_viewport = False
                else:
                    if mo.startswith("Baga") and not mo.startswith(avoid_string):
                        obj.modifiers[mo].show_viewport = True
            else:
                mo = modifiers[1]
                if obj.modifiers[modifiers[1]].show_viewport:
                    if mo.startswith("Baga") and not mo.startswith(avoid_string):
                        obj.modifiers[mo].show_viewport = False
                else:
                    if mo.startswith("Baga") and not mo.startswith(avoid_string):
                        obj.modifiers[mo].show_viewport = True

        elif mo_type == "ivy":
            if obj.modifiers[modifiers[0]].show_viewport:
                mo = modifiers[0]
                obj.modifiers[mo].show_viewport = False
            else:
                mo = modifiers[0]
                obj.modifiers[mo].show_viewport = True

        else:
            if obj.modifiers[modifiers[0]].show_viewport:
                for mo in modifiers:
                    if mo.startswith("Baga") and not mo.startswith(avoid_string):
                        obj.modifiers[mo].show_viewport = False
            else:
                for mo in modifiers:
                    if mo.startswith("Baga") and not mo.startswith(avoid_string):
                        obj.modifiers[mo].show_viewport = True

        return {'FINISHED'}


class BAGAPIE_OP_modifierDisplayRender(Operator):
    """Hide modifier in render"""
    bl_idname = "hide.render"
    bl_label = "Hide Render"

    index: bpy.props.IntProperty(default=0)

    def execute(self, context):
        obj = context.object
        val = json.loads(obj.bagapieList[self.index]['val'])
        modifiers = val['modifiers']
        mo_type = val['name']
        avoid_string = "BagaPie_Texture"

        if mo_type == "scatter":
            scatter_modifier = obj.modifiers.get("BagaPie_Scatter")
            scatt_nde_group = scatter_modifier.node_group
            scatter_node = scatt_nde_group.nodes[modifiers[1]]
            scatter_node_input_value = scatter_node.inputs[23].default_value

            if scatter_node_input_value:
                scatt_nde_group.nodes[modifiers[1]].inputs[23].default_value = False
            else:
                scatt_nde_group.nodes[modifiers[1]].inputs[23].default_value = True

        elif mo_type == "pointeffector":
            scatter_modifier = obj.modifiers.get("BagaPie_Scatter")
            scatt_nde_group = scatter_modifier.node_group
            
            scatt_nde_visibility_bool = scatt_nde_group.nodes[modifiers[1]].inputs[6].default_value

            if scatt_nde_visibility_bool:
                scatt_nde_group.nodes[modifiers[1]].inputs[6].default_value = False
            else:
                scatt_nde_group.nodes[modifiers[1]].inputs[6].default_value = True

        elif mo_type == "camera":
            scatter_modifier = obj.modifiers.get("BagaPie_Scatter")
            scatt_nde_group = scatter_modifier.node_group
            
            scatt_nde_visibility_bool = scatt_nde_group.nodes[modifiers[1]].inputs[4].default_value

            if scatt_nde_visibility_bool:
                scatt_nde_group.nodes[modifiers[1]].inputs[4].default_value = False
            else:
                scatt_nde_group.nodes[modifiers[1]].inputs[4].default_value = True

        elif mo_type == "boolean":
            if obj.modifiers[modifiers[0]].show_render:
                for mo in modifiers:
                    if mo.startswith(("BagaBool","BagaBevel")) and not mo.startswith("BagaBevelObj"):
                        obj.modifiers[mo].show_render = False
                    else:
                        bool_obj = bpy.data.objects[modifiers[5]]
                        if mo != modifiers[5]:
                            if bool_obj.modifiers[mo].show_in_editmode and mo.startswith("BagaSolidify"):
                                bool_obj.modifiers[mo].show_render = False
                            elif not mo.startswith("BagaSolidify"):
                                bool_obj.modifiers[mo].show_render = False

            else:
                for mo in modifiers:
                    if mo.startswith(("BagaBool","BagaBevel")) and not mo.startswith("BagaBevelObj"):
                        obj.modifiers[mo].show_render = True
                    else:
                        bool_obj = bpy.data.objects[modifiers[5]]
                        if mo != modifiers[5]:
                            if bool_obj.modifiers[mo].show_in_editmode and mo.startswith("BagaSolidify"):
                                bool_obj.modifiers[mo].show_render = True
                            elif not mo.startswith("BagaSolidify"):
                                bool_obj.modifiers[mo].show_render = True

        elif mo_type == "window":

            if modifiers[6] == "win":
                wall = bpy.data.objects[modifiers[7]]
                if obj.modifiers[modifiers[0]].show_render:
                    for mo in modifiers:
                        if mo.startswith("Baga") and mo != modifiers[4] and mo != modifiers[5]:
                            obj.modifiers[mo].show_render = False
                        elif mo == modifiers[5]:
                            wall.modifiers[mo].show_render = False
                else:
                    for mo in modifiers:
                        if mo.startswith("Baga") and mo != modifiers[4] and mo != modifiers[5]:
                            obj.modifiers[mo].show_render = True
                        elif mo == modifiers[5]:
                            wall.modifiers[mo].show_render = True

            elif modifiers[6] == "wall":
                window = bpy.data.objects[modifiers[7]]
                if obj.modifiers[modifiers[0]].show_render:
                    for mo in modifiers:
                        if mo.startswith("Baga") and mo != modifiers[0] and mo != modifiers[5] and mo != modifiers[7]:
                            window.modifiers[mo].show_render = False
                        elif mo == modifiers[0] and mo != modifiers[7]:
                            obj.modifiers[mo].show_render = False
                else:
                    for mo in modifiers:
                        if mo.startswith("Baga") and mo != modifiers[0] and mo != modifiers[5] and mo != modifiers[7]:
                            window.modifiers[mo].show_render = True
                        elif mo == modifiers[0] and mo != modifiers[7]:
                            obj.modifiers[mo].show_render = True

        elif mo_type == "wallbrick":
            if obj.type=='MESH':
                mo = modifiers[0]
                if obj.modifiers[modifiers[0]].show_render:
                    if mo.startswith("Baga") and not mo.startswith(avoid_string):
                        obj.modifiers[mo].show_render = False
                else:
                    if mo.startswith("Baga") and not mo.startswith(avoid_string):
                        obj.modifiers[mo].show_render = True
            else:
                mo = modifiers[1]
                if obj.modifiers[modifiers[1]].show_render:
                    if mo.startswith("Baga") and not mo.startswith(avoid_string):
                        obj.modifiers[mo].show_render = False
                else:
                    if mo.startswith("Baga") and not mo.startswith(avoid_string):
                        obj.modifiers[mo].show_render = True

        else:
            if obj.modifiers[modifiers[0]].show_render:
                for mo in modifiers:
                    if mo.startswith("Baga") and not mo.startswith(avoid_string):
                        obj.modifiers[mo].show_render = False
            else:
                for mo in modifiers:
                    if mo.startswith("Baga") and not mo.startswith(avoid_string):
                        obj.modifiers[mo].show_render = True

        return {'FINISHED'}


class BAGAPIE_OP_modifierApply(Operator):
    """Apply all related modifier"""
    bl_idname = "apply.modifier"
    bl_label = "apply.modifier"

    index: bpy.props.IntProperty(default=0)

    @classmethod
    def poll(cls, context):
        return (bpy.context.mode == 'OBJECT')
    
    def execute(self, context):
        obj = context.object
        obj.select_set(True)
        val = json.loads(obj.bagapieList[self.index]['val'])
        modifiers = val['modifiers']
        avoid_string = "BagaPie_Texture"
        mo_type = val['name']

        if mo_type == "window":
            obj.data = obj.data.copy()
        
        for mo in modifiers:
            if mo.startswith("Baga") and not mo.startswith(avoid_string):

                if mo_type == 'wallbrick':
                    bpy.ops.object.convert(target='MESH')

                elif mo_type == 'array':
                    mo_name = obj.modifiers[mo].node_group.name

                    if "Line" in mo_name:
                        obj.modifiers[mo]["Input_10"] = gn_bool_version(1)
                    elif "Grid" in mo_name:
                        obj.modifiers[mo]["Input_14"] = gn_bool_version(1)
                    elif "Circle" in mo_name:
                        obj.modifiers[mo]["Input_21"] = gn_bool_version(1)
                    elif "Curve" in mo_name:
                        obj.modifiers[mo]["Input_13"] = gn_bool_version(1)

                    bpy.ops.object.convert(target='MESH')

                elif mo_type == 'pipes':
                    mo_name = obj.modifiers[mo].node_group.name
                
                    obj.modifiers[mo]["Input_27"] = gn_bool_version(1)

                    obj = context.object
                    val = json.loads(obj.bagapieList[obj.bagapieIndex]['val'])
                    modifiers = val['modifiers']
                    modifier = obj.modifiers[modifiers[0]]
                    coll = mo_input["Input_13"]["value"]

                    bpy.ops.object.convert(target='MESH')
                    RemoveOBJandDeleteColl(self,context, coll)

                elif mo_type == 'cable':
                    mo_name = obj.modifiers[mo].node_group.name

                    obj = context.object
                    val = json.loads(obj.bagapieList[obj.bagapieIndex]['val'])
                    modifiers = val['modifiers']
                    modifier = obj.modifiers[modifiers[0]]
                    coll = mo_input["Input_28"]["value"]

                    bpy.ops.object.convert(target='MESH')
                    RemoveOBJandDeleteColl(self,context, coll)

                elif mo_type == 'fence':
                    mo_name = obj.modifiers[mo].node_group.name

                    obj = context.object
                    val = json.loads(obj.bagapieList[obj.bagapieIndex]['val'])
                    modifiers = val['modifiers']
                    modifier = obj.modifiers[modifiers[0]]

                    bpy.ops.object.convert(target='MESH')

                elif mo_type == 'handrail':
                    
                    bpy.ops.object.convert(target='MESH')
                    
                elif mo_type == 'beamwire':
                    mo_name = obj.modifiers[mo].node_group.name
                
                    obj.modifiers[mo]["Input_12"] = gn_bool_version(1)
                    obj.modifiers[mo].show_viewport = False # Just a way to update model
                    obj.modifiers[mo].show_viewport = True

                    bpy.ops.object.modifier_apply(modifier=mo)

                elif mo_type == 'scatter':
                    
                    bpy.ops.use.applyscatter('INVOKE_DEFAULT')

                    return {'FINISHED'}
                    
                elif mo_type == 'ivy':
                    
                    bpy.ops.use.applyivy('INVOKE_DEFAULT')

                    return {'FINISHED'}
                
                elif mo_type == "window":
                    
                    if modifiers[6] == "win":
                        if mo =="BagaWindow_Displace":
                            if obj.modifiers[mo].strength == 0.0:
                                obj.modifiers[mo].strength = 0.001

                    elif modifiers[6] == "wall":
                        win = bpy.data.objects[modifiers[7]]
                        if mo =="BagaWindow_Displace":
                            if win.modifiers[mo].strength == 0.0:
                                win.modifiers[mo].strength = 0.001

                elif mo_type == "boolean":
                    if mo =="BagaBevel":
                        if obj.modifiers[mo].width == 0.0:
                            bpy.ops.object.modifier_remove(modifier=mo)
                    elif mo =="BagaBool":
                        bpy.ops.object.modifier_apply(modifier=mo)
                
                else:
                    try:
                        bpy.ops.object.modifier_apply(modifier=mo)
                    except:
                        bpy.ops.object.modifier_remove(modifier=mo)

        if mo_type == "boolean":
            bool_obj = bpy.data.objects[modifiers[5]]
            bpy.data.objects.remove(bool_obj)

        elif mo_type == "window":
            for mod in modifiers:
                print(mod)

            if modifiers[6] == "win":############################################
                win_bool = bpy.data.objects[modifiers[4]]
                win = obj
                wall = bpy.data.objects[modifiers[7]]

                # applique le modifier sur le mur
                bpy.context.view_layer.objects.active = wall
                try:
                    bpy.ops.object.modifier_apply(modifier=modifiers[5])
                except:
                    bpy.ops.object.modifier_remove(modifier=modifiers[5])

                # delete boolean
                bpy.data.objects.remove(win_bool)

                # applique le modifier de la vitre
                bpy.context.view_layer.objects.active = win
                for mo in win.modifiers:
                    m = mo.name
                    if m.startswith("BagaWindow") and not m.startswith("BagaWindow_Bool"):
                        try:
                            bpy.ops.object.modifier_apply(modifier=m)
                        except:
                            bpy.ops.object.modifier_remove(modifier=m)

                # relève le modifier de la liste
                index = 0
                for i in range(len(wall.bagapieList)):
                    index = index + i
                    val = json.loads(wall.bagapieList[index]['val'])
                    modifiers = val['modifiers']
                    mo_type = val['name']
                    if mo_type == "window":
                        wall.bagapieList.remove(index)
                        index -=1
                bpy.context.view_layer.objects.active = obj




            elif modifiers[6] == "wall":############################################
                win_bool = bpy.data.objects[modifiers[5]]
                win = bpy.data.objects[modifiers[7]]
                wall = obj


                # applique le modifier sur le mur
                bpy.context.view_layer.objects.active = wall
                try:
                    bpy.ops.object.modifier_apply(modifier=modifiers[0])
                except:
                    bpy.ops.object.modifier_remove(modifier=modifiers[0])

                # delete boolean
                bpy.data.objects.remove(win_bool)

                # applique le modifier de la vitre
                bpy.context.view_layer.objects.active = win
                for mo in win.modifiers:
                    m = mo.name
                    if m.startswith("BagaWindow") and not m.startswith("BagaWindow_Bool"):
                        try:
                            bpy.ops.object.modifier_apply(modifier=m)
                        except:
                            bpy.ops.object.modifier_remove(modifier=m)

                # relève le modifier de la liste
                index = 0
                for i in range(len(win.bagapieList)):
                    index = index + i
                    val = json.loads(win.bagapieList[index]['val'])
                    modifiers = val['modifiers']
                    mo_type = val['name']
                    if mo_type == "window":
                        win.bagapieList.remove(index)
                        index -=1
                bpy.context.view_layer.objects.active = obj


        obj.bagapieList.remove(self.index)

        return {'FINISHED'}


class BAGAPIE_OP_addparttype(Operator):
    """WIP"""
    bl_idname = "switch.glass"
    bl_label = "switch.glass"

    index: IntProperty(
        name="G",
        description="Import or link",
        default = 1
        )

    part_type: StringProperty(
        name="G",
        description="Import or link",
        default = "GLASS"
        )

    current_state: BoolProperty(
        name="M",
        description="World or Cursor",
        default = False
        )  

    def execute(self, context):
        obj = context.object
        glass_statut = obj['line_bool_g']
        stat =glass_statut[self.index]

        if stat == gn_bool_version(1):
            glass_statut[self.index] = gn_bool_version(0)
        else:
            glass_statut[self.index] = gn_bool_version(1)

        return {'FINISHED'}


class BAGAPIE_OP_switchinput(Operator):
    """Switch GN input"""
    bl_idname = "switch.button"
    bl_label = "switch.button"

    index: bpy.props.StringProperty(name="None") # type: ignore

    def execute(self, context):
        obj = context.object
        val = json.loads(obj.bagapieList[obj.bagapieIndex]['val'])
        modifiers = val['modifiers']
        modifier = obj.modifiers[modifiers[0]]
        blender_version = bpy.app.version
        minimum_version = (3, 5, 0)
        if blender_version >= minimum_version:
            if modifier.properties.inputs[self.index]["value"]:
                modifier.properties.inputs[self.index]["value"] = False
            else:
                modifier.properties.inputs[self.index]["value"] = True
        else:
            if modifier.properties.inputs[self.index]["value"] == gn_bool_version(1):
                modifier.properties.inputs[self.index]["value"] = gn_bool_version(0)
            else:
                modifier[self.index] = gn_bool_version(1)
        bpy.ops.object.editmode_toggle()
        bpy.ops.object.editmode_toggle()

        return {'FINISHED'}


class BAGAPIE_OP_switchboolnode(Operator):
    """Switch Node Bool input"""
    bl_idname = "switch.boolnode"
    bl_label = "switch.boolnode"

    index: bpy.props.IntProperty(name="None")

    def execute(self, context):
        obj = context.object
        val = json.loads(obj.bagapieList[obj.bagapieIndex]['val'])
        modifiers = val['modifiers']
        modifier = obj.modifiers[modifiers[0]]

        scatter_node = modifier.node_group.nodes.get(modifiers[1])
        blender_version = bpy.app.version
        minimum_version = (3, 5, 0)
        if blender_version >= minimum_version:
            if scatter_node.inputs[self.index].default_value:
                scatter_node.inputs[self.index].default_value = False
            else:
                scatter_node.inputs[self.index].default_value = True
        else:
            if scatter_node.inputs[self.index].default_value == gn_bool_version(1):
                scatter_node.inputs[self.index].default_value = gn_bool_version(0)
            else:
                scatter_node.inputs[self.index].default_value = gn_bool_version(1)
        bpy.ops.object.editmode_toggle()
        bpy.ops.object.editmode_toggle()

        return {'FINISHED'}


###################################################################################
# DISPLAY TOOLTIPS
###################################################################################
class BagaPie_tooltips(Operator):
    """Display a tooltips"""
    bl_idname = "bagapie.tooltips"
    bl_label = "Tips"

    message: bpy.props.StringProperty(default="None") # type: ignore
    title: bpy.props.StringProperty(default="Tooltip") # type: ignore
    icon: bpy.props.StringProperty(default="INFO") # type: ignore

    def execute(self, context):
        Warning(self.message, self.title, self.icon) 
        return {'FINISHED'}


def RemoveOBJandDeleteColl(self, context, collection):
    for obj in collection.all_objects:
        collection.objects.unlink(obj)
    bpy.data.collections.remove(collection)


###################################################################################
# UI UTILS
###################################################################################
def Double_Row_Switch(ui_type = '', modifier = '', index = '', name_a ='', name_b=''):
    row = ui_type.row(align = True)
    id_a = row.operator('switch.boolcustom', depress = not modifier.properties.inputs[index]["value"], text = name_a)
    id_a.index = index
    id_a.modifier = modifier.name
    id_b = row.operator('switch.boolcustom', depress = modifier.properties.inputs[index]["value"], text = name_b)
    id_b.index = index
    id_b.modifier = modifier.name

def format_shortcut(kmi):
    keys = []
    if kmi.ctrl:
        keys.append("Ctrl")
    if kmi.alt:
        keys.append("Alt")
    if kmi.shift:
        keys.append("Shift")
    if kmi.oskey:
        keys.append("Cmd")
    keys.append(kmi.type.title())
    return " + ".join(keys)

def modifier_header_basic(layout):
    row_head = layout.row(align=True)
    row_head.label(text="Modifier Properties :")
    row_head.operator("wm.url_open", text="", icon = 'PLAY',emboss=False).url = "https://youtube.com/playlist?list=PLSVXpfzibQbh_qjzCP2buB2rK1lQtkQvu&si=Y4MRQn_aTIQUXOpw"


###################################################################################
# Change bool value depending on the blender version
###################################################################################
def gn_bool_version(value):
    if value == 1:
        if bpy.app.version < (3, 5, 0):
            value = 1
        else:
            value = True
    else:        
        if bpy.app.version < (3, 5, 0):
            value = 0
        else:
            value = False
    return value


classes = [
    BAGAPIE_MT_pie_menu,
    BAGAPIE_UL_List,
    BAGAPIE_PT_modifier_panel,
    BAGAPIE_OP_modifierDisplay,
    BAGAPIE_OP_modifierDisplayRender,
    BAGAPIE_OP_modifierApply,
    BAGAPIE_OP_addparttype,
    BAGAPIE_OP_switchinput,
    BAGAPIE_OP_switchboolnode,
    BagaPie_tooltips,
]